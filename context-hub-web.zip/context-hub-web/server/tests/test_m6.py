"""
M6 exit criteria verification.
Run: python -m tests.test_m6
"""

import os
os.environ.setdefault("CH_MCP_PERSONA", "data-engineer")

from app.db import init_db, get_connection
from app.retrieval.hybrid import retrieve_governed
from mcp_server.server import graph_retrieve, graph_walk, context_assets, PERSONA

QUERY = "Who owns the billing retry logic and what is the current retry policy?"


def test_m6_1():
    print("── M6-1: MCP graph.retrieve == POST /api/ask, both audited ──")

    http_result = retrieve_governed(QUERY, PERSONA, channel="http")
    mcp_result = graph_retrieve(QUERY, k=8)

    http_doc_ids = {r.chunk.document_id for r in http_result.chunks}
    mcp_doc_ids = {c["document_id"] for c in mcp_result["chunks"]}
    identical = http_doc_ids == mcp_doc_ids

    con = get_connection()
    rows = con.execute(
        """SELECT channel FROM serve_events WHERE asset = ? ORDER BY ts DESC LIMIT 5""",
        (QUERY[:200],),
    ).fetchall()
    con.close()
    channels = [r[0] for r in rows]
    has_http = "http" in channels
    has_mcp = "mcp" in channels

    print(f"  HTTP chunk doc_ids : {sorted(http_doc_ids)}")
    print(f"  MCP  chunk doc_ids : {sorted(mcp_doc_ids)}")
    print(f"  Identical chunk sets       : {'✓' if identical else 'FAIL'}")
    print(f"  Recent channels            : {channels}")
    print(f"  http row present           : {'✓' if has_http else 'FAIL'}")
    print(f"  mcp row present            : {'✓' if has_mcp else 'FAIL'}")

    passed = identical and has_http and has_mcp
    print(f"  M6-1 : {'✓ PASS' if passed else 'FAIL'}")
    return passed


def test_m6_walk():
    print("── M6-walk: graph.walk returns a real neighborhood ─────────")
    result = graph_walk("Ana Rivera", depth=1)
    ok = len(result["nodes"]) > 1 and "error" not in result
    print(f"  Nodes: {len(result['nodes'])} Edges: {len(result['edges'])}")
    print(f"  M6-walk : {'✓ PASS' if ok else 'FAIL'}")
    return ok


def test_m6_assets():
    print("── M6-assets: context.assets filters correctly ─────────────")
    result = context_assets("rfc")
    ok = len(result) > 0 and all("rfc" in a["label"].lower() for a in result)
    print(f"  Matches: {[a['label'] for a in result]}")
    print(f"  M6-assets : {'✓ PASS' if ok else 'FAIL'}")
    return ok


if __name__ == "__main__":
    init_db()
    print("Running M6 exit criteria verification...")
    print()

    m6_1 = test_m6_1()
    print()
    m6_w = test_m6_walk()
    print()
    m6_a = test_m6_assets()
    print()

    print("── M6 Exit Criteria Summary ──────────────────────────────────")
    print(f"  M6-1 MCP == HTTP, both audited : {'✓ PASS' if m6_1 else 'FAIL'}")
    print(f"  M6-walk graph.walk sane        : {'✓ PASS' if m6_w else 'FAIL'}")
    print(f"  M6-assets context.assets sane  : {'✓ PASS' if m6_a else 'FAIL'}")
    print()
    all_pass = m6_1 and m6_w and m6_a
    print(f"{'M6 COMPLETE ✓' if all_pass else 'M6 INCOMPLETE — fix failures above'}")
