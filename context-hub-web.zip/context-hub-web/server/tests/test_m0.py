"""
M0 exit criteria verification.
Run: python -m tests.test_m0
"""

import httpx
from app.db import init_db, check_db_connection


def test_m0_1():
    print("── M0-1: Health endpoint returns 200 ────────────────────────")
    try:
        r = httpx.get(
            "http://localhost:8080/api/health",
            headers={"X-Persona": "data-engineer"}
        )
        ok = r.status_code == 200 and r.json().get("db") is True
        print(f"  Status code 200  : {'✓' if r.status_code == 200 else 'FAIL'}")
        print(f"  db: true         : {'✓' if r.json().get('db') else 'FAIL'}")
        print(f"  M0-1 : {'✓ PASS' if ok else 'FAIL'}")
        return ok
    except Exception as e:
        print(f"  M0-1 : FAIL — server not running? ({e})")
        return False


def test_m0_2():
    print("── M0-2: Unknown persona returns 400 ────────────────────────")
    try:
        r1 = httpx.get("http://localhost:8080/api/personas")
        r2 = httpx.get(
            "http://localhost:8080/api/personas",
            headers={"X-Persona": "hacker"}
        )
        no_header = r1.status_code == 400
        bad_persona = r2.status_code == 400
        print(f"  No header → 400  : {'✓' if no_header else f'FAIL (got {r1.status_code})'}")
        print(f"  Bad persona → 400: {'✓' if bad_persona else f'FAIL (got {r2.status_code})'}")
        ok = no_header and bad_persona
        print(f"  M0-2 : {'✓ PASS' if ok else 'FAIL'}")
        return ok
    except Exception as e:
        print(f"  M0-2 : FAIL — server not running? ({e})")
        return False


def test_m0_3():
    print("── M0-3: Database initialised ───────────────────────────────")
    init_db()
    ok = check_db_connection()
    print(f"  DB connection    : {'✓' if ok else 'FAIL'}")

    from app.db import get_connection
    con = get_connection()
    tables = [r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()]
    con.close()

    required = {
        "documents", "chunks", "entities", "aliases",
        "edges", "pii_spans", "review_queue", "serve_events"
    }
    missing = required - set(tables)
    all_tables = len(missing) == 0
    print(f"  All 8 tables     : {'✓' if all_tables else f'FAIL — missing: {missing}'}")
    ok = ok and all_tables
    print(f"  M0-3 : {'✓ PASS' if ok else 'FAIL'}")
    return ok


if __name__ == "__main__":
    print("Running M0 exit criteria verification...")
    print()

    m0_1 = test_m0_1()
    print()
    m0_2 = test_m0_2()
    print()
    m0_3 = test_m0_3()
    print()

    print("── M0 Exit Criteria Summary ──────────────────────────────────")
    print(f"  M0-1 Health endpoint     : {'✓ PASS' if m0_1 else 'FAIL'}")
    print(f"  M0-2 Persona middleware  : {'✓ PASS' if m0_2 else 'FAIL'}")
    print(f"  M0-3 DB initialised      : {'✓ PASS' if m0_3 else 'FAIL'}")
    print()
    all_pass = m0_1 and m0_2 and m0_3
    print(f"{'M0 COMPLETE ✓' if all_pass else 'M0 INCOMPLETE — fix failures above'}")