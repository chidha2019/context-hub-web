"""
M4 exit criteria verification.
Run: python -m tests.test_m4
"""

import os
from app.retrieval.hybrid import retrieve_governed
from app.llm.client import stream_answer, validate_citations
from app.db import init_db


QUERY = "Who owns the billing retry logic and what is the current retry policy?"


def run_stream(query: str, persona: str) -> tuple[str, str]:
    """Run stream_answer and collect full answer + model used."""
    result = retrieve_governed(query, persona)
    full_answer = ""
    model_used  = ""
    for event in stream_answer(query, result):
        if event["type"] == "token":
            full_answer += event["data"]
        elif event["type"] == "done":
            model_used = event["data"]["model"]
    return full_answer, model_used, result


def test_m4_1():
    print("── M4-1: Citations valid (no hallucinated references) ────────")
    ok = True
    for persona in ["data-engineer", "citizen"]:
        answer, model, result = run_stream(QUERY, persona)
        check = validate_citations(answer, result.chunks)
        valid = check["valid"]
        print(f"  {persona}")
        print(f"    Model   : {model}")
        print(f"    Cited   : {check['cited']}")
        bad = check["bad_citations"]
        print(f"    Valid   : {'✓' if valid else 'FAIL — bad citations: ' + str(bad)}")
        ok = ok and valid
    print(f"  M4-1 : {'✓ PASS' if ok else 'FAIL'}")
    return ok


def test_m4_2():
    print("── M4-2: Offline fallback works ─────────────────────────────")

    # Patch llm_enabled directly on the client module's settings
    import app.llm.client as client_module
    import app.config as config_module

    # Force offline
    original = config_module.settings.llm_enabled
    config_module.settings.llm_enabled = False

    result = retrieve_governed(QUERY, "data-engineer")
    full_answer = ""
    model_used  = ""
    for event in client_module.stream_answer(QUERY, result):
        if event["type"] == "token":
            full_answer += event["data"]
        elif event["type"] == "done":
            model_used = event["data"]["model"]

    # Restore
    config_module.settings.llm_enabled = original

    fallback_used  = model_used == "offline-fallback"
    has_content    = len(full_answer) > 100
    check          = validate_citations(full_answer, result.chunks)

    print(f"  Model used     : {model_used}")
    print(f"  Answer length  : {len(full_answer)} chars")
    print(f"  Has content    : {'✓' if has_content else 'FAIL'}")
    print(f"  Fallback used  : {'✓' if fallback_used else 'FAIL'}")
    print(f"  Citations valid: {'✓' if check['valid'] else 'FAIL'}")

    ok = fallback_used and has_content and check["valid"]
    print(f"  M4-2 : {'✓ PASS' if ok else 'FAIL'}")
    return ok


def test_m4_withheld_notice():
    print("── M4-withheld: Citizen sees withheld notice ─────────────────")
    result = retrieve_governed(QUERY, "citizen")
    answer = ""
    model  = ""
    for event in stream_answer(QUERY, result):
        if event["type"] == "token":
            answer += event["data"]
        elif event["type"] == "done":
            model = event["data"]["model"]

    has_withheld = (
        "withheld" in answer.lower() or
        "access control" in answer.lower() or
        "policy" in answer.lower()
    )
    denied_correct = result.acl_denied_count == 6

    print(f"  Model          : {model}")
    print(f"  Denied count   : {result.acl_denied_count} {'✓' if denied_correct else 'FAIL'}")
    print(f"  Withheld notice: {'✓' if has_withheld else 'FAIL'}")
    print(f"  Answer preview : {answer[:200]}")

    ok = has_withheld and denied_correct
    print(f"  M4-withheld : {'✓ PASS' if ok else 'FAIL'}")
    return ok


if __name__ == "__main__":
    init_db()
    print("Running M4 exit criteria verification...")
    print()

    # Make sure LLM is enabled first
    from app.config import settings
    settings.llm_enabled = True

    m4_1 = test_m4_1()
    print()
    m4_2 = test_m4_2()
    print()
    m4_w = test_m4_withheld_notice()
    print()

    print("── M4 Exit Criteria Summary ──────────────────────────────────")
    print(f"  M4-1 Citations valid    : {'✓ PASS' if m4_1 else 'FAIL'}")
    print(f"  M4-2 Offline fallback   : {'✓ PASS' if m4_2 else 'FAIL'}")
    print(f"  M4-W Withheld notice    : {'✓ PASS' if m4_w else 'FAIL'}")
    print()
    all_pass = m4_1 and m4_2 and m4_w
    print(f"{'M4 COMPLETE ✓' if all_pass else 'M4 INCOMPLETE — fix failures above'}")