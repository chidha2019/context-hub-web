"""
M1 exit criteria verification.
Run: python -m tests.test_m1
"""

import json
import hashlib
from pathlib import Path

CORPUS_DIR = Path(__file__).parent.parent / "app" / "synth" / "corpus"


def test_m1_1():
    print("── M1-1: Determinism ─────────────────────────────────────────")
    import hashlib
    import app.synth.generate as gen

    def fresh_corpus():
        # Reset RNG to seed before each run
        gen.rng = gen.random.Random(gen.SEED)
        gen.write_corpus()

    fresh_corpus()
    hashes_1 = {}
    for f in ["github.json", "jira.json", "slack.json"]:
        content = (CORPUS_DIR / f).read_bytes()
        hashes_1[f] = hashlib.md5(content).hexdigest()

    fresh_corpus()
    hashes_2 = {}
    for f in ["github.json", "jira.json", "slack.json"]:
        content = (CORPUS_DIR / f).read_bytes()
        hashes_2[f] = hashlib.md5(content).hexdigest()

    ok = hashes_1 == hashes_2
    for f in ["github.json", "jira.json", "slack.json"]:
        match = hashes_1[f] == hashes_2[f]
        print(f"  {f:20s} : {'✓' if match else 'FAIL'}")
    print(f"  M1-1 : {'✓ PASS' if ok else 'FAIL'}")
    return ok

def test_m1_2():
    print("── M1-2: Planted counts match §7.1 ──────────────────────────")
    manifest = json.loads((CORPUS_DIR / "manifest.json").read_text())

    pii_count           = len(manifest.get("pii", []))
    injection_count     = len(manifest.get("injections", []))
    contradiction_count = len(manifest.get("contradictions", []))
    collision_count     = len(manifest.get("collisions", []))

    checks = [
        ("PII instances  ", pii_count,           24),
        ("Injections     ", injection_count,       2),
        ("Contradictions ", contradiction_count,   3),
        ("Collisions     ", collision_count,       12),
    ]

    ok = True
    for label, actual, expected in checks:
        passed = actual == expected
        print(f"  {label}: {actual:3d} (expected {expected}) "
              f"{'✓' if passed else 'FAIL'}")
        ok = ok and passed

    print(f"  M1-2 : {'✓ PASS' if ok else 'FAIL'}")
    return ok


def test_m1_3():
    print("── M1-3: No canonical mapping in corpus ─────────────────────")
    ok = True
    for f in ["github.json", "jira.json", "slack.json"]:
        content = (CORPUS_DIR / f).read_text()
        found = '"canonical"' in content
        print(f"  {f:20s} : {'FAIL — canonical found' if found else '✓ clean'}")
        if found:
            ok = False
    print(f"  M1-3 : {'✓ PASS' if ok else 'FAIL'}")
    return ok


def test_m1_anchors():
    print("── M1-anchors: Key entities present ─────────────────────────")
    github = json.loads((CORPUS_DIR / "github.json").read_text())
    jira   = json.loads((CORPUS_DIR / "jira.json").read_text())
    slack  = json.loads((CORPUS_DIR / "slack.json").read_text())

    rfc114   = any(d["id"] == "doc_rfc_114" for d in github["documents"])
    pr3182   = any(p["number"] == 3182 for p in github["pull_requests"])
    pay2871  = any(i["key"] == "PAY-2871" for i in jira["issues"])
    conf_ch  = any(c["classification"] == "confidential" for c in slack["channels"])

    checks = [
        ("RFC-114 present              ", rfc114),
        ("PR #3182 present             ", pr3182),
        ("PAY-2871 present             ", pay2871),
        ("#payments-security confidential", conf_ch),
    ]

    ok = True
    for label, passed in checks:
        print(f"  {label}: {'✓' if passed else 'FAIL'}")
        ok = ok and passed

    print(f"  M1-anchors : {'✓ PASS' if ok else 'FAIL'}")
    return ok


if __name__ == "__main__":
    print("Running M1 exit criteria verification...")
    print()

    m1_1 = test_m1_1()
    print()
    m1_2 = test_m1_2()
    print()
    m1_3 = test_m1_3()
    print()
    m1_a = test_m1_anchors()
    print()

    print("── M1 Exit Criteria Summary ──────────────────────────────────")
    print(f"  M1-1 Determinism          : {'✓ PASS' if m1_1 else 'FAIL'}")
    print(f"  M1-2 Planted counts       : {'✓ PASS' if m1_2 else 'FAIL'}")
    print(f"  M1-3 No canonical mapping : {'✓ PASS' if m1_3 else 'FAIL'}")
    print(f"  M1-A Key anchors present  : {'✓ PASS' if m1_a else 'FAIL'}")
    print()
    all_pass = m1_1 and m1_2 and m1_3 and m1_a
    print(f"{'M1 COMPLETE ✓' if all_pass else 'M1 INCOMPLETE — fix failures above'}")