"""
M2 exit criteria verification.
Run: python -m tests.test_m2
"""

import time
from app.db import init_db, get_connection
from app.ingest.pipeline import run_pipeline


def test_m2_1():
    print("── M2-1: Ana Rivera resolves across 3 sources ───────────────")
    con = get_connection()

    entity = con.execute("""
        SELECT id, canonical_name FROM entities
        WHERE canonical_name = 'Ana Rivera'
    """).fetchone()

    if not entity:
        print("  Ana Rivera entity : FAIL — not found")
        con.close()
        return False

    entity_id = entity[0]
    aliases = con.execute("""
        SELECT source, raw_name FROM aliases
        WHERE entity_id = ?
    """, (entity_id,)).fetchall()
    con.close()

    alias_map = {source: raw_name for source, raw_name in aliases}

    github_ok = "github" in alias_map
    jira_ok   = "jira"   in alias_map
    slack_ok  = "slack"  in alias_map

    print(f"  github alias ({alias_map.get('github', 'MISSING')}) : "
          f"{'✓' if github_ok else 'FAIL'}")
    print(f"  jira alias   ({alias_map.get('jira',   'MISSING')}) : "
          f"{'✓' if jira_ok else 'FAIL'}")
    print(f"  slack alias  ({alias_map.get('slack',  'MISSING')}) : "
          f"{'✓' if slack_ok else 'FAIL'}")

    ok = github_ok and jira_ok and slack_ok
    print(f"  M2-1 : {'✓ PASS' if ok else 'FAIL'}")
    return ok


def test_m2_2():
    print("── M2-2: PR #3182 FIXES PAY-2871 edge ───────────────────────")
    con = get_connection()
    count = con.execute("""
        SELECT COUNT(*) FROM edges
        WHERE src_id LIKE '%pr_3182%' AND rel = 'FIXES'
    """).fetchone()[0]
    con.close()

    ok = count > 0
    print(f"  FIXES edge exists : {'✓' if ok else 'FAIL'} (count={count})")
    print(f"  M2-2 : {'✓ PASS' if ok else 'FAIL'}")
    return ok


def test_m2_3():
    print("── M2-3: Ambiguous pairs in steward queue ────────────────────")
    con = get_connection()
    pending = con.execute("""
        SELECT COUNT(*) FROM review_queue WHERE state = 'pending'
    """).fetchone()[0]

    items = con.execute("""
        SELECT title, confidence FROM review_queue
        WHERE state = 'pending'
        ORDER BY confidence DESC
    """).fetchall()
    con.close()

    ok = pending > 0
    print(f"  Pending items : {pending} {'✓' if ok else 'FAIL'}")
    for title, confidence in items:
        print(f"    [{confidence:.3f}] {title}")
    print(f"  M2-3 : {'✓ PASS' if ok else 'FAIL'}")
    return ok


def test_m2_4():
    print("── M2-4: Full ingest under 90s ───────────────────────────────")
    t0 = time.time()
    run_pipeline()
    elapsed = time.time() - t0

    ok = elapsed < 90
    print(f"  Elapsed : {elapsed:.1f}s {'✓' if ok else 'FAIL (> 90s)'}")
    print(f"  M2-4 : {'✓ PASS' if ok else 'FAIL'}")
    return ok


def test_m2_counts():
    print("── M2-counts: Database row counts ───────────────────────────")
    con = get_connection()
    counts = {}
    for table in ["documents", "chunks", "entities", "aliases", "edges", "review_queue"]:
        counts[table] = con.execute(
            f"SELECT COUNT(*) FROM {table}"
        ).fetchone()[0]
    con.close()

    ok = True
    for table, count in counts.items():
        has_rows = count > 0
        print(f"  {table:15s} : {count:4d} rows {'✓' if has_rows else 'FAIL — empty'}")
        ok = ok and has_rows

    print(f"  M2-counts : {'✓ PASS' if ok else 'FAIL'}")
    return ok


if __name__ == "__main__":
    print("Running M2 exit criteria verification...")
    print()
    init_db()

    m2_1 = test_m2_1()
    print()
    m2_2 = test_m2_2()
    print()
    m2_3 = test_m2_3()
    print()
    m2_c = test_m2_counts()
    print()
    m2_4 = test_m2_4()
    print()

    print("── M2 Exit Criteria Summary ──────────────────────────────────")
    print(f"  M2-1 Ana Rivera 3-source resolution : {'✓ PASS' if m2_1 else 'FAIL'}")
    print(f"  M2-2 PR #3182 FIXES PAY-2871        : {'✓ PASS' if m2_2 else 'FAIL'}")
    print(f"  M2-3 Ambiguous pairs queued         : {'✓ PASS' if m2_3 else 'FAIL'}")
    print(f"  M2-4 Ingest under 90s               : {'✓ PASS' if m2_4 else 'FAIL'}")
    print(f"  M2-C DB counts populated            : {'✓ PASS' if m2_c else 'FAIL'}")
    print()
    all_pass = m2_1 and m2_2 and m2_3 and m2_4 and m2_c
    print(f"{'M2 COMPLETE ✓' if all_pass else 'M2 INCOMPLETE — fix failures above'}")