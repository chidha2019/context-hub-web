# ContextHub server

FastAPI backend + MCP server for the ContextHub POC. See `docs/POC-PLAN.md` at the repo root for
the full build specification.

## MCP server

`mcp_server/server.py` exposes the same governed retrieval the HTTP API uses
(`retrieve_governed()` / `get_governed_graph()`) over MCP's stdio transport — an MCP client (such
as Claude Code) gets identical governed results to the web UI for the same persona and query, and
every call is written to the same audit trail with `channel = "mcp"`.

Persona is bound **once, at launch**, via the `CH_MCP_PERSONA` env var — not chosen per call. The
server refuses to start if it's missing or not one of the three governed personas
(`data-engineer`, `digital-engineer`, `citizen`).

Add to a client's `.mcp.json`:

```json
{
  "mcpServers": {
    "contexthub": {
      "command": "uv",
      "args": ["run", "--directory", "server", "python", "-m", "mcp_server.server"],
      "env": { "CH_MCP_PERSONA": "citizen" }
    }
  }
}
```

Tools:

- `graph.retrieve(query, k=8)` — governed hybrid retrieval (BM25 + vector + graph, ACL-filtered,
  PII masked/redacted per policy). Returns the same `trace`/`chunks`/`guardrails` shape
  `POST /api/ask` streams.
- `graph.walk(entity, depth=2)` — ACL-filtered N-hop neighborhood around an entity (matched by
  node id, canonical name, or alias).
- `context.assets(filter=None)` — governed listing of documents and entities, optionally
  substring-filtered.

Run the exit-criteria check: `uv run python -m tests.test_m6` (from `server/`).
