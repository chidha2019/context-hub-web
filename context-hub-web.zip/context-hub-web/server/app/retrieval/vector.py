"""
Vector retrieval — brute-force cosine similarity over numpy matrix.
Finds semantically similar chunks even without exact word matches.
At 30 chunks / ~3500 projected chunks this is sub-5ms — no vector DB needed.
"""

import json
import numpy as np
from dataclasses import dataclass
from pathlib import Path
from app.ingest.chunker import Chunk
from app.ingest.embedder import load_vectors

CHUNK_IDS_PATH = Path(__file__).parent.parent / "synth" / "corpus" / "chunk_ids.json"


@dataclass
class VectorHit:
    chunk: Chunk
    score: float
    rank: int


def search(
    query: str,
    chunks: list[Chunk],
    top_k: int = 40,
    model=None,
) -> list[VectorHit]:
    from sentence_transformers import SentenceTransformer
    from app.config import settings

    matrix, all_ids = load_vectors()
    id_to_row = {cid: i for i, cid in enumerate(all_ids)}

    allowed_ids    = [c.id for c in chunks]
    allowed_rows   = [id_to_row[cid] for cid in allowed_ids if cid in id_to_row]
    allowed_chunks = [c for c in chunks if c.id in id_to_row]

    if not allowed_rows:
        return []

    sub_matrix = matrix[allowed_rows]

    # Use passed model or load once
    if model is None:
        model = SentenceTransformer(settings.embed_model)

    query_vec = model.encode(
        [query],
        normalize_embeddings=settings.embed_normalize,
    )[0].astype(np.float32)

    scores = sub_matrix @ query_vec
    ranked_indices = np.argsort(scores)[::-1]

    hits = []
    for rank, idx in enumerate(ranked_indices[:top_k]):
        score = float(scores[idx])
        if score > 0:
            hits.append(VectorHit(
                chunk=allowed_chunks[idx],
                score=score,
                rank=rank,
            ))

    return hits

if __name__ == "__main__":
    from app.ingest.github  import GitHubConnector
    from app.ingest.jira    import JiraConnector
    from app.ingest.slack   import SlackConnector
    from app.ingest.chunker import chunk_records
    from app.governance.acl import apply_acl
    from sentence_transformers import SentenceTransformer
    from app.config import settings

    # Load once — shared across all personas
    print("Loading model...")
    model = SentenceTransformer(settings.embed_model)

    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )
    all_chunks = chunk_records(records)

    QUERY = "Who owns the billing retry logic and what is the current retry policy?"
    print(f"Query: {QUERY}\n")

    for persona_id in ["data-engineer", "digital-engineer", "citizen"]:
        acl_result = apply_acl(all_chunks, persona_id)
        allowed    = acl_result.allowed
        hits       = search(QUERY, allowed, top_k=10, model=model)

        print(f"Persona: {persona_id}")
        print(f"  Pool  : {len(allowed)} chunks after ACL")
        print(f"  Hits  : {len(hits)}")
        for h in hits[:5]:
            print(f"    [{h.score:.3f}] {h.chunk.document_id} "
                  f"source={h.chunk.source}")
        print()