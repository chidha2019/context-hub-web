"""
Lexical retrieval — BM25.
Searches chunk text using term frequency / inverse document frequency.
Fast, no model needed, excellent for exact term matches.
"""

from dataclasses import dataclass
from rank_bm25 import BM25Okapi
from app.ingest.chunker import Chunk


@dataclass
class LexicalHit:
    chunk: Chunk
    score: float
    rank: int


def _tokenize(text: str) -> list[str]:
    return text.lower().split()


def build_index(chunks: list[Chunk]) -> BM25Okapi:
    """Build BM25 index from chunk texts."""
    corpus = [_tokenize(c.text) for c in chunks]
    return BM25Okapi(corpus)


def search(
    query: str,
    chunks: list[Chunk],
    index: BM25Okapi,
    top_k: int = 40,
) -> list[LexicalHit]:
    """
    BM25 search over chunks.
    Returns top_k hits sorted by score descending.
    """
    tokens = _tokenize(query)
    scores = index.get_scores(tokens)

    hits = []
    for i, (chunk, score) in enumerate(zip(chunks, scores)):
        if score > 0:
            hits.append(LexicalHit(chunk=chunk, score=float(score), rank=i))

    hits.sort(key=lambda h: h.score, reverse=True)
    return hits[:top_k]


if __name__ == "__main__":
    from app.ingest.github  import GitHubConnector
    from app.ingest.jira    import JiraConnector
    from app.ingest.slack   import SlackConnector
    from app.ingest.chunker import chunk_records
    from app.governance.acl import apply_acl

    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )
    all_chunks = chunk_records(records)

    QUERY = "Who owns the billing retry logic and what is the current retry policy?"

    print(f"Query: {QUERY}\n")

    for persona_id in ["data-engineer", "digital-engineer", "citizen"]:
        acl_result = apply_acl(all_chunks, persona_id)
        allowed    = acl_result.allowed
        index      = build_index(allowed)
        hits       = search(QUERY, allowed, index, top_k=10)

        print(f"Persona: {persona_id}")
        print(f"  Pool  : {len(allowed)} chunks after ACL")
        print(f"  Hits  : {len(hits)}")
        for h in hits[:5]:
            print(f"    [{h.score:.3f}] {h.chunk.document_id} "
                  f"source={h.chunk.source}")
        print()