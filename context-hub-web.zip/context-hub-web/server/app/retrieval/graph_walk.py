"""
Graph walk retrieval.
Extracts named entities from the query, finds them in the knowledge graph,
then walks outward N hops to find connected chunks.
Brings in contextually related chunks that keyword/vector search alone misses.
"""

import sqlite3
from dataclasses import dataclass
from app.ingest.chunker import Chunk
from app.db import get_connection
from app.config import settings


@dataclass
class GraphHit:
    chunk: Chunk
    score: float
    rank: int
    seed_entity: str    # which entity triggered this hit
    hops: int           # how many hops from the seed


# ── Entity extraction from query ──────────────────────────────────────────────

# Known entity names to look for in queries
# In production this would use NER — for POC, simple keyword matching
ENTITY_KEYWORDS: dict[str, str] = {
    # Services
    "billing-service": "billing-service",
    "billing service": "billing-service",
    "billing":         "billing-service",
    "identity-api":    "identity-api",
    "identity api":    "identity-api",
    "identity":        "identity-api",
    "data-loader":     "data-loader",
    "gateway":         "gateway",
    "scheduler":       "scheduler",

    # People
    "ana rivera":  "Ana Rivera",
    "arivera":     "Ana Rivera",
    "ana":         "Ana Rivera",
    "michael chen":"Michael Chen",
    "priya":       "Priya Krishnan",
    "raj":         "Raj Bhat",

    # Documents
    "rfc-114":  "RFC-114",
    "rfc 114":  "RFC-114",
    "pay-2871": "PAY-2871",
    "pay 2871": "PAY-2871",
    "pr #3182": "PR #3182",
    "pr 3182":  "PR #3182",

    # Customers
    "acme":     "Acme Corp",
    "acme corp":"Acme Corp",
    "brightline":"Brightline Inc",
    "vertex":   "Vertex Systems",
}


def extract_entities(query: str) -> list[str]:
    """Extract known entity names from query text."""
    query_lower = query.lower()
    found = []
    for keyword, canonical in ENTITY_KEYWORDS.items():
        if keyword in query_lower and canonical not in found:
            found.append(canonical)
    return found[:settings.graph_seed_max]


# ── Graph traversal ───────────────────────────────────────────────────────────

def _get_connected_doc_ids(
    seed_names: list[str],
    hops: int,
    con: sqlite3.Connection,
) -> dict[str, tuple[str, int]]:
    """
    Walk the graph from seed entities outward N hops.
    Returns {doc_id -> (seed_name, hop_distance)}
    """
    connected: dict[str, tuple[str, int]] = {}

    for seed in seed_names:
        # Find entity node by canonical name or alias
        cur = con.execute("""
            SELECT e.id FROM entities e
            WHERE LOWER(e.canonical_name) = LOWER(?)
            UNION
            SELECT a.entity_id FROM aliases a
            WHERE LOWER(a.raw_name) = LOWER(?)
        """, (seed, seed))
        entity_rows = cur.fetchall()

        if not entity_rows:
            # Try document nodes directly
            cur = con.execute("""
                SELECT id FROM documents
                WHERE LOWER(title) LIKE ?
            """, (f"%{seed.lower()}%",))
            doc_rows = cur.fetchall()
            for (doc_id,) in doc_rows:
                if doc_id not in connected:
                    connected[doc_id] = (seed, 0)
            continue

        # BFS from each entity node
        for (entity_id,) in entity_rows:
            frontier = {entity_id}
            for hop in range(hops):
                next_frontier = set()
                for node in frontier:
                    # Follow edges outward
                    cur = con.execute("""
                        SELECT dst_id FROM edges WHERE src_id = ?
                        UNION
                        SELECT src_id FROM edges WHERE dst_id = ?
                    """, (node, node))
                    for (neighbor,) in cur.fetchall():
                        # If it looks like a document id, record it
                        if neighbor.startswith("github:") or \
                           neighbor.startswith("jira:") or \
                           neighbor.startswith("slack:"):
                            if neighbor not in connected:
                                connected[neighbor] = (seed, hop + 1)
                        next_frontier.add(neighbor)
                frontier = next_frontier

    return connected


def search(
    query: str,
    chunks: list[Chunk],
    top_k: int = 20,
) -> list[GraphHit]:
    """
    Graph walk search.
    1. Extract entities from query
    2. Find them in the graph
    3. Walk N hops to find connected document IDs
    4. Return chunks whose document_id was reached
    """
    seed_entities = extract_entities(query)
    if not seed_entities:
        return []

    con = get_connection()
    connected = _get_connected_doc_ids(
        seed_entities,
        hops=settings.graph_hops,
        con=con,
    )
    con.close()

    # Map document IDs to chunks
    chunk_map: dict[str, list[Chunk]] = {}
    for c in chunks:
        chunk_map.setdefault(c.document_id, []).append(c)

    hits = []
    for doc_id, (seed, hop) in connected.items():
        doc_chunks = chunk_map.get(doc_id, [])
        for c in doc_chunks:
            # Proximity boost — closer hops score higher
            score = 1.0 / (1 + hop)
            hits.append(GraphHit(
                chunk=c,
                score=score,
                rank=0,
                seed_entity=seed,
                hops=hop,
            ))

    # Sort by score
    hits.sort(key=lambda h: h.score, reverse=True)
    for i, h in enumerate(hits):
        h.rank = i

    return hits[:top_k]


if __name__ == "__main__":
    from app.ingest.github  import GitHubConnector
    from app.ingest.jira    import JiraConnector
    from app.ingest.slack   import SlackConnector
    from app.ingest.chunker import chunk_records
    from app.governance.acl import apply_acl

    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )
    all_chunks = chunk_records(records)

    QUERY = "Who owns the billing retry logic and what is the current retry policy?"
    print(f"Query: {QUERY}\n")

    entities = extract_entities(QUERY)
    print(f"Extracted entities: {entities}\n")

    for persona_id in ["data-engineer", "digital-engineer", "citizen"]:
        acl_result = apply_acl(all_chunks, persona_id)
        allowed    = acl_result.allowed
        hits       = search(QUERY, allowed, top_k=10)

        print(f"Persona: {persona_id}")
        print(f"  Pool  : {len(allowed)} chunks after ACL")
        print(f"  Hits  : {len(hits)}")
        for h in hits[:5]:
            print(f"    [{h.score:.3f}] {h.chunk.document_id} "
                  f"hops={h.hops} seed='{h.seed_entity}'")
        print()