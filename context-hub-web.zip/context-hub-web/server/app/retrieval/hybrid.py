"""
Hybrid retrieval — RRF fusion + trust weighting.
Combines BM25, vector and graph results into one ranked list.
Applies trust scores and optional reranking.
Emits a full trace for the Retrieval Trace card in Ask.tsx.
"""

from dataclasses import dataclass, field
from app.ingest.chunker import Chunk
from app.retrieval.lexical import search as bm25_search, build_index
from app.retrieval.vector import search as vector_search
from app.retrieval.graph_walk import search as graph_search
from app.config import settings

# ── Model cache ───────────────────────────────────────────────────────────────

_model = None

def _get_model():
    global _model
    if _model is None:
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer(settings.embed_model)
    return _model


# ── Result types ──────────────────────────────────────────────────────────────

@dataclass
class RankedChunk:
    chunk: Chunk
    rrf_score: float
    trust_score: float
    final_score: float
    sources: list[str]      # which retrievers found this chunk


@dataclass
class RetrievalTrace:
    query: str
    persona: str
    bm25_count: int
    vector_count: int
    graph_count: int
    fused_count: int
    final_count: int
    denied_count: int
    denied_sources: list[str]
    chunks: list[RankedChunk]


# ── Trust score lookup ────────────────────────────────────────────────────────

SOURCE_TRUST = {
    "github": settings.trust_github_docs,
    "jira":   settings.trust_jira,
    "slack":  settings.trust_slack,
}


# ── RRF fusion ────────────────────────────────────────────────────────────────

def _rrf_score(rank: int, k: int = 60) -> float:
    """Reciprocal Rank Fusion score. k=60 is the standard constant."""
    return 1.0 / (k + rank + 1)


def _fuse(
    bm25_hits,
    vector_hits,
    graph_hits,
) -> dict[str, tuple[float, list[str]]]:
    """
    Merge three ranked lists using RRF.
    Returns {chunk_id -> (rrf_score, [retriever_names])}
    """
    scores: dict[str, float] = {}
    sources: dict[str, list[str]] = {}

    for rank, hit in enumerate(bm25_hits):
        cid = hit.chunk.id
        scores[cid]  = scores.get(cid, 0) + _rrf_score(rank)
        sources.setdefault(cid, []).append("bm25")

    for rank, hit in enumerate(vector_hits):
        cid = hit.chunk.id
        scores[cid]  = scores.get(cid, 0) + _rrf_score(rank)
        sources.setdefault(cid, []).append("vector")

    for rank, hit in enumerate(graph_hits):
        cid = hit.chunk.id
        scores[cid]  = scores.get(cid, 0) + _rrf_score(rank)
        sources.setdefault(cid, []).append("graph")

    return {cid: (scores[cid], sources[cid]) for cid in scores}


# ── Main retrieve function ────────────────────────────────────────────────────

def retrieve(
    query: str,
    allowed_chunks: list[Chunk],
    persona: str,
    denied_count: int = 0,
    denied_sources: list[str] = None,
    model=None,
    final_k: int = None,
) -> RetrievalTrace:
    """
    Full hybrid retrieval pipeline.
    Expects ACL-filtered chunks — governance applied before this.
    """
    final_k = final_k or settings.final_k

    if not allowed_chunks:
        return RetrievalTrace(
            query=query, persona=persona,
            bm25_count=0, vector_count=0, graph_count=0,
            fused_count=0, final_count=0,
            denied_count=denied_count,
            denied_sources=denied_sources or [],
            chunks=[],
        )

    # 1. BM25
    index     = build_index(allowed_chunks)
    bm25_hits = bm25_search(query, allowed_chunks, index,
                             top_k=settings.bm25_top_k)

    # 2. Vector
    vector_hits = vector_search(query, allowed_chunks,
                                top_k=settings.vector_top_k,
                                model=model)

    # 3. Graph
    graph_hits = graph_search(query, allowed_chunks,
                               top_k=settings.graph_hops * 10)

    # 4. RRF fusion
    fused = _fuse(bm25_hits, vector_hits, graph_hits)

    # Build chunk lookup
    chunk_lookup = {c.id: c for c in allowed_chunks}

    # 5. Trust weighting + final scoring
    ranked: list[RankedChunk] = []
    for cid, (rrf_score, retriever_sources) in fused.items():
        chunk = chunk_lookup.get(cid)
        if not chunk:
            continue

        trust = SOURCE_TRUST.get(chunk.source, 0.5)

        # Final score = RRF score weighted by trust
        final_score = rrf_score * (0.7 + 0.3 * trust)

        ranked.append(RankedChunk(
            chunk=chunk,
            rrf_score=rrf_score,
            trust_score=trust,
            final_score=final_score,
            sources=retriever_sources,
        ))

    # Sort by final score
    ranked.sort(key=lambda r: r.final_score, reverse=True)

    # 6. Apply floor and final_k cap
    ranked = [r for r in ranked if r.rrf_score >= settings.min_score]
    ranked = ranked[:final_k]

    return RetrievalTrace(
        query=query,
        persona=persona,
        bm25_count=len(bm25_hits),
        vector_count=len(vector_hits),
        graph_count=len(graph_hits),
        fused_count=len(fused),
        final_count=len(ranked),
        denied_count=denied_count,
        denied_sources=denied_sources or [],
        chunks=ranked,
    )

# ── Governed entry point ──────────────────────────────────────────────────────

@dataclass
class GovernedResult:
    trace: RetrievalTrace
    chunks: list[RankedChunk]
    pii_counts: dict[str, int]    # chunk_id -> pii span count
    clean_texts: dict[str, str]   # chunk_id -> pii-handled text
    injection_blocked: bool
    acl_denied_count: int
    acl_denied_sources: list[str]


def retrieve_governed(
    query: str,
    persona: str,
    model=None,
    channel: str = "http",
    final_k: int | None = None,
) -> GovernedResult:
    """
    THE single entry point for all retrieval.
    Called by POST /api/ask and MCP graph.retrieve — same function, same path.

    Order:
    1. Injection scan — block hostile queries immediately
    2. ACL pre-filter — remove chunks this persona cannot see
    3. Hybrid retrieval — BM25 + vector + graph + trust weighting
    4. PII handling — mask or redact per persona policy
    5. Audit — write ServeEvent
    """
    import time
    from app.ingest.github  import GitHubConnector
    from app.ingest.jira    import JiraConnector
    from app.ingest.slack   import SlackConnector
    from app.ingest.chunker import chunk_records
    from app.governance.acl import apply_acl, get_policy
    from app.governance.pii import detect_and_apply
    from app.governance.injection import scan_query
    from app.governance.audit import write_event, ServeEvent

    t0 = time.time()

    # 1. Injection scan
    injection = scan_query(query)
    if injection.is_injection:
        write_event(ServeEvent(
            actor=persona, persona=persona,
            action="query", asset=query[:200],
            acl="blocked", pii_masked=0,
            latency_ms=int((time.time() - t0) * 1000),
            channel=channel,
        ))
        return GovernedResult(
            trace=RetrievalTrace(
                query=query, persona=persona,
                bm25_count=0, vector_count=0, graph_count=0,
                fused_count=0, final_count=0,
                denied_count=0, denied_sources=[],
                chunks=[],
            ),
            chunks=[],
            pii_counts={},
            clean_texts={},
            injection_blocked=True,
            acl_denied_count=0,
            acl_denied_sources=[],
        )

    # 2. Load all chunks + ACL filter
    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )
    all_chunks = chunk_records(records)
    acl_result = apply_acl(all_chunks, persona)

    # 3. Hybrid retrieval
    trace = retrieve(
        query=query,
        allowed_chunks=acl_result.allowed,
        persona=persona,
        denied_count=acl_result.denied_count,
        denied_sources=acl_result.denied_sources,
        model=_get_model(),
        final_k=final_k,
    )

    # 4. PII handling
    policy     = get_policy(persona)
    pii_counts = {}
    clean_texts = {}
    for ranked in trace.chunks:
        result = detect_and_apply(ranked.chunk.text, policy.pii_handling)
        pii_counts[ranked.chunk.id]  = result.count
        clean_texts[ranked.chunk.id] = result.clean_text

    total_pii = sum(pii_counts.values())

    # 5. Audit
    write_event(ServeEvent(
        actor=persona, persona=persona,
        action="query", asset=query[:200],
        acl="allowed" if trace.final_count > 0 else "denied",
        pii_masked=total_pii,
        latency_ms=int((time.time() - t0) * 1000),
        channel=channel,
    ))

    return GovernedResult(
        trace=trace,
        chunks=trace.chunks,
        pii_counts=pii_counts,
        clean_texts=clean_texts,
        injection_blocked=False,
        acl_denied_count=acl_result.denied_count,
        acl_denied_sources=acl_result.denied_sources,
    )

if __name__ == "__main__":
    from app.ingest.github  import GitHubConnector
    from app.ingest.jira    import JiraConnector
    from app.ingest.slack   import SlackConnector
    from app.ingest.chunker import chunk_records
    from app.governance.acl import apply_acl
    from sentence_transformers import SentenceTransformer

    print("Loading model...")
    model = SentenceTransformer(settings.embed_model)

    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )
    all_chunks = chunk_records(records)

    QUERY = "Who owns the billing retry logic and what is the current retry policy?"
    print(f"Query: {QUERY}\n")

    for persona_id in ["data-engineer", "digital-engineer", "citizen"]:
        acl_result = apply_acl(all_chunks, persona_id)
        trace = retrieve(
            query=QUERY,
            allowed_chunks=acl_result.allowed,
            persona=persona_id,
            denied_count=acl_result.denied_count,
            denied_sources=acl_result.denied_sources,
            model=model,
        )

        print(f"Persona : {persona_id}")
        print(f"  BM25    : {trace.bm25_count} hits")
        print(f"  Vector  : {trace.vector_count} hits")
        print(f"  Graph   : {trace.graph_count} hits")
        print(f"  Fused   : {trace.fused_count} unique")
        print(f"  Final   : {trace.final_count} chunks")
        print(f"  Denied  : {trace.denied_count} chunks")
        print(f"\n  Top chunks:")
        for r in trace.chunks[:5]:
            print(f"    [{r.final_score:.3f}] {r.chunk.document_id} "
                  f"trust={r.trust_score} via={r.sources}")

        # M3-3: RFC-114 should outrank contradiction
        rfc_rank = next(
            (i for i, r in enumerate(trace.chunks)
             if "rfc_114" in r.chunk.document_id), None)
        contradiction_rank = next(
            (i for i, r in enumerate(trace.chunks)
             if r.chunk.source == "slack" and
             "contradiction" in r.chunk.metadata.get("tags", [])), None)

        if rfc_rank is not None and contradiction_rank is not None:
            m3_3 = "✓" if rfc_rank < contradiction_rank else "FAIL"
            print(f"\n  M3-3 RFC-114 outranks contradiction: {m3_3} "
                  f"(RFC rank {rfc_rank} vs contradiction rank {contradiction_rank})")
        elif rfc_rank is not None:
            print(f"\n  M3-3 RFC-114 at rank {rfc_rank} "
                  f"(contradiction not in final set — trust filter removed it ✓)")
        print()