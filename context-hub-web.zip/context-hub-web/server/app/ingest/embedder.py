"""
Embedder.
Converts chunks to 384-dim vectors using sentence-transformers.
Stores vectors as a numpy matrix — one row per chunk.
"""

import numpy as np
from pathlib import Path
from app.ingest.chunker import Chunk
from app.config import settings

VECTOR_STORE_PATH = Path(__file__).parent.parent / "synth" / "corpus" / "vectors.npy"
CHUNK_IDS_PATH    = Path(__file__).parent.parent / "synth" / "corpus" / "chunk_ids.json"


def _load_model():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(settings.embed_model)


def embed_chunks(chunks: list[Chunk]) -> tuple[np.ndarray, list[str]]:
    """
    Embed all chunks.
    Returns:
        matrix  — float32 array of shape (n_chunks, embed_dim)
        ids     — list of chunk ids in the same row order
    """
    model  = _load_model()
    texts  = [c.text for c in chunks]
    ids    = [c.id   for c in chunks]

    print(f"Embedding {len(texts)} chunks with {settings.embed_model}...")
    vectors = model.encode(
        texts,
        batch_size=settings.embed_batch,
        normalize_embeddings=settings.embed_normalize,
        show_progress_bar=True,
    )

    matrix = np.array(vectors, dtype=np.float32)
    return matrix, ids


def save_vectors(matrix: np.ndarray, ids: list[str]) -> None:
    import json
    np.save(VECTOR_STORE_PATH, matrix)
    CHUNK_IDS_PATH.write_text(json.dumps(ids, indent=2))
    print(f"Saved {matrix.shape[0]} vectors → {VECTOR_STORE_PATH}")
    print(f"Saved chunk ids → {CHUNK_IDS_PATH}")


def load_vectors() -> tuple[np.ndarray, list[str]]:
    import json
    matrix = np.load(VECTOR_STORE_PATH)
    ids    = json.loads(CHUNK_IDS_PATH.read_text())
    return matrix, ids


if __name__ == "__main__":
    from app.ingest.github  import GitHubConnector
    from app.ingest.jira    import JiraConnector
    from app.ingest.slack   import SlackConnector
    from app.ingest.chunker import chunk_records

    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )
    chunks = chunk_records(records)

    matrix, ids = embed_chunks(chunks)
    save_vectors(matrix, ids)

    print(f"\nMatrix shape : {matrix.shape}")
    print(f"Chunk ids    : {len(ids)}")
    print(f"Size on disk : {VECTOR_STORE_PATH.stat().st_size / 1024:.1f} KB")