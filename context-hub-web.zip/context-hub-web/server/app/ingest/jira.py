"""
Jira connector.
Reads jira.json from the corpus and returns list[RawRecord].
Comments are folded into the issue body — one RawRecord per issue.
"""

import json
from pathlib import Path
from app.ingest.base import RawRecord

CORPUS_PATH = Path(__file__).parent.parent / "synth" / "corpus" / "jira.json"

PROJECT_DOMAINS = {
    "PAY":  "Billing & Payments",
    "IDN":  "Identity & Auth",
    "DATA": "Data Platform",
    "SUP":  "Customer Support",
}


def _domain(key: str) -> str:
    project = key.split("-")[0] if "-" in key else key
    return PROJECT_DOMAINS.get(project, "Engineering")


def _build_body(issue: dict) -> str:
    """Fold issue fields and comments into one searchable text body."""
    parts = [
        f"{issue['key']}: {issue['title']}",
        f"Type: {issue['type']} | Priority: {issue['priority']} | Status: {issue['status']}",
        f"Reporter: {issue['reporter']} | Assignee: {issue['assignee']}",
        f"\n{issue.get('description', '')}",
    ]

    if issue.get("pr_refs"):
        parts.append(f"\nLinked PRs: {', '.join(issue['pr_refs'])}")

    comments = issue.get("comments", [])
    if comments:
        parts.append("\n── Comments ──")
        for c in comments:
            parts.append(f"{c['author']} [{c['created_at']}]: {c['body']}")

    return "\n".join(parts)


class JiraConnector:
    def fetch(self) -> list[RawRecord]:
        raw = json.loads(CORPUS_PATH.read_text())
        records: list[RawRecord] = []

        for issue in raw.get("issues", []):
            records.append(RawRecord(
                id=f"jira:{issue['id']}",
                source="jira",
                source_ref=issue["id"],
                title=f"{issue['key']}: {issue['title']}",
                body=_build_body(issue),
                author_raw=issue["reporter"],
                created_at=issue["created_at"],
                classification=issue.get("classification", "internal"),
                domain=_domain(issue["key"]),
                metadata={
                    "type":       "jira_issue",
                    "key":        issue["key"],
                    "project":    issue["project"],
                    "issue_type": issue["type"],
                    "status":     issue["status"],
                    "priority":   issue["priority"],
                    "assignee":   issue["assignee"],
                    "pr_refs":    issue.get("pr_refs", []),
                    "resolved_at":issue.get("resolved_at"),
                },
            ))

        return records


if __name__ == "__main__":
    records = JiraConnector().fetch()
    print(f"Jira records: {len(records)}")

    pay2871 = next((r for r in records if "PAY-2871" in r.title), None)
    print(f"  PAY-2871        : {'✓ ' + pay2871.id if pay2871 else 'MISSING'}")

    has_pr_ref = pay2871 and "PR #3182" in pay2871.body
    print(f"  PR #3182 in body: {'✓' if has_pr_ref else 'MISSING'}")

    projects = {}
    for r in records:
        p = r.metadata["project"]
        projects[p] = projects.get(p, 0) + 1
    for p, count in sorted(projects.items()):
        print(f"  {p}: {count} issues")