"""
Token-window chunker.
Splits RawRecord bodies into overlapping token windows.
Each chunk becomes one row in the chunks table.
"""

import uuid
import hashlib
from dataclasses import dataclass
from app.ingest.base import RawRecord
from app.config import settings


@dataclass
class Chunk:
    id: str
    document_id: str        # RawRecord.id
    ordinal: int            # position within the document
    text: str               # chunk text
    token_count: int
    source: str             # inherited from RawRecord
    classification: str     # inherited from RawRecord
    domain: str             # inherited from RawRecord
    author_raw: str         # inherited from RawRecord
    created_at: str         # inherited from RawRecord
    metadata: dict          # inherited from RawRecord


def _tokenize(text: str) -> list[str]:
    """
    Whitespace tokenizer — fast and deterministic.
    Good enough for windowing; embedder uses its own tokenizer.
    """
    return text.split()


def chunk_record(record: RawRecord) -> list[Chunk]:
    tokens  = _tokenize(record.body)
    size    = settings.chunk_tokens
    overlap = settings.chunk_overlap
    min_tok = settings.min_chunk_tokens

    if len(tokens) < min_tok:
        return []

    chunks  = []
    start   = 0
    ordinal = 0

    while start < len(tokens):
        end    = min(start + size, len(tokens))
        window = tokens[start:end]

        if len(window) >= min_tok:
            text = " ".join(window)

            # Deterministic ID — derived from document + position
            chunk_id = hashlib.md5(
                f"{record.id}:{ordinal}".encode()
            ).hexdigest()

            chunks.append(Chunk(
                id=chunk_id,
                document_id=record.id,
                ordinal=ordinal,
                text=text,
                token_count=len(window),
                source=record.source,
                classification=record.classification,
                domain=record.domain,
                author_raw=record.author_raw,
                created_at=record.created_at,
                metadata=record.metadata,
            ))
            ordinal += 1

        if end == len(tokens):
            break
        start += size - overlap

    return chunks

def chunk_records(records: list[RawRecord]) -> list[Chunk]:
    """Chunk all records, return flat list."""
    all_chunks = []
    for record in records:
        all_chunks.extend(chunk_record(record))
    return all_chunks


if __name__ == "__main__":
    from app.ingest.github import GitHubConnector
    from app.ingest.jira   import JiraConnector
    from app.ingest.slack  import SlackConnector

    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )

    chunks = chunk_records(records)

    print(f"Records : {len(records)}")
    print(f"Chunks  : {len(chunks)}")

    by_source = {}
    for c in chunks:
        by_source[c.source] = by_source.get(c.source, 0) + 1
    for src, count in sorted(by_source.items()):
        print(f"  {src}: {count} chunks")

    token_counts = [c.token_count for c in chunks]
    print(f"\nToken stats:")
    print(f"  Min : {min(token_counts)}")
    print(f"  Max : {max(token_counts)}")
    print(f"  Avg : {sum(token_counts) // len(token_counts)}")