"""
GitHub connector.
Reads github.json from the corpus and returns list[RawRecord].
"""

import json
from pathlib import Path
from app.ingest.base import RawRecord

CORPUS_PATH = Path(__file__).parent.parent / "synth" / "corpus" / "github.json"

SERVICE_DOMAINS = {
    "billing-service": "Billing & Payments",
    "identity-api":    "Identity & Auth",
    "data-loader":     "Data Platform",
    "gateway":         "Infrastructure",
    "scheduler":       "Infrastructure",
}


def _domain(repo: str) -> str:
    return SERVICE_DOMAINS.get(repo, "Engineering")


class GitHubConnector:
    def fetch(self) -> list[RawRecord]:
        raw = json.loads(CORPUS_PATH.read_text())
        records: list[RawRecord] = []

        # Documents — RFCs, ADRs, runbooks
        for doc in raw.get("documents", []):
            records.append(RawRecord(
                id=f"github:{doc['id']}",
                source="github",
                source_ref=doc["id"],
                title=doc["title"],
                body=doc["body"],
                author_raw=doc["author"],
                created_at=doc["created_at"],
                classification=doc.get("classification", "internal"),
                domain=_domain(doc.get("repo", "")),
                metadata={
                    "type": doc.get("type"),
                    "repo": doc.get("repo"),
                    "path": doc.get("path"),
                    "trust": doc.get("trust", 1.0),
                },
            ))

        # Pull requests
        for pr in raw.get("pull_requests", []):
            body = (
                f"PR #{pr['number']}: {pr['title']}\n\n"
                f"{pr.get('body', '')}\n\n"
                f"Author: {pr['author']} | State: {pr['state']} | "
                f"Repo: {pr['repo']}"
            )
            records.append(RawRecord(
                id=f"github:pr_{pr['number']}",
                source="github",
                source_ref=f"pr_{pr['number']}",
                title=f"PR #{pr['number']}: {pr['title']}",
                body=body,
                author_raw=pr["author"],
                created_at=pr["created_at"],
                classification=pr.get("classification", "internal"),
                domain=_domain(pr.get("repo", "")),
                metadata={
                    "type": "pull_request",
                    "number": pr["number"],
                    "repo": pr["repo"],
                    "state": pr["state"],
                    "jira_refs": pr.get("jira_refs", []),
                    "merged_at": pr.get("merged_at"),
                },
            ))

        return records


if __name__ == "__main__":
    records = GitHubConnector().fetch()
    print(f"GitHub records: {len(records)}")
    docs = [r for r in records if r.metadata.get("type") != "pull_request"]
    prs  = [r for r in records if r.metadata.get("type") == "pull_request"]
    print(f"  Documents : {len(docs)}")
    print(f"  PRs       : {len(prs)}")
    rfc = next((r for r in records if "RFC-114" in r.title), None)
    print(f"  RFC-114   : {'✓ ' + rfc.id if rfc else 'MISSING'}")
    pr3182 = next((r for r in records if r.source_ref == "pr_3182"), None)
    print(f"  PR #3182  : {'✓ ' + pr3182.id if pr3182 else 'MISSING'}")