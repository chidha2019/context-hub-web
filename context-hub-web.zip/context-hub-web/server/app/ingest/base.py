"""
Base types for the ingestion pipeline.
Every source connector produces list[RawRecord].
The rest of the pipeline never knows which source it came from.
"""

from dataclasses import dataclass, field
from typing import Protocol


@dataclass
class RawRecord:
    """
    Normalised unit of content from any source.
    One document, one PR, one Jira issue, one Slack message = one RawRecord.
    """
    id: str                          # globally unique e.g. "github:pr_3182"
    source: str                      # "github" | "jira" | "slack"
    source_ref: str                  # original id in the source system
    title: str                       # short label for the record
    body: str                        # full text content to be chunked
    author_raw: str                  # name as it appears in the source
    created_at: str                  # ISO timestamp
    classification: str              # "public" | "internal" | "confidential"
    domain: str                      # e.g. "Billing & Payments"
    metadata: dict = field(default_factory=dict)  # source-specific extras


class Connector(Protocol):
    """
    Every source connector must implement fetch().
    Returns a flat list of RawRecords — no source-specific types leak out.
    """
    def fetch(self) -> list[RawRecord]:
        ...