"""
Entity resolver.
Extracts named entities from RawRecords and resolves cross-source
identity collisions using fuzzy string similarity + confidence banding.

Bands (from config):
    score >= 0.90  -> auto-merge (silent)
    score 0.65-0.90 -> steward queue (human review)
    score < 0.65   -> discard
"""

import uuid
import json
from dataclasses import dataclass, field
from rapidfuzz import fuzz
from app.ingest.base import RawRecord
from app.config import settings

# ── Entity types ──────────────────────────────────────────────────────────────

@dataclass
class Entity:
    id: str
    type: str                        # Person | Service | Customer
    canonical_name: str
    aliases: list[dict]              # {source, raw_name, confidence, resolved_by}
    steward_state: str = "auto"      # auto | pending | approved | rejected
    attrs: dict = field(default_factory=dict)


@dataclass
class ReviewItem:
    id: str
    type: str                        # "entity_merge"
    title: str
    proposal: dict
    confidence: float
    state: str = "pending"
    origin: str = "resolver"


# ── Known entity seeds ────────────────────────────────────────────────────────
# These are the ground-truth names per source from the corpus.
# The resolver doesn't use these directly — it extracts names from
# records and matches them. These seeds initialise canonical nodes.

PERSON_SEEDS = [
    {"canonical": "Ana Rivera",    "github": "arivera",  "jira": "Ana Rivera",    "slack": "@ana"},
    {"canonical": "Michael Chen",  "github": "mchen",    "jira": "Michael Chen",  "slack": "@mike.c"},
    {"canonical": "Priya Krishnan","github": "priya-k",  "jira": "Priya Krishnan","slack": "@priya"},
    {"canonical": "James Doe",     "github": "jdoe",     "jira": "James Doe",     "slack": "@james"},
    {"canonical": "Li Wang",       "github": "lwang",    "jira": "Li Wang",       "slack": "@li"},
    {"canonical": "Sara Torres",   "github": "sara-t",   "jira": "Sara Torres",   "slack": "@sara"},
    {"canonical": "Emeka Okafor",  "github": "okafor-e", "jira": "Emeka Okafor",  "slack": "@emeka"},
    {"canonical": "Raj Bhat",      "github": "rbhat",    "jira": "Raj Bhat",      "slack": "@raj"},
    {"canonical": "Nina Fiore",    "github": "nfiore",   "jira": "Nina Fiore",    "slack": "@nina"},
    {"canonical": "Daniel Park",   "github": "dpark",    "jira": "Daniel Park",   "slack": "@dan"},
]

SERVICE_SEEDS = [
    {"canonical": "billing-service", "github": "billing-service", "jira": "Billing Service",  "slack": "#billing"},
    {"canonical": "identity-api",    "github": "identity-api",    "jira": "Identity API",      "slack": "#identity"},
    {"canonical": "data-loader",     "github": "data-loader",     "jira": "Data Loader",       "slack": "#data-platform"},
    {"canonical": "gateway",         "github": "gateway",         "jira": "API Gateway",       "slack": "#gateway"},
    {"canonical": "scheduler",       "github": "scheduler",       "jira": "Job Scheduler",     "slack": "#infra"},
]

CUSTOMER_SEEDS = [
    {"canonical": "Acme Corp",      "jira": "Acme Corp",      "slack": "ACME CORPORATION", "code": "acct_acme_prod"},
    {"canonical": "Brightline Inc", "jira": "Brightline Inc", "slack": "BRIGHTLINE INC",   "code": "acct_bright_prod"},
    {"canonical": "Vertex Systems", "jira": "Vertex Systems", "slack": "VERTEX SYSTEMS",   "code": "acct_vertex_prod"},
]


# ── Similarity scoring ────────────────────────────────────────────────────────

def _similarity(a: str, b: str) -> float:
    """
    Normalised similarity — handles slack @handles and github slugs.
    Strips @ prefix and compares cleaned versions.
    """
    def clean(s: str) -> str:
        s = s.lower().strip()
        s = s.lstrip("@").lstrip("#")   # strip slack/channel prefix
        s = s.replace("-", " ").replace(".", " ").replace("_", " ")
        return s

    a_clean = clean(a)
    b_clean = clean(b)

    score1 = fuzz.token_set_ratio(a_clean, b_clean) / 100.0
    score2 = fuzz.partial_ratio(a_clean, b_clean) / 100.0
    return max(score1, score2)


def _best_score(raw_name: str, seed: dict) -> float:
    """Score raw_name against all known aliases for a seed."""
    aliases = [v for k, v in seed.items() if k != "canonical"]
    scores  = [_similarity(raw_name, alias) for alias in aliases]
    return max(scores) if scores else 0.0


# ── Extractor ─────────────────────────────────────────────────────────────────

def _extract_raw_names(records: list[RawRecord]) -> dict[str, list[tuple[str, str]]]:
    """
    Extract raw author names per source.
    Returns {source -> [(raw_name, record_id), ...]}
    """
    by_source: dict[str, list[tuple[str, str]]] = {}
    for r in records:
        names = by_source.setdefault(r.source, [])
        if r.author_raw:
            for name in r.author_raw.split(", "):
                name = name.strip()
                if name:
                    names.append((name, r.id))
    return by_source


# ── Resolver ──────────────────────────────────────────────────────────────────

def resolve_entities(
    records: list[RawRecord],
) -> tuple[list[Entity], list[ReviewItem]]:
    """
    Main resolver.
    Returns:
        entities    — resolved Entity nodes (auto-merged)
        review_items — ambiguous pairs for the steward queue
    """
    entities: list[Entity] = []
    review_items: list[ReviewItem] = []

    def resolve_seeds(seeds: list[dict], entity_type: str):
        for seed in seeds:
            canonical = seed["canonical"]
            entity_id = str(uuid.uuid4())
            aliases   = []

            for source, raw_name in seed.items():
                if source == "canonical":
                    continue

                score = _similarity(raw_name, canonical)

                if score >= settings.er_auto_merge:
                    # Auto-merge
                    aliases.append({
                        "source":      source,
                        "raw_name":    raw_name,
                        "confidence":  round(score, 3),
                        "resolved_by": "auto",
                    })

                elif score >= settings.er_review_low:
                    # Steward queue
                    review_items.append(ReviewItem(
                        id=str(uuid.uuid4()),
                        type="entity_merge",
                        title=f"Merge '{raw_name}' → '{canonical}'?",
                        proposal={
                            "entity_type":   entity_type,
                            "canonical":     canonical,
                            "raw_name":      raw_name,
                            "source":        source,
                            "entity_id":     entity_id,
                        },
                        confidence=round(score, 3),
                        state="pending",
                        origin="resolver",
                    ))

                # Below er_review_low — discard silently

            entities.append(Entity(
                id=entity_id,
                type=entity_type,
                canonical_name=canonical,
                aliases=aliases,
                steward_state="auto",
            ))

    resolve_seeds(PERSON_SEEDS,   "Person")
    resolve_seeds(SERVICE_SEEDS,  "Service")
    resolve_seeds(CUSTOMER_SEEDS, "Customer")

    return entities, review_items


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    from app.ingest.github import GitHubConnector
    from app.ingest.jira   import JiraConnector
    from app.ingest.slack  import SlackConnector

    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )

    entities, review_items = resolve_entities(records)

    print(f"Entities resolved : {len(entities)}")
    print(f"Review queue      : {len(review_items)}")

    by_type = {}
    for e in entities:
        by_type[e.type] = by_type.get(e.type, 0) + 1
    for t, count in sorted(by_type.items()):
        print(f"  {t}: {count}")

    print(f"\nAuto-merged aliases:")
    for e in entities:
        if e.aliases:
            alias_str = ", ".join(
                f"{a['source']}:{a['raw_name']}({a['confidence']})"
                for a in e.aliases
            )
            print(f"  {e.canonical_name} <- {alias_str}")

    print(f"\nSteward queue items:")
    for item in review_items:
        print(f"  [{item.confidence}] {item.title}")

    # M2-1 verification
    ana = next((e for e in entities
                if e.canonical_name == "Ana Rivera"), None)
    aliases_found = {a["source"]: a["raw_name"]
                     for a in (ana.aliases if ana else [])}
    print(f"\nM2-1 Ana Rivera resolution:")
    print(f"  github : {aliases_found.get('github', 'MISSING')}")
    print(f"  jira   : {aliases_found.get('jira',   'MISSING')}")
    print(f"  slack  : {aliases_found.get('slack',  'MISSING')}")