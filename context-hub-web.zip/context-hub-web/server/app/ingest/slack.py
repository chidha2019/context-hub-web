"""
Slack connector.
Reads slack.json from the corpus and returns list[RawRecord].
One RawRecord per message — classification inherited from channel.
"""

import json
from pathlib import Path
from app.ingest.base import RawRecord

CORPUS_PATH = Path(__file__).parent.parent / "synth" / "corpus" / "slack.json"

CHANNEL_DOMAINS = {
    "billing":           "Billing & Payments",
    "identity":          "Identity & Auth",
    "data-platform":     "Data Platform",
    "gateway":           "Infrastructure",
    "infra":             "Infrastructure",
    "general":           "Engineering",
    "support":           "Customer Support",
    "payments-security": "Billing & Payments",
}


def _domain(channel_name: str) -> str:
    return CHANNEL_DOMAINS.get(channel_name, "Engineering")


class SlackConnector:
    def fetch(self) -> list[RawRecord]:
        raw = json.loads(CORPUS_PATH.read_text())
        channels = {c["id"]: c for c in raw.get("channels", [])}

        # Group messages by channel
        channel_messages: dict[str, list[dict]] = {}
        for msg in raw.get("messages", []):
            cid = msg["channel_id"]
            channel_messages.setdefault(cid, []).append(msg)

        records: list[RawRecord] = []

        for cid, messages in channel_messages.items():
            channel = channels.get(cid, {})
            channel_name = channel.get("name", "unknown")

            # Sort by timestamp
            messages = sorted(messages, key=lambda m: m["created_at"])

            # Collect all tags across messages in this channel
            all_tags = []
            for m in messages:
                all_tags.extend(m.get("tags", []))

            # Build one body per channel — all messages concatenated
            lines = [f"{m['author']}: {m['body']}" for m in messages]
            body = f"[#{channel_name}]\n" + "\n".join(lines)

            # Use earliest message id as source_ref
            first_msg = messages[0]

            records.append(RawRecord(
                id=f"slack:channel_{cid}",
                source="slack",
                source_ref=f"channel_{cid}",
                title=f"Slack / #{channel_name}",
                body=body,
                author_raw=", ".join({m["author"] for m in messages}),
                created_at=first_msg["created_at"],
                classification=channel.get("classification", "internal"),
                domain=_domain(channel_name),
                metadata={
                    "type":         "slack_channel",
                    "channel_id":   cid,
                    "channel_name": channel_name,
                    "message_count": len(messages),
                    "tags":         list(set(all_tags)),
                },
            ))

        return records

if __name__ == "__main__":
    records = SlackConnector().fetch()

    confidential = [r for r in records if r.classification == "confidential"]
    pii_tagged   = [r for r in records if "pii" in r.metadata.get("tags", [])]
    injections   = [r for r in records if "injection" in r.metadata.get("tags", [])]
    contradict   = [r for r in records if "contradiction" in r.metadata.get("tags", [])]

    print(f"Slack channel records : {len(records)}")
    print(f"  Confidential        : {len(confidential)}")
    print(f"  PII tagged          : {len(pii_tagged)}")
    print(f"  Injections          : {len(injections)}")
    print(f"  Contradictions      : {len(contradict)}")

    print(f"\nChannel sizes:")
    for r in sorted(records, key=lambda r: r.metadata["channel_name"]):
        ch = r.metadata["channel_name"]
        count = r.metadata["message_count"]
        cls = r.classification
        from app.ingest.chunker import _tokenize
        tokens = len(_tokenize(r.body))
        print(f"  #{ch}: {count} msgs, {tokens} tokens, {cls}")