"""
Bedrock LLM client.
Streaming synthesis with grounded prompt.
Falls back to extractive answer when LLM_ENABLED=false or credentials fail.
"""

import json
import boto3
from typing import Generator
from app.config import settings
from app.retrieval.hybrid import RankedChunk, GovernedResult
from app.llm.prompts import build_system_prompt, build_user_prompt


# ── Bedrock client ────────────────────────────────────────────────────────────

def _get_bedrock_client():
    return boto3.client(
        "bedrock-runtime",
        region_name=settings.aws_region,
    )


# ── Streaming synthesis ───────────────────────────────────────────────────────

def stream_answer(
    query: str,
    result: GovernedResult,
) -> Generator[dict, None, None]:
    """
    Stream a grounded answer from Bedrock.
    Yields dicts with type: trace | chunks | guardrails | token | done

    Matches the SSE event types Ask.tsx already expects.
    """

    # 1. Emit trace
    yield {
        "type": "trace",
        "data": {
            "bm25_count":    result.trace.bm25_count,
            "vector_count":  result.trace.vector_count,
            "graph_count":   result.trace.graph_count,
            "fused_count":   result.trace.fused_count,
            "final_count":   result.trace.final_count,
            "denied_count":  result.acl_denied_count,
            "denied_sources":result.acl_denied_sources,
        }
    }

    # 2. Emit chunks
    yield {
        "type": "chunks",
        "data": [
            {
                "index":       i + 1,
                "document_id": r.chunk.document_id,
                "source":      r.chunk.source,
                "trust":       r.trust_score,
                "text":        result.clean_texts.get(r.chunk.id, r.chunk.text)[:300],
            }
            for i, r in enumerate(result.chunks)
        ]
    }

    # 3. Emit guardrails
    yield {
        "type": "guardrails",
        "data": {
            "injection_blocked": result.injection_blocked,
            "pii_counts":        result.pii_counts,
            "total_pii_masked":  sum(result.pii_counts.values()),
            "acl_denied":        result.acl_denied_count,
        }
    }

    # 4. LLM synthesis or offline fallback
    if not settings.llm_enabled or not result.chunks:
        yield from _offline_fallback(query, result)
        return

    try:
        yield from _bedrock_stream(query, result)
    except Exception as e:
        print(f"Bedrock error: {e} — falling back to extractive answer")
        yield from _offline_fallback(query, result)


def _bedrock_stream(
    query: str,
    result: GovernedResult,
) -> Generator[dict, None, None]:
    """Stream tokens from Bedrock Claude."""
    client = _get_bedrock_client()

    system_prompt = build_system_prompt()
    user_prompt   = build_user_prompt(
        query=query,
        chunks=result.chunks,
        clean_texts=result.clean_texts,
        denied_count=result.acl_denied_count,
        denied_sources=result.acl_denied_sources,
    )

    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens":        settings.llm_max_tokens,
        "system":            system_prompt,
        "messages": [
            {"role": "user", "content": user_prompt}
        ],
    })

    response = client.invoke_model_with_response_stream(
        modelId=settings.llm_model,
        body=body,
        contentType="application/json",
        accept="application/json",
    )

    for event in response["body"]:
        chunk = json.loads(event["chunk"]["bytes"])
        if chunk.get("type") == "content_block_delta":
            delta = chunk.get("delta", {})
            if delta.get("type") == "text_delta":
                yield {"type": "token", "data": delta.get("text", "")}

    yield {"type": "done", "data": {"model": settings.llm_model}}


def _offline_fallback(
    query: str,
    result: GovernedResult,
) -> Generator[dict, None, None]:
    """
    Extractive fallback — assembles an answer from chunk text directly.
    No LLM call. Produces a grounded answer the demo can survive on.
    """
    if not result.chunks:
        text = "No context available for this query under your current access level."
        if result.acl_denied_count > 0:
            text += (f" {result.acl_denied_count} source(s) were withheld by policy: "
                     f"{', '.join(result.acl_denied_sources)}.")
    else:
        lines = ["Based on the available context:\n"]
        for i, ranked in enumerate(result.chunks[:4], start=1):
            clean = result.clean_texts.get(ranked.chunk.id, ranked.chunk.text)
            excerpt = clean[:200].strip()
            lines.append(f"[{i}] {excerpt}...")

        if result.acl_denied_count > 0:
            lines.append(
                f"\nNote: {result.acl_denied_count} additional source(s) were "
                f"withheld by access control policy."
            )
        text = "\n".join(lines)

    # Stream as tokens word by word
    for word in text.split():
        yield {"type": "token", "data": word + " "}

    yield {"type": "done", "data": {"model": "offline-fallback"}}


# ── Citation validator ────────────────────────────────────────────────────────

def validate_citations(answer: str, chunks: list[RankedChunk]) -> dict:
    """
    M4-1: Verify every [n] in the answer resolves to a real chunk.
    Returns {valid: bool, bad_citations: list[int]}
    """
    import re
    cited = [int(m) for m in re.findall(r"\[(\d+)\]", answer)]
    valid_indices = set(range(1, len(chunks) + 1))
    bad = [n for n in cited if n not in valid_indices]
    return {
        "valid": len(bad) == 0,
        "cited": cited,
        "bad_citations": bad,
    }


if __name__ == "__main__":
    from app.retrieval.hybrid import retrieve_governed
    from app.db import init_db

    init_db()

    QUERY = "Who owns the billing retry logic and what is the current retry policy?"

    print(f"Query: {QUERY}\n")

    for persona in ["data-engineer", "citizen"]:
        print(f"── Persona: {persona} ───────────────────────────────────────")
        result = retrieve_governed(QUERY, persona)

        full_answer = ""
        for event in stream_answer(QUERY, result):
            if event["type"] == "trace":
                print(f"  Trace: {event['data']['final_count']} chunks, "
                      f"{event['data']['denied_count']} denied")
            elif event["type"] == "chunks":
                print(f"  Chunks: {len(event['data'])}")
                for c in event["data"][:3]:
                    print(f"    [{c['index']}] {c['document_id']} "
                          f"trust={c['trust']}")
            elif event["type"] == "guardrails":
                print(f"  Guardrails: pii={event['data']['total_pii_masked']} "
                      f"acl_denied={event['data']['acl_denied']}")
            elif event["type"] == "token":
                full_answer += event["data"]
                print(event["data"], end="", flush=True)
            elif event["type"] == "done":
                print(f"\n  Model: {event['data']['model']}")

        print(f"\n  Answer length: {len(full_answer)} chars")

        # M4-1 citation check
        check = validate_citations(full_answer, result.chunks)
        print(f"  M4-1 citations valid: {'✓' if check['valid'] else 'FAIL'}")
        if check["bad_citations"]:
            print(f"  Bad citations: {check['bad_citations']}")
        print()