import json
from pathlib import Path

from fastapi import APIRouter

from app.db import get_connection

router = APIRouter()

CORPUS_DIR = Path(__file__).parent.parent / "synth" / "corpus"

SOURCE_NAMES = {
    "github": "GitHub",
    "jira": "Jira",
    "slack": "Slack",
}


def _corpus_generated_at() -> str:
    raw = json.loads((CORPUS_DIR / "github.json").read_text())
    return raw.get("generated_at", "")


@router.get("/api/sources")
def sources():
    con = get_connection()
    try:
        doc_rows = con.execute(
            "SELECT source, classification, COUNT(*) FROM documents GROUP BY source, classification"
        ).fetchall()
        chunk_rows = con.execute(
            """
            SELECT d.source, COUNT(*) FROM chunks c
            JOIN documents d ON d.id = c.document_id
            GROUP BY d.source
            """
        ).fetchall()
    finally:
        con.close()

    document_counts: dict[str, int] = {}
    classifications: dict[str, dict[str, int]] = {}
    for source, classification, count in doc_rows:
        document_counts[source] = document_counts.get(source, 0) + count
        classifications.setdefault(source, {})[classification] = count

    chunk_counts = {source: count for source, count in chunk_rows}

    connectors = [
        {
            "id": source_id,
            "name": name,
            "document_count": document_counts.get(source_id, 0),
            "chunk_count": chunk_counts.get(source_id, 0),
            "classifications": classifications.get(source_id, {}),
        }
        for source_id, name in SOURCE_NAMES.items()
    ]

    return {
        "connectors": connectors,
        "corpus_generated_at": _corpus_generated_at(),
    }
