from fastapi import APIRouter, Header

from app.db import get_connection
from app.governance.acl import get_policy

router = APIRouter()


def _resolve_external_node(con, node_id: str) -> dict:
    """
    Resolve a node id referenced by an edge but not present in `entities` —
    these are GitHub document/PR ids (match `documents.id` directly) or
    synthetic Jira issue-stub ids minted by build_graph() (e.g. "jira:pay_2871"),
    which do NOT match any `documents.id` and have to be re-derived.
    """
    row = con.execute(
        "SELECT title, source, classification FROM documents WHERE id = ?", (node_id,)
    ).fetchone()
    if row:
        title, source, classification = row
        return {"type": "Document", "label": title, "source": source, "classification": classification}

    if node_id.startswith("jira:"):
        key = node_id[len("jira:"):].upper().replace("_", "-")
        row = con.execute(
            "SELECT title, classification FROM documents WHERE source = 'jira' AND title LIKE ? LIMIT 1",
            (f"{key}: %",),
        ).fetchone()
        classification = row[1] if row else "internal"
        return {"type": "Issue", "label": key, "source": "jira", "classification": classification}

    source = node_id.split(":", 1)[0] if ":" in node_id else "unknown"
    return {"type": "Document", "label": node_id, "source": source, "classification": "internal"}


def get_governed_graph(persona: str) -> dict:
    """
    The single governed graph assembly used by both GET /api/graph and the MCP
    graph.walk tool — ACL-filtered the same way for both callers.
    """
    policy = get_policy(persona)
    con = get_connection()
    try:
        entity_rows = con.execute(
            "SELECT id, type, canonical_name FROM entities"
        ).fetchall()
        alias_rows = con.execute(
            "SELECT entity_id, source, raw_name FROM aliases"
        ).fetchall()
        edge_rows = con.execute(
            "SELECT src_id, dst_id, rel FROM edges"
        ).fetchall()

        aliases_by_entity: dict[str, list[dict]] = {}
        for entity_id, source, raw_name in alias_rows:
            aliases_by_entity.setdefault(entity_id, []).append({"source": source, "raw_name": raw_name})

        nodes: dict[str, dict] = {}
        for entity_id, entity_type, canonical_name in entity_rows:
            nodes[entity_id] = {
                "id": entity_id,
                "type": entity_type,
                "label": canonical_name,
                "aliases": aliases_by_entity.get(entity_id, []),
            }

        entity_ids = set(nodes.keys())
        external_ids = {n for edge in edge_rows for n in (edge[0], edge[1])} - entity_ids
        for node_id in external_ids:
            resolved = _resolve_external_node(con, node_id)
            nodes[node_id] = {"id": node_id, **resolved}
    finally:
        con.close()

    def node_allowed(node: dict) -> bool:
        if "source" not in node:
            return True  # Person/Service/Customer entities aren't classified content
        return node["source"] in policy.allowed_sources and node["classification"] in policy.allowed_classifications

    allowed_ids = {node_id for node_id, node in nodes.items() if node_allowed(node)}

    degree: dict[str, int] = {}
    edges = []
    for src_id, dst_id, rel in edge_rows:
        if src_id not in allowed_ids or dst_id not in allowed_ids:
            continue
        degree[src_id] = degree.get(src_id, 0) + 1
        degree[dst_id] = degree.get(dst_id, 0) + 1
        edges.append({"source": src_id, "target": dst_id, "rel": rel})

    node_list = [
        {**nodes[node_id], "degree": degree.get(node_id, 0)}
        for node_id in allowed_ids
    ]

    return {"nodes": node_list, "edges": edges}


@router.get("/api/graph")
def graph(x_persona: str = Header(...)):
    return get_governed_graph(x_persona)
