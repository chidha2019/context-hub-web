from fastapi import APIRouter

from app.db import get_connection

router = APIRouter()


@router.get("/api/overview")
def overview():
    con = get_connection()
    try:
        entities = con.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
        relations = con.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
        served_24h = con.execute(
            "SELECT COUNT(*) FROM serve_events WHERE ts > datetime('now', '-1 day')"
        ).fetchone()[0]
    finally:
        con.close()

    return {"entities": entities, "relations": relations, "served_24h": served_24h}
