from fastapi import APIRouter

from app.governance.audit import get_recent_events, get_stats

router = APIRouter()


@router.get("/api/governance/audit")
def audit(limit: int = 50):
    return get_recent_events(limit=limit)


@router.get("/api/governance/stats")
def stats():
    return get_stats()
