import json

from fastapi import APIRouter, HTTPException

from app.db import get_connection

router = APIRouter()


@router.get("/api/steward/queue")
def queue():
    con = get_connection()
    try:
        rows = con.execute(
            """
            SELECT id, type, title, proposal_json, confidence, origin
            FROM review_queue WHERE state = 'pending'
            ORDER BY confidence DESC
            """
        ).fetchall()
    finally:
        con.close()

    return [
        {
            "id": row_id,
            "type": item_type,
            "title": title,
            "confidence": confidence,
            "origin": origin,
            "proposal": json.loads(proposal_json),
        }
        for row_id, item_type, title, proposal_json, confidence, origin in rows
    ]


def _get_pending_item(con, review_id: str) -> tuple[dict, float]:
    row = con.execute(
        "SELECT proposal_json, confidence FROM review_queue WHERE id = ? AND state = 'pending'",
        (review_id,),
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Review item not found or already resolved")
    return json.loads(row[0]), row[1]


@router.post("/api/steward/{review_id}/approve")
def approve(review_id: str):
    con = get_connection()
    try:
        proposal, confidence = _get_pending_item(con, review_id)
        con.execute(
            """
            INSERT INTO aliases (entity_id, source, raw_name, confidence, resolved_by)
            VALUES (?, ?, ?, ?, 'steward')
            """,
            (proposal["entity_id"], proposal["source"], proposal["raw_name"], confidence),
        )
        con.execute(
            "UPDATE entities SET steward_state = 'approved' WHERE id = ?", (proposal["entity_id"],)
        )
        con.execute(
            "UPDATE review_queue SET state = 'approved' WHERE id = ?", (review_id,)
        )
        con.commit()

        entity_row = con.execute(
            "SELECT id, type, canonical_name FROM entities WHERE id = ?", (proposal["entity_id"],)
        ).fetchone()
    finally:
        con.close()

    return {
        "id": review_id,
        "state": "approved",
        "entity": {"id": entity_row[0], "type": entity_row[1], "canonical_name": entity_row[2]},
    }


@router.post("/api/steward/{review_id}/reject")
def reject(review_id: str):
    con = get_connection()
    try:
        _get_pending_item(con, review_id)
        con.execute(
            "UPDATE review_queue SET state = 'rejected' WHERE id = ?", (review_id,)
        )
        con.commit()
    finally:
        con.close()

    return {"id": review_id, "state": "rejected"}
