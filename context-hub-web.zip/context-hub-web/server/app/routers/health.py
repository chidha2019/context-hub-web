from fastapi import APIRouter
from app.db import check_db_connection

router = APIRouter()

@router.get("/api/health")
def health():
    return {"status": "ok", "db": check_db_connection()}