from fastapi import APIRouter

from app.db import get_connection
from app.governance.audit import get_stats

router = APIRouter()


@router.get("/api/measure")
def measure():
    overall = get_stats()

    con = get_connection()
    try:
        rows = con.execute(
            """
            SELECT persona,
                   COUNT(*) AS requests,
                   AVG(latency_ms) AS avg_latency_ms,
                   SUM(pii_masked) AS pii_masked,
                   SUM(CASE WHEN acl = 'denied' THEN 1 ELSE 0 END) AS denied
            FROM serve_events
            GROUP BY persona
            ORDER BY requests DESC
            """
        ).fetchall()
    finally:
        con.close()

    by_persona = [
        {
            "persona": persona,
            "requests": requests,
            "avg_latency_ms": round(avg_latency_ms or 0),
            "pii_masked": pii_masked or 0,
            "denied": denied or 0,
        }
        for persona, requests, avg_latency_ms, pii_masked, denied in rows
    ]

    return {"overall": overall, "by_persona": by_persona}
