import json

from fastapi import APIRouter, Header, Request
from fastapi.responses import StreamingResponse

from app.models import AskRequest
from app.retrieval.hybrid import retrieve_governed
from app.llm.client import stream_answer

router = APIRouter()


def _sse_event(event_type: str, data: dict | list) -> str:
    return f"event: {event_type}\ndata: {json.dumps(data)}\n\n"


@router.post("/api/ask")
async def ask(request: Request, body: AskRequest, x_persona: str = Header(...)):
    def event_stream():
        result = retrieve_governed(body.query, x_persona)
        for event in stream_answer(body.query, result):
            yield _sse_event(event["type"], event["data"])

    return StreamingResponse(event_stream(), media_type="text/event-stream")
