from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.config import settings
from app.db import init_db
from app.governance.acl import POLICIES
from app.routers import health, ask, governance, sources, graph, steward, measure, overview

VALID_PERSONAS = set(POLICIES.keys())

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def persona_middleware(request: Request, call_next):
    excluded = {"/api/health"}
    if (
        request.method != "OPTIONS"
        and request.url.path.startswith("/api/")
        and request.url.path not in excluded
    ):
        persona = request.headers.get("X-Persona")
        if not persona or persona not in VALID_PERSONAS:
            return JSONResponse(status_code=400, content={"detail": "Missing or unknown X-Persona header"})
    return await call_next(request)

app.include_router(health.router)
app.include_router(ask.router)
app.include_router(governance.router)
app.include_router(sources.router)
app.include_router(graph.router)
app.include_router(steward.router)
app.include_router(measure.router)
app.include_router(overview.router)