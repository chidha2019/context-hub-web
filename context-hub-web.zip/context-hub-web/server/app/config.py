from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    seed: int = 20260831
    org_name: str = "Meridian Pay"
    api_port: int = 8080
    db_path: str = "./data/contexthub.db"
    cors_origins: list[str] = ["http://localhost:5173"]

    # Chunking
    chunk_tokens: int = 320
    chunk_overlap: int = 64
    min_chunk_tokens: int = 40

    # Embedding
    embed_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    embed_dim: int = 384
    embed_normalize: bool = True
    embed_batch: int = 64

    # Entity resolution
    er_auto_merge: float = 0.75
    er_review_low: float = 0.55

    # Trust scores by source
    trust_github_docs: float = 1.0
    trust_jira: float = 0.60
    trust_slack: float = 0.35

    # Graph
    graph_hops: int = 2
    graph_seed_max: int = 5

    # Retrieval
    bm25_top_k: int = 40
    vector_top_k: int = 40
    final_k: int = 8
    min_score: float = 0.01

    # LLM — Bedrock
    llm_model: str = "us.anthropic.claude-haiku-4-5-20251001-v1:0"
    llm_fallback_model: str = "us.anthropic.claude-haiku-4-5-20251001-v1:0"
    llm_max_tokens: int = 4096
    llm_enabled: bool = True
    aws_region: str = "us-east-1"

    class Config:
        env_prefix = "CH_"

settings = Settings()