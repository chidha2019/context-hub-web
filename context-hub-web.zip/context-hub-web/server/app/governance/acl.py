"""
Access Control Layer.
Defines persona policies and filters chunks before retrieval.
The filter runs BEFORE any search — restricted chunks never enter
the candidate set, so they cannot appear in results by accident.
"""

from dataclasses import dataclass
from app.ingest.chunker import Chunk


# ── Persona policies ──────────────────────────────────────────────────────────

@dataclass
class PersonaPolicy:
    persona_id: str
    display_name: str
    allowed_sources: set[str]
    allowed_classifications: set[str]
    pii_handling: str          # "masked" | "redacted"


POLICIES: dict[str, PersonaPolicy] = {
    "data-engineer": PersonaPolicy(
        persona_id="data-engineer",
        display_name="Data Engineer",
        allowed_sources={"github", "jira", "slack"},
        allowed_classifications={"public", "internal", "confidential"},
        pii_handling="masked",
    ),
    "digital-engineer": PersonaPolicy(
        persona_id="digital-engineer",
        display_name="Digital Engineer",
        allowed_sources={"github", "jira", "slack"},
        allowed_classifications={"public", "internal"},
        pii_handling="masked",
    ),
    "citizen": PersonaPolicy(
        persona_id="citizen",
        display_name="Citizen Developer",
        allowed_sources={"github", "jira"},
        allowed_classifications={"public", "internal"},
        pii_handling="redacted",
    ),
}


def get_policy(persona_id: str) -> PersonaPolicy:
    policy = POLICIES.get(persona_id)
    if not policy:
        raise ValueError(f"Unknown persona: {persona_id}")
    return policy


# ── ACL filter ────────────────────────────────────────────────────────────────

@dataclass
class AclResult:
    allowed: list[Chunk]
    denied_count: int
    denied_sources: list[str]
    denied_classifications: list[str]


def apply_acl(chunks: list[Chunk], persona_id: str) -> AclResult:
    """
    Filter chunks by persona policy.
    Returns allowed chunks and a summary of what was denied.
    Runs BEFORE retrieval — denied chunks never enter the search.
    """
    policy = get_policy(persona_id)
    allowed = []
    denied_sources = set()
    denied_classifications = set()

    for chunk in chunks:
        source_ok = chunk.source in policy.allowed_sources
        class_ok  = chunk.classification in policy.allowed_classifications

        if source_ok and class_ok:
            allowed.append(chunk)
        else:
            if not source_ok:
                denied_sources.add(chunk.source)
            if not class_ok:
                denied_classifications.add(chunk.classification)

    return AclResult(
        allowed=allowed,
        denied_count=len(chunks) - len(allowed),
        denied_sources=sorted(denied_sources),
        denied_classifications=sorted(denied_classifications),
    )


if __name__ == "__main__":
    from app.ingest.github import GitHubConnector
    from app.ingest.jira   import JiraConnector
    from app.ingest.slack  import SlackConnector
    from app.ingest.chunker import chunk_records

    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )
    chunks = chunk_records(records)

    print(f"Total chunks: {len(chunks)}")
    print()

    for persona_id in ["data-engineer", "digital-engineer", "citizen"]:
        result = apply_acl(chunks, persona_id)
        policy = get_policy(persona_id)
        print(f"Persona: {policy.display_name}")
        print(f"  Allowed  : {len(result.allowed)}")
        print(f"  Denied   : {result.denied_count}")
        if result.denied_sources:
            print(f"  Denied sources         : {result.denied_sources}")
        if result.denied_classifications:
            print(f"  Denied classifications : {result.denied_classifications}")
        print()