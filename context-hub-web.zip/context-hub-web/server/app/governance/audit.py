"""
Audit logger.
Writes a ServeEvent to the database for every query served.
This is the single source of truth behind the Governance screen,
the LiveFeed and the Measure counters.
"""

import time
from dataclasses import dataclass
from app.db import get_connection


# ── ServeEvent ────────────────────────────────────────────────────────────────

@dataclass
class ServeEvent:
    actor: str          # persona_id or agent identifier
    persona: str        # persona_id
    action: str         # "query"
    asset: str          # the query text
    acl: str            # "allowed" | "denied" | "blocked"
    pii_masked: int     # count of PII spans handled
    latency_ms: int     # end-to-end latency
    channel: str        # "http" | "mcp"


def write_event(event: ServeEvent) -> None:
    """Write one ServeEvent to the database."""
    con = get_connection()
    try:
        con.execute("""
            INSERT INTO serve_events
              (ts, actor, persona, action, asset, acl, pii_masked, latency_ms, channel)
            VALUES (datetime('now'), ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            event.actor,
            event.persona,
            event.action,
            event.asset,
            event.acl,
            event.pii_masked,
            event.latency_ms,
            event.channel,
        ))
        con.commit()
    finally:
        con.close()


def get_recent_events(limit: int = 50) -> list[dict]:
    """Fetch recent serve events for the Governance screen."""
    con = get_connection()
    try:
        cur = con.execute("""
            SELECT ts, actor, persona, action, asset,
                   acl, pii_masked, latency_ms, channel
            FROM serve_events
            ORDER BY ts DESC
            LIMIT ?
        """, (limit,))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]
    finally:
        con.close()


def get_stats() -> dict:
    """Derive summary stats for the Governance tiles."""
    con = get_connection()
    try:
        total     = con.execute("SELECT COUNT(*) FROM serve_events").fetchone()[0]
        allowed   = con.execute("SELECT COUNT(*) FROM serve_events WHERE acl='allowed'").fetchone()[0]
        denied    = con.execute("SELECT COUNT(*) FROM serve_events WHERE acl='denied'").fetchone()[0]
        blocked   = con.execute("SELECT COUNT(*) FROM serve_events WHERE acl='blocked'").fetchone()[0]
        pii_total = con.execute("SELECT SUM(pii_masked) FROM serve_events").fetchone()[0] or 0
        avg_lat   = con.execute("SELECT AVG(latency_ms) FROM serve_events").fetchone()[0] or 0
        mcp_count = con.execute("SELECT COUNT(*) FROM serve_events WHERE channel='mcp'").fetchone()[0]
        return {
            "total":     total,
            "allowed":   allowed,
            "denied":    denied,
            "blocked":   blocked,
            "pii_total": pii_total,
            "avg_latency_ms": round(avg_lat),
            "mcp_requests": mcp_count,
        }
    finally:
        con.close()


if __name__ == "__main__":
    from app.db import init_db
    init_db()

    # Write three test events — one per persona
    test_events = [
        ServeEvent(
            actor="data-engineer", persona="data-engineer",
            action="query", asset="Who owns the billing retry logic?",
            acl="allowed", pii_masked=3, latency_ms=142, channel="http",
        ),
        ServeEvent(
            actor="digital-engineer", persona="digital-engineer",
            action="query", asset="Who owns the billing retry logic?",
            acl="allowed", pii_masked=2, latency_ms=138, channel="http",
        ),
        ServeEvent(
            actor="citizen", persona="citizen",
            action="query", asset="Who owns the billing retry logic?",
            acl="denied", pii_masked=0, latency_ms=12, channel="http",
        ),
    ]

    for event in test_events:
        write_event(event)

    print("Wrote 3 test serve events")
    print()

    events = get_recent_events(limit=10)
    print(f"Recent events ({len(events)}):")
    for e in events:
        print(f"  [{e['acl']:7s}] {e['persona']:20s} pii={e['pii_masked']} "
              f"latency={e['latency_ms']}ms channel={e['channel']}")

    print()
    stats = get_stats()
    print("Stats:")
    for k, v in stats.items():
        print(f"  {k:20s}: {v}")

    print(f"\nM3-1 audit trail check:")
    print(f"  3 serve events written : {'✓' if stats['total'] >= 3 else 'FAIL'}")
    print(f"  allowed count >= 2     : {'✓' if stats['allowed'] >= 2 else 'FAIL'}")
    print(f"  denied count >= 1      : {'✓' if stats['denied'] >= 1 else 'FAIL'}")