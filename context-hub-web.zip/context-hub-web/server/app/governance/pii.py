"""
PII detector and masker.
Detects personal data in chunk text and masks or redacts it
depending on the persona's PII handling policy.

masked  -> partial replacement: a****@example.com (Data Engineer, Digital Engineer)
redacted -> full replacement:   [REDACTED:EMAIL]  (Citizen Developer)
"""

import re
from dataclasses import dataclass, field


# ── PII patterns ──────────────────────────────────────────────────────────────

PII_PATTERNS = {
    "email": re.compile(
        r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
        re.IGNORECASE,
    ),
    "phone_us": re.compile(
        r"\+?1?\s*[\(\-\.]?\d{3}[\)\-\.\s]\s*\d{3}[\-\.\s]\d{4}",
    ),
    "phone_intl": re.compile(
        r"\+\d{1,3}[\s\-]\d{1,4}[\s\-]\d{3,4}[\s\-]\d{3,4}",
    ),
    "pan_luhn": re.compile(
        r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|"
        r"3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12})\b",
    ),
    "iban": re.compile(
        r"\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}(?:[A-Z0-9]?){0,16}\b",
    ),
    "ipv4": re.compile(
        r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}"
        r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b",
    ),
}

PII_MIN_CONFIDENCE = 0.75


# ── Span tracking ─────────────────────────────────────────────────────────────

@dataclass
class PiiSpan:
    start: int
    end: int
    kind: str
    value: str
    confidence: float


@dataclass
class PiiResult:
    clean_text: str
    spans: list[PiiSpan] = field(default_factory=list)
    count: int = 0


# ── Masking helpers ───────────────────────────────────────────────────────────

def _mask_value(value: str, kind: str) -> str:
    """Partial masking — keeps shape, hides content."""
    if kind == "email":
        local, _, domain = value.partition("@")
        masked_local = local[0] + "*" * (len(local) - 1) if len(local) > 1 else "*"
        return f"{masked_local}@{domain}"
    if kind in ("phone_us", "phone_intl"):
        digits = re.sub(r"\D", "", value)
        return f"***-***-{digits[-4:]}" if len(digits) >= 4 else "***-***-****"
    if kind == "pan_luhn":
        return f"****-****-****-{value[-4:]}" if len(value) >= 4 else "****"
    if kind == "iban":
        return value[:4] + "*" * (len(value) - 8) + value[-4:]
    if kind == "ipv4":
        parts = value.split(".")
        return f"{parts[0]}.{parts[1]}.*.*"
    return "*" * len(value)


def _redact_value(kind: str) -> str:
    """Full redaction — removes content entirely."""
    return f"[REDACTED:{kind.upper()}]"


# ── Main detector ─────────────────────────────────────────────────────────────

def detect_and_apply(text: str, pii_handling: str) -> PiiResult:
    """
    Detect PII in text and apply masking or redaction.
    pii_handling: "masked" | "redacted"
    Returns clean text with PII handled, plus span metadata.
    """
    spans: list[PiiSpan] = []

    # Find all PII spans
    for kind, pattern in PII_PATTERNS.items():
        for match in pattern.finditer(text):
            spans.append(PiiSpan(
                start=match.start(),
                end=match.end(),
                kind=kind,
                value=match.group(0),
                confidence=0.90,
            ))

    # Filter by confidence
    spans = [s for s in spans if s.confidence >= PII_MIN_CONFIDENCE]

    if not spans:
        return PiiResult(clean_text=text, spans=[], count=0)

    # Sort by start position, remove overlaps
    spans.sort(key=lambda s: s.start)
    non_overlapping: list[PiiSpan] = []
    last_end = -1
    for span in spans:
        if span.start >= last_end:
            non_overlapping.append(span)
            last_end = span.end

    # Apply replacements right to left (preserves indices)
    clean = text
    for span in reversed(non_overlapping):
        if pii_handling == "masked":
            replacement = _mask_value(span.value, span.kind)
        else:
            replacement = _redact_value(span.kind)
        clean = clean[:span.start] + replacement + clean[span.end:]

    return PiiResult(
        clean_text=clean,
        spans=non_overlapping,
        count=len(non_overlapping),
    )


if __name__ == "__main__":
    from app.ingest.github  import GitHubConnector
    from app.ingest.jira    import JiraConnector
    from app.ingest.slack   import SlackConnector
    from app.ingest.chunker import chunk_records

    records = (
        GitHubConnector().fetch() +
        JiraConnector().fetch() +
        SlackConnector().fetch()
    )
    chunks = chunk_records(records)

    total_pii   = 0
    pii_chunks  = 0

    print("PII detection results")
    print("─" * 60)

    for chunk in chunks:
        result = detect_and_apply(chunk.text, "masked")
        if result.count > 0:
            pii_chunks += 1
            total_pii  += result.count
            print(f"\nChunk: {chunk.document_id}")
            for span in result.spans:
                print(f"  [{span.kind}] '{span.value}' → '{_mask_value(span.value, span.kind)}'")

    print(f"\n── Summary ──────────────────────────────")
    print(f"  Chunks with PII : {pii_chunks}")
    print(f"  Total PII spans : {total_pii}")

    # Redaction test
    test = "Contact john.smith@acmecorp.com or call +1-415-555-0192"
    masked   = detect_and_apply(test, "masked")
    redacted = detect_and_apply(test, "redacted")
    print(f"\n── Masking vs Redaction ─────────────────")
    print(f"  Original : {test}")
    print(f"  Masked   : {masked.clean_text}")
    print(f"  Redacted : {redacted.clean_text}")