"""
Pydantic response models for the /api/ask and /api/governance routes.
Mirrors src/types.ts where the two overlap.
"""

from pydantic import BaseModel


class AskRequest(BaseModel):
    query: str


class TraceInfo(BaseModel):
    bm25_count: int
    vector_count: int
    graph_count: int
    fused_count: int
    final_count: int
    denied_count: int
    denied_sources: list[str]


class AskChunk(BaseModel):
    index: int
    document_id: str
    source: str
    trust: float
    text: str


class GuardrailsInfo(BaseModel):
    injection_blocked: bool
    pii_counts: dict[str, int]
    total_pii_masked: int
    acl_denied: int


class ServeEventOut(BaseModel):
    ts: str
    actor: str
    persona: str
    action: str
    asset: str
    acl: str
    pii_masked: int
    latency_ms: int
    channel: str


class GovernanceStats(BaseModel):
    total: int
    allowed: int
    denied: int
    blocked: int
    pii_total: int
    avg_latency_ms: int
    mcp_requests: int
