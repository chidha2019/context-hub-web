import sqlite3
import os
from app.config import settings

def get_connection():
    os.makedirs(os.path.dirname(settings.db_path), exist_ok=True)
    return sqlite3.connect(settings.db_path)

def init_db():
    con = get_connection()
    cur = con.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS documents (
            id TEXT PRIMARY KEY, source TEXT, source_ref TEXT,
            title TEXT, body TEXT, author_raw TEXT,
            created_at TEXT, updated_at TEXT,
            classification TEXT, domain TEXT
        );
        CREATE TABLE IF NOT EXISTS chunks (
            id TEXT PRIMARY KEY, document_id TEXT, ordinal INTEGER,
            text TEXT, token_count INTEGER, trust REAL, embedding_row INTEGER
        );
        CREATE TABLE IF NOT EXISTS entities (
            id TEXT PRIMARY KEY, type TEXT, canonical_name TEXT,
            attrs_json TEXT, steward_state TEXT
        );
        CREATE TABLE IF NOT EXISTS aliases (
            entity_id TEXT, source TEXT, raw_name TEXT,
            confidence REAL, resolved_by TEXT
        );
        CREATE TABLE IF NOT EXISTS edges (
            src_id TEXT, dst_id TEXT, rel TEXT,
            weight REAL, provenance_doc_id TEXT
        );
        CREATE TABLE IF NOT EXISTS pii_spans (
            chunk_id TEXT, start INTEGER, end INTEGER,
            kind TEXT, confidence REAL
        );
        CREATE TABLE IF NOT EXISTS review_queue (
            id TEXT PRIMARY KEY, type TEXT, title TEXT,
            proposal_json TEXT, confidence REAL,
            state TEXT, origin TEXT
        );
        CREATE TABLE IF NOT EXISTS serve_events (
            ts TEXT, actor TEXT, persona TEXT, action TEXT,
            asset TEXT, acl TEXT, pii_masked INTEGER,
            latency_ms INTEGER, channel TEXT
        );
    """)
    con.commit()
    con.close()

def check_db_connection() -> bool:
    try:
        con = get_connection()
        con.execute("SELECT 1")
        con.close()
        return True
    except Exception:
        return False