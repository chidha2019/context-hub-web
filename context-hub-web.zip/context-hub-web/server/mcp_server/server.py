"""
ContextHub MCP server — stdio transport.

Persona is bound once at launch via the CH_MCP_PERSONA env var (POC-PLAN: "bound at launch
config, not chosen per call") — every tool call in this process serves that one persona.
Every tool goes through the same governed functions the HTTP API uses:
`retrieve_governed()` for graph.retrieve, `get_governed_graph()` for graph.walk/context.assets.
"""

import os
from collections import deque

from mcp.server.mcpserver import MCPServer

from app.governance.acl import POLICIES
from app.retrieval.hybrid import retrieve_governed
from app.routers.graph import get_governed_graph

PERSONA = os.environ.get("CH_MCP_PERSONA")
if not PERSONA or PERSONA not in POLICIES:
    raise RuntimeError(
        f"CH_MCP_PERSONA must be set to one of {sorted(POLICIES)} at launch "
        f"(got {PERSONA!r}). Persona is bound at server start, not per call."
    )

mcp = MCPServer("contexthub", version="0.1.0")


@mcp.tool(name="graph.retrieve", description="Governed hybrid retrieval over the ContextHub corpus")
def graph_retrieve(query: str, k: int = 8) -> dict:
    result = retrieve_governed(query, PERSONA, final_k=k, channel="mcp")
    return {
        "trace": {
            "bm25_count": result.trace.bm25_count,
            "vector_count": result.trace.vector_count,
            "graph_count": result.trace.graph_count,
            "fused_count": result.trace.fused_count,
            "final_count": result.trace.final_count,
            "denied_count": result.acl_denied_count,
            "denied_sources": result.acl_denied_sources,
        },
        "chunks": [
            {
                "index": i + 1,
                "document_id": r.chunk.document_id,
                "source": r.chunk.source,
                "trust": r.trust_score,
                "text": result.clean_texts.get(r.chunk.id, r.chunk.text)[:300],
            }
            for i, r in enumerate(result.chunks)
        ],
        "guardrails": {
            "injection_blocked": result.injection_blocked,
            "pii_counts": result.pii_counts,
            "total_pii_masked": sum(result.pii_counts.values()),
            "acl_denied": result.acl_denied_count,
        },
    }


def _resolve_entity(nodes: list[dict], entity: str) -> dict | None:
    needle = entity.strip().lower()
    for n in nodes:
        if n["id"] == entity:
            return n
    for n in nodes:
        if n["label"].lower() == needle:
            return n
    for n in nodes:
        for alias in n.get("aliases", []):
            if alias["raw_name"].lower() == needle:
                return n
    for n in nodes:
        if needle in n["label"].lower():
            return n
    return None


@mcp.tool(name="graph.walk", description="Governed N-hop neighborhood walk from an entity")
def graph_walk(entity: str, depth: int = 2) -> dict:
    graph = get_governed_graph(PERSONA)
    nodes_by_id = {n["id"]: n for n in graph["nodes"]}
    seed = _resolve_entity(graph["nodes"], entity)
    if seed is None:
        return {"nodes": [], "edges": [], "error": f"No node matching {entity!r} for this persona"}

    adjacency: dict[str, list[tuple[str, str]]] = {}
    for e in graph["edges"]:
        adjacency.setdefault(e["source"], []).append((e["target"], e["rel"]))
        adjacency.setdefault(e["target"], []).append((e["source"], e["rel"]))

    visited = {seed["id"]}
    frontier = deque([(seed["id"], 0)])
    while frontier:
        node_id, hop = frontier.popleft()
        if hop >= depth:
            continue
        for neighbor_id, _rel in adjacency.get(node_id, []):
            if neighbor_id not in visited:
                visited.add(neighbor_id)
                frontier.append((neighbor_id, hop + 1))

    walked_nodes = [nodes_by_id[n] for n in visited if n in nodes_by_id]
    walked_edges = [
        e for e in graph["edges"]
        if e["source"] in visited and e["target"] in visited
    ]
    return {"nodes": walked_nodes, "edges": walked_edges}


@mcp.tool(name="context.assets", description="Governed listing of documents and entities, optionally filtered")
def context_assets(filter: str | None = None) -> list[dict]:
    graph = get_governed_graph(PERSONA)
    needle = filter.strip().lower() if filter else None
    results = []
    for n in graph["nodes"]:
        if needle and needle not in n["label"].lower():
            continue
        asset = {"id": n["id"], "type": n["type"], "label": n["label"]}
        if "source" in n:
            asset["source"] = n["source"]
            asset["classification"] = n["classification"]
        results.append(asset)
    return results


if __name__ == "__main__":
    mcp.run()
