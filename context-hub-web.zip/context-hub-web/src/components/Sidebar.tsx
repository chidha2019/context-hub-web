import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard, Search, Network, Database, CheckSquare, Blocks, ShieldCheck,
  LineChart, Users, Settings, PanelLeftClose, PanelLeftOpen, Target, Boxes, Layers,
} from 'lucide-react'

const ITEMS = [
  { to: '/', label: 'Overview', Icon: LayoutDashboard, end: true, group: 'Workspace' },
  { to: '/ask', label: 'Ask · Console', Icon: Search, group: 'Workspace' },
  { to: '/graph', label: 'Knowledge Graph', Icon: Network, group: 'Workspace' },
  { to: '/sources', label: 'Sources & Crawlers', Icon: Database, group: 'Context' },
  { to: '/steward', label: 'Steward Review', Icon: CheckSquare, group: 'Context' },
  { to: '/skills', label: 'Skills & MCP', Icon: Blocks, group: 'Context' },
  { to: '/governance', label: 'Governance', Icon: ShieldCheck, group: 'Govern' },
  { to: '/measure', label: 'Measure & ROI', Icon: LineChart, group: 'Govern' },
  { to: '/personas', label: 'Personas', Icon: Users, group: 'Govern' },
  { to: '/strategy', label: 'Market & Positioning', Icon: Target, group: 'Strategy' },
  { to: '/domains', label: 'Domain Products', Icon: Boxes, group: 'Strategy' },
  { to: '/federation', label: 'Federation & Standards', Icon: Layers, group: 'Strategy' },
]

function Logo({ collapsed }: { collapsed: boolean }) {
  return (
    <div className="flex items-center gap-2.5 h-[30px] px-1">
      <svg viewBox="0 0 32 32" fill="none" className="w-[26px] h-[26px] flex-none">
        <circle cx="16" cy="16" r="4" fill="#55b8c9" />
        <circle cx="6" cy="8" r="2.4" fill="#a98cd6" /><circle cx="26" cy="9" r="2.4" fill="#6cc08d" />
        <circle cx="7" cy="25" r="2.4" fill="#d6a45c" /><circle cx="25" cy="24" r="2.4" fill="#55b8c9" />
        <g stroke="#2f6b7a" strokeWidth="1.1">
          <line x1="16" y1="16" x2="6" y2="8" /><line x1="16" y1="16" x2="26" y2="9" />
          <line x1="16" y1="16" x2="7" y2="25" /><line x1="16" y1="16" x2="25" y2="24" />
        </g>
      </svg>
      {!collapsed && <span className="mono font-bold whitespace-nowrap" style={{ fontSize: 13, letterSpacing: 2, color: '#eaf6ff' }}>CONTEXT<b style={{ color: 'var(--cyan)' }}>HUB</b></span>}
    </div>
  )
}

export default function Sidebar({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  let lastGroup = ''
  return (
    <nav className="flex flex-col py-3 gap-0.5 z-[5] h-full"
      style={{ background: 'linear-gradient(180deg,#0a1019,#06090f)', borderRight: '1px solid var(--line2)' }}>
      <div className={`flex items-center px-2.5 mb-2 ${collapsed ? 'flex-col gap-2.5' : 'justify-between'}`}>
        <Logo collapsed={collapsed} />
        <button onClick={onToggle} title={collapsed ? 'Expand' : 'Collapse'}
          className="nav-item w-8 h-8 rounded-[8px] grid place-items-center cursor-pointer flex-none">
          {collapsed ? <PanelLeftOpen size={18} color="var(--dim)" /> : <PanelLeftClose size={18} color="var(--dim)" />}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto overflow-x-hidden px-2">
        {ITEMS.map(({ to, label, Icon, end, group }) => {
          const showGroup = !collapsed && group !== lastGroup
          lastGroup = group
          return (
            <div key={to}>
              {showGroup && (
                <div className="mono px-2 pt-3 pb-1" style={{ fontSize: 8, letterSpacing: 1.5, color: 'var(--faint)', textTransform: 'uppercase' }}>{group}</div>
              )}
              <NavLink to={to} end={end}
                className={({ isActive }) => `nav-item group relative flex items-center gap-3 rounded-[9px] cursor-pointer transition ${collapsed ? 'justify-center h-11 w-11 mx-auto' : 'h-9 px-2.5'} ${isActive ? 'is-active' : ''}`}>
                {({ isActive }) => (
                  <>
                    {isActive && <span className="absolute left-[-8px] top-1.5 bottom-1.5 w-[3px] rounded-[3px]" style={{ background: 'var(--cyan)' }} />}
                    <Icon size={19} className="flex-none" color={isActive ? 'var(--cyan)' : 'var(--dim)'} />
                    {!collapsed && <span className="whitespace-nowrap" style={{ fontSize: 12, color: isActive ? '#eaf6ff' : 'var(--dim)' }}>{label}</span>}
                    {collapsed && (
                      <span className="absolute left-[52px] mono opacity-0 group-hover:opacity-100 pointer-events-none transition whitespace-nowrap z-20"
                        style={{ background: 'var(--panelSolid)', border: '1px solid var(--line2)', color: 'var(--text)', fontSize: 10, padding: '5px 9px', borderRadius: 6, letterSpacing: 0.5 }}>{label}</span>
                    )}
                  </>
                )}
              </NavLink>
            </div>
          )
        })}
      </div>

      <div className="px-2 pt-2 flex flex-col gap-0.5" style={{ borderTop: '1px solid var(--line)' }}>
        <button className={`nav-item flex items-center gap-3 rounded-[9px] cursor-pointer ${collapsed ? 'justify-center h-11 w-11 mx-auto' : 'h-9 px-2.5'}`}>
          <Settings size={19} className="flex-none" color="var(--dim)" />
          {!collapsed && <span style={{ fontSize: 12, color: 'var(--dim)' }}>Settings</span>}
        </button>
      </div>
    </nav>
  )
}
