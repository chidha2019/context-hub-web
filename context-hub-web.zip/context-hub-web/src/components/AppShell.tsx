import { useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Sidebar from './Sidebar'
import TopBar from './TopBar'

export default function AppShell() {
  const [collapsed, setCollapsed] = useState(false)
  const { pathname } = useLocation()
  const navW = collapsed ? 62 : 220
  const bleed = pathname === '/' // Command Center is a full-bleed intelligence view

  return (
    <div className="h-screen w-screen overflow-hidden grid transition-[grid-template-columns] duration-200"
      style={{ gridTemplateColumns: `${navW}px 1fr`, gridTemplateRows: '50px 1fr' }}>
      <div className="row-span-2 overflow-hidden">
        <Sidebar collapsed={collapsed} onToggle={() => setCollapsed((c) => !c)} />
      </div>
      <TopBar />
      <main className="overflow-hidden relative">
        {!bleed && <div className="grid-bg pointer-events-none fixed z-0" style={{ inset: `50px 0 0 ${navW}px` }} />}
        {bleed ? (
          <div className="absolute inset-0 overflow-hidden z-[1]"><Outlet /></div>
        ) : (
          <div className="relative z-[1] px-[22px] py-[18px] pb-10 h-full overflow-y-auto" style={{ animation: 'fade .25s' }}><Outlet /></div>
        )}
      </main>
    </div>
  )
}
