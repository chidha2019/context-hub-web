import { useEffect, useRef } from 'react'

export interface GraphCanvasNode { id: string; type: string; label: string; degree: number }
export interface GraphCanvasEdge { source: string; target: string; rel: string }

interface Props {
  label?: string
  fill?: boolean
  nodes?: GraphCanvasNode[]
  edges?: GraphCanvasEdge[]
  selectedId?: string
  onNodeClick?: (id: string) => void
}

const TYPE_COLORS: Record<string, string> = {
  Document: '#55b8c9', Issue: '#6f9fe0', Person: '#d6a45c', Service: '#6cc08d', Customer: '#a98cd6',
}

interface FakeNode { x: number; y: number; vx: number; vy: number; r: number; c: string; hub: boolean; ph: number }
interface Pulse { e: [number, number]; t: number; sp: number; c: string }
interface PosNode { id: string; x: number; y: number; r: number; c: string; degree: number; ph: number }

const COLORS = ['#55b8c9', '#a98cd6', '#6cc08d', '#d6a45c', '#d97a86', '#6f9fe0']
const WEIGHTS = [0.4, 0.2, 0.13, 0.15, 0.06, 0.06]

function pickColor() {
  let r = Math.random(), a = 0
  for (let i = 0; i < WEIGHTS.length; i++) { a += WEIGHTS[i]; if (r <= a) return COLORS[i] }
  return COLORS[0]
}

/** Force-graph on a canvas. Real nodes/edges when provided (Graph Explorer); a decorative
 * procedural animation otherwise (Overview's full-bleed background). */
export default function GraphCanvas({ label, fill = false, nodes, edges, selectedId, onNodeClick }: Props) {
  const ref = useRef<HTMLCanvasElement>(null)
  const positionsRef = useRef<Map<string, { x: number; y: number; r: number }>>(new Map())
  // Read via refs inside the layout effect so selecting a node (or an inline onNodeClick
  // callback identity change) doesn't re-trigger the force layout — only nodes/edges should.
  const selectedIdRef = useRef(selectedId)
  selectedIdRef.current = selectedId
  const onNodeClickRef = useRef(onNodeClick)
  onNodeClickRef.current = onNodeClick

  useEffect(() => {
    const cv = ref.current
    if (!cv) return
    const ctx = cv.getContext('2d')!
    let W = 0, H = 0, DPR = 1, frame = 0, raf = 0
    const real = !!(nodes && nodes.length)

    if (real) {
      let posNodes: PosNode[] = []
      let posEdges: [number, number][] = []
      let pulses: Pulse[] = []

      function layout() {
        DPR = Math.min(window.devicePixelRatio || 1, 2)
        W = cv!.clientWidth; H = cv!.clientHeight
        cv!.width = W * DPR; cv!.height = H * DPR
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0)

        const idIndex = new Map(nodes!.map((n, i) => [n.id, i]))
        posNodes = nodes!.map((n) => {
          const an = Math.random() * 6.28, rd = Math.pow(Math.random(), 0.6) * Math.min(W, H) * 0.42
          return {
            id: n.id, degree: n.degree,
            x: W / 2 + Math.cos(an) * rd, y: H / 2 + Math.sin(an) * rd,
            r: Math.min(3 + n.degree * 0.7, 11),
            c: TYPE_COLORS[n.type] || '#9aa4b0',
            ph: Math.random() * 6.28,
          }
        })
        posEdges = (edges || [])
          .map((e) => [idIndex.get(e.source), idIndex.get(e.target)] as [number | undefined, number | undefined])
          .filter((pair): pair is [number, number] => pair[0] !== undefined && pair[1] !== undefined)

        // Minimal force-directed layout: repulsion + spring edges + centering, fixed iterations.
        const vx = new Array(posNodes.length).fill(0)
        const vy = new Array(posNodes.length).fill(0)
        const REPEL = 1800, SPRING = 0.02, REST = 70, CENTER = 0.015
        for (let iter = 0; iter < 160; iter++) {
          for (let i = 0; i < posNodes.length; i++) {
            let fx = 0, fy = 0
            for (let j = 0; j < posNodes.length; j++) {
              if (i === j) continue
              const dx = posNodes[i].x - posNodes[j].x, dy = posNodes[i].y - posNodes[j].y
              const d2 = dx * dx + dy * dy + 0.01
              const f = REPEL / d2
              fx += dx * f; fy += dy * f
            }
            fx += (W / 2 - posNodes[i].x) * CENTER
            fy += (H / 2 - posNodes[i].y) * CENTER
            vx[i] = (vx[i] + fx * 0.01) * 0.85
            vy[i] = (vy[i] + fy * 0.01) * 0.85
          }
          for (const [a, b] of posEdges) {
            const A = posNodes[a], B = posNodes[b]
            const dx = B.x - A.x, dy = B.y - A.y
            const dist = Math.sqrt(dx * dx + dy * dy) || 1
            const f = (dist - REST) * SPRING
            const ux = dx / dist, uy = dy / dist
            vx[a] += ux * f; vy[a] += uy * f
            vx[b] -= ux * f; vy[b] -= uy * f
          }
          for (let i = 0; i < posNodes.length; i++) {
            posNodes[i].x = Math.max(16, Math.min(W - 16, posNodes[i].x + vx[i]))
            posNodes[i].y = Math.max(16, Math.min(H - 16, posNodes[i].y + vy[i]))
          }
        }

        const map = new Map<string, { x: number; y: number; r: number }>()
        for (const n of posNodes) map.set(n.id, { x: n.x, y: n.y, r: n.r })
        positionsRef.current = map
        pulses = []
      }

      function draw() {
        frame++
        ctx.clearRect(0, 0, W, H)
        ctx.lineWidth = 0.7
        for (const [a, b] of posEdges) {
          const A = posNodes[a], B = posNodes[b]
          ctx.strokeStyle = 'rgba(160,175,192,0.16)'
          ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke()
        }
        if (frame % 14 === 0 && pulses.length < 20 && posEdges.length) {
          const e = posEdges[Math.floor(Math.random() * posEdges.length)]
          pulses.push({ e, t: 0, sp: 0.008 + Math.random() * 0.02, c: Math.random() < 0.6 ? '#55b8c9' : '#a98cd6' })
        }
        for (let p = pulses.length - 1; p >= 0; p--) {
          const pu = pulses[p]; pu.t += pu.sp
          if (pu.t >= 1) { pulses.splice(p, 1); continue }
          const A = posNodes[pu.e[0]], B = posNodes[pu.e[1]]
          const x = A.x + (B.x - A.x) * pu.t, y = A.y + (B.y - A.y) * pu.t
          ctx.fillStyle = pu.c; ctx.globalAlpha = 0.85; ctx.shadowColor = pu.c; ctx.shadowBlur = 3
          ctx.beginPath(); ctx.arc(x, y, 1.6, 0, 7); ctx.fill(); ctx.shadowBlur = 0; ctx.globalAlpha = 1
        }
        for (const n of posNodes) {
          const hub = n.degree >= 4
          const g = hub ? 6 : 0
          const pr = hub ? n.r + Math.sin(frame * 0.05 + n.ph) * 0.7 : n.r
          ctx.shadowColor = n.c; ctx.shadowBlur = g; ctx.fillStyle = n.c
          ctx.beginPath(); ctx.arc(n.x, n.y, pr, 0, 7); ctx.fill(); ctx.shadowBlur = 0
          if (n.id === selectedIdRef.current) {
            ctx.strokeStyle = '#eaf6ff'; ctx.lineWidth = 1.5; ctx.globalAlpha = 0.9
            ctx.beginPath(); ctx.arc(n.x, n.y, pr + 4, 0, 7); ctx.stroke(); ctx.globalAlpha = 1
          }
        }
        raf = requestAnimationFrame(draw)
      }

      function onClick(ev: MouseEvent) {
        if (!onNodeClickRef.current) return
        const rect = cv!.getBoundingClientRect()
        const x = ev.clientX - rect.left, y = ev.clientY - rect.top
        let best: string | null = null, bestD = Infinity
        for (const [id, p] of positionsRef.current) {
          const d = Math.hypot(x - p.x, y - p.y)
          if (d <= p.r + 6 && d < bestD) { bestD = d; best = id }
        }
        if (best) onNodeClickRef.current(best)
      }

      layout(); draw()
      cv.addEventListener('click', onClick)
      const onResize = () => { if (cv!.clientWidth) layout() }
      window.addEventListener('resize', onResize)
      return () => {
        cancelAnimationFrame(raf)
        cv!.removeEventListener('click', onClick)
        window.removeEventListener('resize', onResize)
      }
    }

    // === Decorative fallback (no real data) — unchanged procedural animation ===
    let fakeNodes: FakeNode[] = [], fakeEdges: [number, number, number][] = [], fakePulses: Pulse[] = []

    function build() {
      DPR = Math.min(window.devicePixelRatio || 1, 2)
      W = cv!.clientWidth; H = cv!.clientHeight
      cv!.width = W * DPR; cv!.height = H * DPR
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0)
      fakeNodes = []; fakeEdges = []; fakePulses = []
      const N = Math.max(40, Math.floor((W * H) / 11000))
      const cx = W / 2, cy = H / 2
      for (let i = 0; i < N; i++) {
        const an = Math.random() * 6.28
        const rd = Math.pow(Math.random(), 0.6) * Math.min(W, H) * 0.46
        fakeNodes.push({
          x: cx + Math.cos(an) * rd + (Math.random() - 0.5) * 40,
          y: cy + Math.sin(an) * rd + (Math.random() - 0.5) * 40,
          vx: (Math.random() - 0.5) * 0.11, vy: (Math.random() - 0.5) * 0.11,
          r: i < 3 ? 5.5 : 1.6 + Math.random() * 2.6,
          c: i === 0 ? '#6cc08d' : pickColor(), hub: i < 4, ph: Math.random() * 6.28,
        })
      }
      for (let i = 1; i < fakeNodes.length; i++) {
        const links = 1 + (Math.random() < 0.3 ? 1 : 0)
        for (let l = 0; l < links; l++) {
          const j = Math.random() < 0.4 ? Math.floor(Math.random() * 4) : Math.floor(Math.random() * fakeNodes.length)
          if (j !== i) fakeEdges.push([i, j, Math.random() * 0.6 + 0.15])
        }
      }
    }

    function draw() {
      frame++
      ctx.clearRect(0, 0, W, H)
      for (const n of fakeNodes) {
        n.x += n.vx; n.y += n.vy
        if (n.x < 20 || n.x > W - 20) n.vx *= -1
        if (n.y < 20 || n.y > H - 20) n.vy *= -1
      }
      ctx.lineWidth = 0.6
      for (const [i, j, a] of fakeEdges) {
        const A = fakeNodes[i], B = fakeNodes[j]
        ctx.strokeStyle = `rgba(160,175,192,${a * 0.14})`
        ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke()
      }
      if (frame % 14 === 0 && fakePulses.length < 20 && fakeEdges.length) {
        const e = fakeEdges[Math.floor(Math.random() * fakeEdges.length)]
        fakePulses.push({ e: [e[0], e[1]], t: 0, sp: 0.008 + Math.random() * 0.02, c: Math.random() < 0.6 ? '#55b8c9' : '#a98cd6' })
      }
      for (let p = fakePulses.length - 1; p >= 0; p--) {
        const pu = fakePulses[p]; pu.t += pu.sp
        if (pu.t >= 1) { fakePulses.splice(p, 1); continue }
        const A = fakeNodes[pu.e[0]], B = fakeNodes[pu.e[1]]
        const x = A.x + (B.x - A.x) * pu.t, y = A.y + (B.y - A.y) * pu.t
        ctx.fillStyle = pu.c; ctx.globalAlpha = 0.85; ctx.shadowColor = pu.c; ctx.shadowBlur = 3
        ctx.beginPath(); ctx.arc(x, y, 1.6, 0, 7); ctx.fill(); ctx.shadowBlur = 0; ctx.globalAlpha = 1
      }
      for (const n of fakeNodes) {
        const g = n.hub ? 6 : 0
        const pr = n.hub ? n.r + Math.sin(frame * 0.05 + n.ph) * 0.7 : n.r
        ctx.shadowColor = n.c; ctx.shadowBlur = g; ctx.fillStyle = n.c
        ctx.beginPath(); ctx.arc(n.x, n.y, pr, 0, 7); ctx.fill(); ctx.shadowBlur = 0
        if (n.hub) {
          ctx.strokeStyle = n.c; ctx.globalAlpha = 0.22; ctx.lineWidth = 1
          ctx.beginPath(); ctx.arc(n.x, n.y, pr + 5 + ((frame * 0.4 + n.ph * 20) % 18), 0, 7); ctx.stroke()
          ctx.globalAlpha = 1
        }
      }
      raf = requestAnimationFrame(draw)
    }

    build(); draw()
    const onResize = () => { if (cv!.clientWidth) build() }
    window.addEventListener('resize', onResize)
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', onResize) }
  }, [nodes, edges])

  return (
    <div
      className={fill ? 'absolute inset-0 overflow-hidden' : 'relative w-full h-full rounded-[10px] overflow-hidden'}
      style={fill ? { background: 'radial-gradient(ellipse 90% 70% at 50% 40%, #12161c, #0e1116)' } : { background: '#12161c', border: '1px solid var(--line)' }}
    >
      {label && <span className="absolute top-2 left-2.5 mono z-[2]" style={{ fontSize: 9, color: 'var(--dim)', letterSpacing: 1 }}>{label}</span>}
      <canvas ref={ref} className="absolute inset-0 w-full h-full" style={{ cursor: nodes?.length ? 'pointer' : 'default' }} />
    </div>
  )
}
