import { useState } from 'react'
import { useLocation } from 'react-router-dom'
import { ChevronDown, Check } from 'lucide-react'
import { usePersona } from '../PersonaContext'

const CRUMBS: Record<string, string> = {
  '/': 'Overview', '/ask': 'Ask · Context Console', '/graph': 'Knowledge Graph',
  '/sources': 'Sources & Crawlers', '/steward': 'Steward Review', '/skills': 'Skills & MCP Registry',
  '/governance': 'Governance & Audit', '/measure': 'Measure & ROI', '/personas': 'Personas',
  '/strategy': 'Market & Positioning', '/domains': 'Domain Products', '/federation': 'Federation & Standards',
}

export default function TopBar() {
  const { pathname } = useLocation()
  const crumb = CRUMBS[pathname] || 'Overview'
  const { persona, setPersona, all } = usePersona()
  const [open, setOpen] = useState(false)

  return (
    <div className="flex items-center gap-4 px-[18px] z-[10] relative"
      style={{ background: 'linear-gradient(180deg,#0a1019,#070b12)', borderBottom: '1px solid var(--line2)' }}>
      <div className="mono" style={{ fontSize: 12, letterSpacing: 1, color: '#eaf6ff' }}>
        CONTEXT<b style={{ color: 'var(--cyan)' }}>HUB</b> <span style={{ color: 'var(--faint)' }}>/ {crumb}</span>
      </div>
      <div className="flex items-center gap-2 ml-3 rounded-md px-[11px] py-1.5 w-[300px]"
        style={{ background: 'rgba(6,11,18,0.9)', border: '1px solid var(--line2)' }}>
        <span style={{ color: 'var(--cyan)' }}>⌕</span>
        <input placeholder="Ask the graph or jump to anything…" className="bg-transparent border-none outline-none mono w-full" style={{ color: 'var(--text)', fontSize: 11.5 }} />
        <span className="mono" style={{ fontSize: 9, color: 'var(--faint)', border: '1px solid var(--line)', borderRadius: 3, padding: '1px 5px' }}>⌘K</span>
      </div>

      <div className="ml-auto flex items-center gap-3.5">
        {/* Persona switcher */}
        <div className="relative">
          <button onClick={() => setOpen((o) => !o)}
            className="mono flex items-center gap-2 cursor-pointer rounded-md pl-2 pr-2.5 py-1.5"
            style={{ fontSize: 10, color: 'var(--dim)', border: '1px solid var(--line2)', background: open ? 'rgba(85,184,201,0.06)' : 'transparent' }}>
            <span className="w-[18px] h-[18px] rounded-[5px] grid place-items-center font-bold" style={{ fontSize: 8.5, color: '#04121a', background: persona.color }}>{persona.initials}</span>
            VIEW AS <b style={{ color: persona.color }}>{persona.name}</b>
            <ChevronDown size={13} />
          </button>

          {open && (
            <>
              <div className="fixed inset-0 z-[19]" onClick={() => setOpen(false)} />
              <div className="absolute right-0 mt-1.5 w-[280px] rounded-lg z-[20] overflow-hidden"
                style={{ background: 'var(--panelSolid)', border: '1px solid var(--line2)', boxShadow: '0 12px 40px rgba(0,0,0,.55)' }}>
                <div className="mono px-3 pt-2.5 pb-1.5" style={{ fontSize: 8.5, letterSpacing: 1.5, color: 'var(--faint)', textTransform: 'uppercase' }}>Switch persona · reshapes workspace</div>
                {all.map((p) => {
                  const active = p.id === persona.id
                  return (
                    <button key={p.id} onClick={() => { setPersona(p.id); setOpen(false) }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-white/[0.04]"
                      style={{ background: active ? 'rgba(85,184,201,0.06)' : 'transparent' }}>
                      <span className="w-[26px] h-[26px] rounded-[6px] grid place-items-center mono font-bold flex-none" style={{ fontSize: 9, color: '#04121a', background: p.color }}>{p.initials}</span>
                      <span className="flex-1 min-w-0">
                        <span className="block" style={{ fontSize: 12, color: '#eaf6ff' }}>{p.name}</span>
                        <span className="block truncate mono" style={{ fontSize: 9, color: 'var(--faint)' }}>{p.tagline}</span>
                      </span>
                      {active && <Check size={14} color="var(--cyan)" className="flex-none" />}
                    </button>
                  )
                })}
              </div>
            </>
          )}
        </div>

        <div className="mono flex items-center gap-1.5" style={{ fontSize: 10, color: 'var(--green)' }}>
          <span className="w-[7px] h-[7px] rounded-full" style={{ background: 'var(--green)', animation: 'pulse 2s infinite' }} />
          NOMINAL
        </div>
        <div className="w-7 h-7 rounded-full grid place-items-center mono font-bold" style={{ background: `linear-gradient(135deg,${persona.color},#a98cd6)`, fontSize: 11, color: '#04121a' }}>{persona.initials}</div>
      </div>
    </div>
  )
}
