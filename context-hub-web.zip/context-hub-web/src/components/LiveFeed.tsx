import { useEffect, useState } from 'react'
import { usePersona } from '../PersonaContext'
import { getAudit, type ServeEventOut } from '../api/client'

/** Auto-scrolling live context feed ticker, polling real serve events. Pauses on hover. */
export default function LiveFeed() {
  const { persona } = usePersona()
  const [events, setEvents] = useState<ServeEventOut[]>([])

  useEffect(() => {
    let cancelled = false
    const poll = () => {
      getAudit(persona.id, 12).then((rows) => { if (!cancelled) setEvents(rows) }).catch(() => {})
    }
    poll()
    const id = setInterval(poll, 5000)
    return () => { cancelled = true; clearInterval(id) }
  }, [persona.id])

  const rows = events.map((e) => ({
    ts: e.ts.slice(11, 16),
    actor: e.persona,
    verb: e.action,
    obj: e.asset,
    lat: e.latency_ms,
  }))
  const doubled = rows.length > 0 ? [...rows, ...rows] : []

  return (
    <div className="overflow-hidden relative flex-1 min-h-0 group">
      {doubled.length === 0 && <div style={{ fontSize: 11, color: 'var(--dim)', padding: 8 }}>No serve events yet.</div>}
      <div className="group-hover:[animation-play-state:paused]" style={{ animation: 'roll 24s linear infinite' }}>
        {doubled.map((r, i) => (
          <div key={i} className="grid items-center mono" style={{ gridTemplateColumns: '52px 1fr 52px', gap: 8, fontSize: 9.5, padding: '4px 2px', borderBottom: '1px solid rgba(90,120,150,0.06)' }}>
            <span style={{ color: 'var(--faint)' }}>{r.ts}</span>
            <span>
              <span style={{ color: 'var(--magenta)' }}>{r.actor}</span> {r.verb}{' '}
              <span style={{ color: 'var(--cyan)' }} className="truncate">{r.obj}</span>
            </span>
            <span className="text-right" style={{ color: 'var(--green)' }}>{r.lat}ms</span>
          </div>
        ))}
      </div>
    </div>
  )
}
