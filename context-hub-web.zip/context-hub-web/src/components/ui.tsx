import type { ReactNode } from 'react'

export function ViewHeader({ title, sub, actions }: { title: string; sub: string; actions?: ReactNode }) {
  return (
    <div className="flex items-end gap-3 mb-4">
      <div className="vtitle">{title}</div>
      <div className="vsub mb-0.5">{sub}</div>
      {actions && <div className="ml-auto flex gap-2">{actions}</div>}
    </div>
  )
}

export function Card({ title, extra, children, className = '', bodyClass = '' }: {
  title?: string; extra?: ReactNode; children: ReactNode; className?: string; bodyClass?: string
}) {
  return (
    <div className={`card ${className}`}>
      {title && (
        <div className="card-h">
          <span className="card-t">{title}</span>
          {extra && <span className="card-x">{extra}</span>}
        </div>
      )}
      <div className={bodyClass}>{children}</div>
    </div>
  )
}

export function Stat({ n, label, detail, color = '', trend }: {
  n: string; label: string; detail?: string; color?: string; trend?: 'up' | 'down'
}) {
  const colorMap: Record<string, string> = {
    cy: 'var(--cyan)', gr: 'var(--green)', am: 'var(--amber)', mg: 'var(--magenta)', bl: 'var(--blue)',
  }
  return (
    <div className="stat">
      <div className="stat-n" style={{ color: colorMap[color] || '#eaf6ff' }}>{n}</div>
      <div className="stat-l">{label}</div>
      {detail && (
        <div className="stat-d" style={{ color: trend === 'up' ? 'var(--green)' : trend === 'down' ? 'var(--red)' : 'var(--dim)' }}>
          {trend === 'up' ? '▲ ' : trend === 'down' ? '▼ ' : ''}{detail}
        </div>
      )}
    </div>
  )
}

export function Badge({ kind, children }: { kind: string; children: ReactNode }) {
  return <span className={`badge ${kind}`}>{children}</span>
}

export function Meter({ pct, color = 'var(--cyan)' }: { pct: number; color?: string }) {
  return <div className="meter"><i style={{ width: `${pct}%`, background: color }} /></div>
}

export function Btn({ children, variant = '', onClick }: { children: ReactNode; variant?: 'ghost' | 'pri' | ''; onClick?: () => void }) {
  return <button className={`btn ${variant === 'ghost' ? 'btn-ghost' : variant === 'pri' ? 'btn-pri' : ''}`} onClick={onClick}>{children}</button>
}
