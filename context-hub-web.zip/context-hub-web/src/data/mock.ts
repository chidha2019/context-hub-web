import type {
  SourceConnector, Spine, Skill, ReviewItem, ServeEvent,
} from '../types'

export const spines: Spine[] = [
  { id: 'trust', badge: 'TRUST', color: '#55b8c9', value: '0.93', unit: 'avg trust', fill: 93 },
  { id: 'govern', badge: 'GOVERN', color: '#a98cd6', value: '100%', unit: 'audited', fill: 100 },
  { id: 'learn', badge: 'LEARN', color: '#6cc08d', value: '+412', unit: 'learns/wk', fill: 72 },
  { id: 'serve', badge: 'SERVE', color: '#d6a45c', value: '42ms', unit: 'p95', fill: 88 },
  { id: 'measure', badge: 'MEASURE', color: '#6f9fe0', value: '61%', unit: 'uplift', fill: 61 },
  { id: 'scale', badge: 'SCALE', color: '#4fb39b', value: '78%', unit: 'std-compliant', fill: 78 },
]

export const sources: SourceConnector[] = [
  { code: 'Co', name: 'Confluence · Eng', color: '#6f9fe0', kind: 'docs', entities: '184k', crawler: 'agent-1', lastSync: '2m ago', freshness: 'fresh', status: 'synced', statusBadge: 'b-ok', statusLabel: 'synced' },
  { code: 'Ji', name: 'Jira · Issues', color: '#6f9fe0', kind: 'tickets', entities: '92.4k', crawler: 'agent-1', lastSync: 'now', freshness: 'syncing', status: 'syncing', statusBadge: 'b-sync', statusLabel: 'syncing' },
  { code: 'G', name: 'GitHub · 214 repos', color: '#b06a86', kind: 'code+PR', entities: '1.1M', crawler: 'agent-2', lastSync: '6m ago', freshness: 'fresh', status: 'synced', statusBadge: 'b-ok', statusLabel: 'synced' },
  { code: 'Sl', name: 'Slack · 38 channels', color: '#b06a86', kind: 'threads', entities: '640k', crawler: 'agent-3', lastSync: '1m ago', freshness: 'pii-guard', status: 'pii', statusBadge: 'b-pii', statusLabel: 'pii' },
  { code: 'Sf', name: 'Salesforce', color: '#d6a45c', kind: 'CRM', entities: '58.9k', crawler: 'agent-3', lastSync: '6h ago', freshness: 'stale', status: 'stale', statusBadge: 'b-stale', statusLabel: 'stale 6h' },
  { code: 'Pg', name: 'Postgres · prod', color: '#6cc08d', kind: 'tables', entities: '2.4k', crawler: 'agent-2', lastSync: '4m ago', freshness: 'fresh', status: 'synced', statusBadge: 'b-ok', statusLabel: 'synced' },
  { code: 'No', name: 'Notion · Wiki', color: '#9aa4b0', kind: 'pages', entities: '21.7k', crawler: 'agent-1', lastSync: '9m ago', freshness: 'fresh', status: 'synced', statusBadge: 'b-ok', statusLabel: 'synced' },
  { code: 'Cb', name: 'Collibra', color: '#55b8c9', kind: 'governance', entities: '12.1k', crawler: 'agent-4', lastSync: '12m ago', freshness: 'fresh', status: 'synced', statusBadge: 'b-ok', statusLabel: 'synced' },
  { code: 'S3', name: 'S3 · Data Lake', color: '#c88a4a', kind: 'objects', entities: '4.9M', crawler: 'agent-2', lastSync: 'off', freshness: 'off', status: 'paused', statusBadge: 'b-stale', statusLabel: 'paused' },
  { code: 'Sp', name: 'SharePoint · Legal', color: '#6f9fe0', kind: 'docs', entities: '33.1k', crawler: 'agent-1', lastSync: 'off', freshness: 'off', status: 'off', statusBadge: 'b-stale', statusLabel: 'off' },
  { code: 'Er', name: 'Erwin Models', color: '#55b8c9', kind: 'models', entities: '1.9k', crawler: 'agent-4', lastSync: '1h ago', freshness: 'fresh', status: 'synced', statusBadge: 'b-ok', statusLabel: 'synced' },
  { code: 'MD', name: 'MDM · master', color: '#6cc08d', kind: 'records', entities: '410k', crawler: 'agent-2', lastSync: '18m ago', freshness: 'fresh', status: 'synced', statusBadge: 'b-ok', statusLabel: 'synced' },
]

export const crawlers = [
  { name: 'Technical metadata', code: 'A1', running: false },
  { name: 'Business metadata', code: 'A2', running: true },
  { name: 'Operational metadata', code: 'A3', running: false },
  { name: 'Governance metadata', code: 'A4', running: false },
  { name: 'SDLC crawler', code: 'A5', running: false },
]

export const graphLayers = [
  { name: 'Document', color: '#55b8c9', count: '842k', on: true },
  { name: 'Entity', color: '#a98cd6', count: '1.2k', on: true },
  { name: 'Service', color: '#6cc08d', count: '214', on: true },
  { name: 'Person', color: '#d6a45c', count: '3.1k', on: true },
  { name: 'PII / Sensitive', color: '#d97a86', count: '58k', on: true },
  { name: 'Metric / KPI', color: '#6f9fe0', count: '904', on: false },
  { name: 'Policy', color: '#4fb39b', count: '311', on: false },
]

export const reviewQueue: ReviewItem[] = [
  { type: 'KPI', title: 'Net Revenue Retention', origin: 'crawler · business', confidence: '0.71', badge: 'b-stale' },
  { type: 'GLOSSARY', title: '"MRR" synonym merge', origin: 'crawler · business', confidence: '0.68', badge: 'b-stale' },
  { type: 'ENTITY', title: 'Acme Corp ↔ Account', origin: 'crawler · technical', confidence: '0.83', badge: 'b-sync' },
  { type: 'KPI', title: 'Churn Rate definition', origin: 'crawler · business', confidence: '0.62', badge: 'b-stale' },
  { type: 'POLICY', title: 'PII tag · email_hash', origin: 'crawler · governance', confidence: '0.90', badge: 'b-ok' },
  { type: 'ENTITY', title: 'billing-service owner', origin: 'crawler · sdlc', confidence: '0.77', badge: 'b-sync' },
]

export const skills: Skill[] = [
  { icon: '{ }', name: 'Coding Skills', kind: 'SKILL · SDLC', color: '#55b8c9', desc: 'Coding patterns, standards, samples, unit-test scaffolds.', usage: '1,204 uses', status: 'verified' },
  { icon: 'QA', name: 'QA Skills', kind: 'SKILL · SDLC', color: '#6cc08d', desc: 'Test templates, coverage checks, domain artifacts.', usage: '642 uses', status: 'verified' },
  { icon: '⚙', name: 'DevOps Skills', kind: 'SKILL · SDLC', color: '#d6a45c', desc: 'Deployment guides, container & pipeline templates.', usage: '388 uses', status: 'verified' },
  { icon: '🛡', name: 'DevSecOps Skills', kind: 'SKILL · SDLC', color: '#a98cd6', desc: 'Code compliance, vuln & penetration checks.', usage: '221 uses', status: 'review' },
  { icon: '◧', name: 'Requirement Elaboration', kind: 'SKILL · SDLC', color: '#6f9fe0', desc: 'Requirements templates, ops handbooks, domain artifacts.', usage: '501 uses', status: 'verified' },
  { icon: '⬡', name: 'Architecture & Design', kind: 'SKILL · SDLC', color: '#4fb39b', desc: 'Architecture & design patterns, tech topology.', usage: '312 uses', status: 'verified' },
  { icon: '⛃', name: 'snowflake.query', kind: 'MCP TOOL', color: '#55b8c9', desc: 'Governed Cortex semantic-view query endpoint.', usage: '9.1k calls', status: 'verified' },
  { icon: '⛁', name: 'uc.metric_view', kind: 'MCP TOOL', color: '#6cc08d', desc: 'Databricks Unity Catalog metric view · Genie.', usage: '5.4k calls', status: 'verified' },
  { icon: '≈', name: 'graph.retrieve', kind: 'MCP TOOL', color: '#d6a45c', desc: 'Hybrid retrieval + rerank over the context graph.', usage: '88k calls', status: 'verified' },
]

export const auditLog: ServeEvent[] = [
  { ts: '14:22:07', actor: 'support-copilot', action: 'retrieve', asset: 'billing retry policy', acl: 'allowed', pii: '3 masked', latencyMs: 38, badge: 'b-ok' },
  { ts: '14:22:04', actor: 'sales-gpt', action: 'graph.walk', asset: 'Acme → owner', acl: 'allowed', pii: '—', latencyMs: 21, badge: 'b-ok' },
  { ts: '14:21:58', actor: 'analytics-ai', action: 'snowflake.query', asset: 'NRR metric', acl: 'allowed', pii: '—', latencyMs: 62, badge: 'b-ok' },
  { ts: '14:21:50', actor: 'sre-agent', action: 'retrieve', asset: 'oncall runbook', acl: 'allowed', pii: '1 masked', latencyMs: 44, badge: 'b-ok' },
  { ts: '14:21:44', actor: 'legal-review', action: 'retrieve', asset: 'contract-restricted', acl: 'denied', pii: '—', latencyMs: 8, badge: 'b-err' },
  { ts: '14:21:39', actor: 'onboard-bot', action: 'skill.coding', asset: 'code sample', acl: 'allowed', pii: '—', latencyMs: 29, badge: 'b-ok' },
  { ts: '14:21:31', actor: 'unknown-agent', action: 'retrieve', asset: 'injection payload', acl: 'blocked', pii: '—', latencyMs: 5, badge: 'b-err' },
]

export const adoption = [120, 148, 165, 180, 176, 205, 238, 262, 281, 318]

export const personaUplift = [
  { name: 'Data Engineer', pct: 68 },
  { name: 'Digital Engineer', pct: 64 },
  { name: 'QA', pct: 58 },
  { name: 'DevOps', pct: 55 },
  { name: 'BI', pct: 49 },
  { name: 'Citizen Dev', pct: 44 },
]

export const slas = [
  { consumer: 'Snowflake', surface: 'Cortex view', sla: '15m', met: '99.8%', p95: '62ms', badge: 'b-ok', label: 'healthy' },
  { consumer: 'Databricks', surface: 'UC Genie', sla: '15m', met: '99.5%', p95: '58ms', badge: 'b-ok', label: 'healthy' },
  { consumer: 'PowerBI', surface: 'TMDL+DAX', sla: '1h', met: '98.9%', p95: '—', badge: 'b-ok', label: 'healthy' },
  { consumer: 'Applications', surface: 'MCP', sla: '5m', met: '99.4%', p95: '42ms', badge: 'b-ok', label: 'healthy' },
  { consumer: 'SDLC Tools', surface: 'MCP', sla: '5m', met: '97.2%', p95: '51ms', badge: 'b-stale', label: 'watch' },
]

export const feedActors = ['support-copilot', 'sales-gpt', 'sre-agent', 'analytics-ai', 'code-reviewer', 'onboard-bot']
export const feedActions: [string, string][] = [
  ['pulled', 'billing retry policy'], ['resolved', 'Acme → Account'], ['graph walk', 'service→owner'],
  ['search', '"refund SLA"'], ['reranked', '32→6'], ['masked', '4 PII fields'],
  ['acl check', 'denied · finance'], ['memory write', 'PAY-2871'],
]
