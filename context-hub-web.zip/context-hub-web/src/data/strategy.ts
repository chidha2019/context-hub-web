// Market findings (as of Aug 2026) reflected as interactive product data.

export const marketSignals = [
  { n: '$1.3B→$19B', label: 'Knowledge-graph market', detail: '2025 → 2033', color: 'cy' },
  { n: '~95%', label: 'GenAI pilots that fail', detail: 'context, not the model', color: 'am' },
  { n: '7%', label: 'Enterprises fully AI-ready', detail: '93% are not', color: 'mg' },
  { n: '$7.2B', label: 'Glean valuation', detail: 'context layer is a real business', color: 'bl' },
  { n: 'Critical', label: 'Semantic layer status', detail: 'named core infrastructure', color: 'gr' },
]

// Competitors for the interactive positioning chart + compare panel.
// x = head-to-head overlap (0-100), y = incumbent strength (0-100), r = market weight.
export interface Competitor {
  id: string; name: string; x: number; y: number; r: number
  angle: string; strength: string; counter: string; color: string
}
export const competitors: Competitor[] = [
  { id: 'fabric', name: 'MS Fabric IQ', x: 90, y: 88, r: 15, angle: 'Ontology + semantics over OneLake', strength: 'OneLake + M365 distribution', counter: 'Federate across non-MS catalogs; SDLC depth they lack', color: '#6f9fe0' },
  { id: 'dbx', name: 'Databricks', x: 86, y: 85, r: 15, angle: 'Unity Catalog + Genie ontology', strength: 'Lakehouse + ontology + Genie', counter: 'Cross-platform + agent skills, not lakehouse-bound', color: '#d97a86' },
  { id: 'sf', name: 'Snowflake Cortex', x: 83, y: 80, r: 14, angle: 'Semantic views + Cortex agents', strength: 'Semantics in-warehouse', counter: 'Multi-warehouse federation + governance depth', color: '#55b8c9' },
  { id: 'atlan', name: 'Atlan', x: 74, y: 66, r: 11, angle: 'Cross-platform catalog + MCP', strength: 'Catalog + MCP server', counter: 'Agent-serving + SDLC context, not just catalog', color: '#a98cd6' },
  { id: 'palantir', name: 'Palantir AIP', x: 58, y: 82, r: 13, angle: 'Operational ontology + apps', strength: 'Ontology + operational apps', counter: 'Open standards + far lower TCO; ride existing stack', color: '#d6a45c' },
  { id: 'glean', name: 'Glean', x: 52, y: 76, r: 12, angle: 'Enterprise KG + work assistant', strength: 'KG + assistant, $7.2B', counter: 'Structured data + governed serving, not just search', color: '#4fb39b' },
  { id: 'dbt', name: 'dbt / Cube', x: 46, y: 52, r: 9, angle: 'Universal semantic / metrics layer', strength: 'Metrics/semantic layer', counter: 'Graph + governance + agent serving on top', color: '#8f93d6' },
  { id: 'us', name: 'ContextHub', x: 30, y: 44, r: 12, angle: 'SDLC + FDE context, federated over catalogs', strength: 'Differentiated wedge + standards-native', counter: 'This is us — low head-to-head, high specialization', color: '#6cc08d' },
]

export const wedge = [
  ['SDLC + FDE enablement', 'Lead with the SDLC/agent-skills half — far less crowded than the BI semantic-layer lane.'],
  ['Federate, don’t re-crawl', 'Sit on top of existing catalogs (Collibra, Unity, Purview) instead of re-ingesting raw sources.'],
  ['Standards-native', 'MCP, OSI, OpenLineage, Iceberg — an interoperable layer, not another silo.'],
  ['Accelerator + services GTM', 'Stand up one governed domain in 90 days — a winnable motion vs building horizontal SaaS.'],
]

// Domain products — land-and-expand portfolio (interactive).
export interface Domain {
  id: string; name: string; stage: string; owner: string; sources: string[]
  value: string; agents: number; maturity: number; entityRes: number
  milestone: string; blurb: string; wedge?: boolean
}
export const initialDomains: Domain[] = [
  { id: 'billing', name: 'Billing & Payments', stage: 'Live', owner: 'Payments team', sources: ['GitHub', 'Jira', 'Snowflake'], value: '−38% ticket cycle', agents: 4, maturity: 100, entityRes: 96, milestone: 'GA — expand to refunds & disputes', blurb: 'Retry logic, dunning and dispute context served to payment agents.' },
  { id: 'sdlc', name: 'SDLC / Engineering', stage: 'Live', owner: 'Platform Eng', sources: ['GitHub', 'Jira', 'Confluence'], value: 'FDE operations', agents: 6, maturity: 85, entityRes: 88, milestone: 'Add DevSecOps skills', blurb: 'Coding / QA / DevOps skills as governed MCP tools for FDE agents.', wedge: true },
  { id: 'cust', name: 'Customer 360', stage: 'Scaling', owner: 'CRM + Data', sources: ['Salesforce', 'MDM', 'Snowflake'], value: 'entity resolution', agents: 3, maturity: 68, entityRes: 62, milestone: 'Resolve Salesforce ↔ Stripe IDs', blurb: 'Cross-system identity + account context for sales & support agents.' },
  { id: 'fin', name: 'Finance / Metrics', stage: 'Next', owner: 'Finance', sources: ['Snowflake', 'Collibra'], value: 'certified KPIs', agents: 0, maturity: 22, entityRes: 30, milestone: 'Certify top 20 KPIs', blurb: 'Certified metric definitions sourced from Collibra + Snowflake.' },
  { id: 'supply', name: 'Supply Chain', stage: 'Pilot', owner: 'Operations', sources: ['SAP', 'Databricks'], value: 'scoped pilot', agents: 1, maturity: 35, entityRes: 34, milestone: 'Prove one use case', blurb: 'Scoped pilot on SAP + Databricks before any expansion.' },
  { id: 'hr', name: 'HR / People', stage: 'Later', owner: 'HRIS', sources: ['Workday'], value: 'backlog', agents: 0, maturity: 0, entityRes: 0, milestone: 'Backlog — not started', blurb: 'People / org graph — deliberately deferred.' },
]
export const stages = ['Live', 'Scaling', 'Pilot', 'Next', 'Later']
export const stageColor: Record<string, string> = {
  Live: '#6cc08d', Scaling: '#55b8c9', Pilot: '#d6a45c', Next: '#6f9fe0', Later: '#46586b',
}
export const stageBadge: Record<string, string> = {
  Live: 'b-ok', Scaling: 'b-sync', Pilot: 'b-stale', Next: 'b-sync', Later: 'b-stale',
}

// Federation console — toggleable catalogs, each contributes coverage weight.
export interface Catalog {
  id: string; name: string; kind: string; state: 'federated' | 'connected' | 'off'
  weight: number; contributes: string[]
}
export const initialCatalogs: Catalog[] = [
  { id: 'unity', name: 'Databricks Unity Catalog', kind: 'Governance + lineage', state: 'federated', weight: 22, contributes: ['governance', 'lineage', 'table metadata'] },
  { id: 'purview', name: 'Microsoft Purview', kind: 'Governance', state: 'federated', weight: 18, contributes: ['governance', 'classification', 'sensitivity labels'] },
  { id: 'collibra', name: 'Collibra', kind: 'Glossary + semantics', state: 'federated', weight: 20, contributes: ['business glossary', 'semantic domains', 'stewardship'] },
  { id: 'dbt', name: 'dbt Semantic Layer', kind: 'Metrics', state: 'federated', weight: 16, contributes: ['metric definitions', 'transformations'] },
  { id: 'horizon', name: 'Snowflake Horizon', kind: 'Catalog', state: 'connected', weight: 14, contributes: ['object catalog', 'tags', 'access history'] },
  { id: 'cube', name: 'Cube', kind: 'Semantic API', state: 'off', weight: 10, contributes: ['semantic API', 'metrics cache'] },
]

export interface Standard { id: string; name: string; body: string; pct: number; enables: string }
export const standards: Standard[] = [
  { id: 'mcp', name: 'MCP — Model Context Protocol', body: 'Linux Foundation', pct: 92, enables: 'Agents call tools & skills over one standard protocol.' },
  { id: 'iceberg', name: 'Apache Iceberg', body: 'Apache Software Foundation', pct: 85, enables: 'Open table format — no data lock-in across engines.' },
  { id: 'lineage', name: 'OpenLineage', body: 'LF AI & Data', pct: 78, enables: 'Portable lineage across tools and pipelines.' },
  { id: 'dcat', name: 'DCAT / RDF', body: 'W3C', pct: 70, enables: 'Interoperable metadata & semantic interchange.' },
  { id: 'osi', name: 'Open Semantic Interchange', body: 'OSI consortium', pct: 58, enables: 'Move semantic models across vendors without rework.' },
]
