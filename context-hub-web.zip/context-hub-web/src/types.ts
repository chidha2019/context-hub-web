// ---- Core domain contracts (front-end mirrors of the future API) ----

export type SyncStatus = 'synced' | 'syncing' | 'stale' | 'paused' | 'off' | 'pii'
export type BadgeKind = 'b-ok' | 'b-sync' | 'b-stale' | 'b-err' | 'b-pii'

/** A single governed unit of knowledge in the hub. */
export interface ContextAsset {
  id: string
  type: 'Document' | 'Entity' | 'Service' | 'Person' | 'Metric' | 'Policy' | 'Glossary'
  title: string
  sources: string[]
  trust: number // 0..1
  lineageResolved: boolean
  acl: 'allowed' | 'denied' | 'restricted'
  piiFields: number
}

/** A single context-serve event — drives Ask, Governance and Measure. */
export interface ServeEvent {
  ts: string
  actor: string // agent or user
  action: string
  asset: string
  acl: 'allowed' | 'denied' | 'blocked'
  pii: string
  latencyMs: number
  badge: BadgeKind
}

export interface SourceConnector {
  code: string
  name: string
  color: string
  kind: string
  entities: string
  crawler: string
  lastSync: string
  freshness: string
  status: SyncStatus
  statusBadge: BadgeKind
  statusLabel: string
}

export interface Spine {
  id: string
  badge: string
  color: string
  value: string
  unit: string
  fill: number // 0..100
}

export interface Skill {
  icon: string
  name: string
  kind: string
  color: string
  desc: string
  usage: string
  status: 'verified' | 'review'
}

export interface ReviewItem {
  type: string
  title: string
  origin: string
  confidence: string
  badge: BadgeKind
}

export interface NavRoute {
  path: string
  label: string
  icon: string // lucide icon name
}
