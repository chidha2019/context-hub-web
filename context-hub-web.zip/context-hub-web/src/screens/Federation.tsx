import { useState, useMemo } from 'react'
import { ViewHeader, Card, Badge } from '../components/ui'
import { initialCatalogs, standards, type Catalog, type Standard } from '../data/strategy'

const CYCLE: Record<Catalog['state'], Catalog['state']> = { off: 'connected', connected: 'federated', federated: 'off' }
const stateBadge: Record<string, string> = { federated: 'b-ok', connected: 'b-sync', off: 'b-stale' }
const stateFactor: Record<string, number> = { federated: 1, connected: 0.5, off: 0 }

export default function Federation() {
  const [catalogs, setCatalogs] = useState<Catalog[]>(initialCatalogs)
  const [detail, setDetail] = useState<{ kind: 'catalog'; item: Catalog } | { kind: 'standard'; item: Standard } | null>(
    { kind: 'catalog', item: initialCatalogs[0] })

  const totalWeight = initialCatalogs.reduce((a, c) => a + c.weight, 0)
  const coverage = useMemo(
    () => Math.round(catalogs.reduce((a, c) => a + c.weight * stateFactor[c.state], 0) / totalWeight * 100),
    [catalogs, totalWeight])

  const cycle = (id: string) => setCatalogs((L) => L.map((c) => (c.id === id ? { ...c, state: CYCLE[c.state] } : c)))

  return (
    <>
      <ViewHeader title="CATALOG FEDERATION & STANDARDS" sub="ride the catalogs, don’t re-crawl · toggle a source to see coverage change" />

      {/* live coverage gauge */}
      <div className="grid gap-3" style={{ gridTemplateColumns: '260px 1fr' }}>
        <div className="card flex flex-col items-center justify-center" style={{ minHeight: 150 }}>
          <div className="mono" style={{ fontSize: 9, letterSpacing: 1.5, color: 'var(--faint)' }}>FEDERATED COVERAGE</div>
          <div className="mono font-semibold" style={{ fontSize: 46, color: coverage > 75 ? 'var(--green)' : coverage > 45 ? 'var(--cyan)' : 'var(--amber)', lineHeight: 1.1 }}>{coverage}%</div>
          <div className="w-full mt-2"><div className="meter" style={{ height: 7 }}><i style={{ width: `${coverage}%`, background: coverage > 75 ? 'var(--green)' : 'var(--cyan)' }} /></div></div>
          <div className="mono mt-2" style={{ fontSize: 9, color: 'var(--faint)' }}>{catalogs.filter((c) => c.state !== 'off').length}/{catalogs.length} catalogs active</div>
        </div>
        <div className="card flex items-center">
          <div className="grid w-full gap-3" style={{ gridTemplateColumns: '1fr 0.12fr 1fr 0.12fr 1fr' }}>
            <div><div className="mono" style={{ fontSize: 9, letterSpacing: 1.5, color: 'var(--faint)' }}>RAW SOURCES</div><div style={{ fontSize: 11.5, color: 'var(--dim)', marginTop: 3 }}>MDM · Lake · apps · Git · Jira</div></div>
            <div className="grid place-items-center"><span className="mono" style={{ fontSize: 20, color: 'var(--faint)' }}>→</span></div>
            <div><div className="mono" style={{ fontSize: 9, letterSpacing: 1.5, color: 'var(--teal)' }}>EXISTING CATALOGS</div><div style={{ fontSize: 11.5, color: '#d3e0ec', marginTop: 3 }}>already own governance + lineage</div></div>
            <div className="grid place-items-center"><span className="mono" style={{ fontSize: 20, color: 'var(--cyan)' }}>→</span></div>
            <div><div className="mono" style={{ fontSize: 9, letterSpacing: 1.5, color: 'var(--cyan)' }}>CONTEXTHUB</div><div style={{ fontSize: 11.5, color: '#eaf6ff', marginTop: 3 }}>federate · resolve · govern · serve</div></div>
          </div>
        </div>
      </div>

      <div className="grid gap-3 mt-3" style={{ gridTemplateColumns: '1fr 1fr 300px' }}>
        {/* catalogs with real toggles */}
        <Card title="Federated catalogs" extra="click badge to cycle state">
          {catalogs.map((c) => (
            <div key={c.id} className="flex items-center gap-2.5 py-2.5 cursor-pointer" style={{ borderBottom: '1px solid var(--line)' }} onClick={() => setDetail({ kind: 'catalog', item: c })}>
              <span className="w-[26px] h-[26px] rounded-[6px] grid place-items-center mono font-bold flex-none" style={{ fontSize: 9, color: 'var(--teal)', border: '1px solid var(--line2)' }}>{c.name.slice(0, 2).toUpperCase()}</span>
              <div className="flex-1 min-w-0">
                <div style={{ fontSize: 12, color: '#d3e0ec' }}>{c.name}</div>
                <div className="mono" style={{ fontSize: 9, color: 'var(--faint)' }}>{c.kind} · weight {c.weight}</div>
              </div>
              <button onClick={(e) => { e.stopPropagation(); cycle(c.id) }} title="cycle state"><Badge kind={stateBadge[c.state]}>{c.state}</Badge></button>
            </div>
          ))}
        </Card>

        {/* standards */}
        <Card title="Open standards adoption" extra="click to inspect">
          <div className="flex flex-col gap-2.5 mt-1">
            {standards.map((s) => (
              <div key={s.id} className="cursor-pointer" onClick={() => setDetail({ kind: 'standard', item: s })}>
                <div className="flex justify-between mb-1"><span style={{ fontSize: 11.5, color: '#d3e0ec' }}>{s.name}</span><span className="mono" style={{ fontSize: 10, color: 'var(--cyan)' }}>{s.pct}%</span></div>
                <div className="meter"><i style={{ width: `${s.pct}%`, background: 'linear-gradient(90deg,#2f6b78,#55b8c9)' }} /></div>
              </div>
            ))}
          </div>
        </Card>

        {/* detail drawer */}
        <Card className="self-start" title={detail?.kind === 'standard' ? 'Standard' : 'Catalog'} extra="detail">
          {detail?.kind === 'catalog' && (
            <>
              <div style={{ fontSize: 14, color: '#eaf6ff', fontWeight: 600, marginBottom: 4 }}>{detail.item.name}</div>
              <div className="mono mb-3" style={{ fontSize: 10, color: 'var(--dim)' }}>{detail.item.kind} · state {detail.item.state}</div>
              <div className="mono" style={{ fontSize: 9, letterSpacing: 1, color: 'var(--faint)' }}>CONTRIBUTES</div>
              <div className="flex flex-col gap-1.5 mt-2">
                {detail.item.contributes.map((x) => (
                  <div key={x} className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full" style={{ background: 'var(--teal)' }} /><span style={{ fontSize: 11.5, color: '#d3e0ec' }}>{x}</span></div>
                ))}
              </div>
              <div className="mono mt-3" style={{ fontSize: 9.5, color: 'var(--faint)' }}>ContextHub reads this — it does not re-ingest the raw source.</div>
            </>
          )}
          {detail?.kind === 'standard' && (
            <>
              <div style={{ fontSize: 14, color: '#eaf6ff', fontWeight: 600, marginBottom: 4 }}>{detail.item.name}</div>
              <div className="mono mb-3" style={{ fontSize: 10, color: 'var(--dim)' }}>{detail.item.body} · {detail.item.pct}% adoption</div>
              <div className="mono" style={{ fontSize: 9, letterSpacing: 1, color: 'var(--faint)' }}>ENABLES</div>
              <div style={{ fontSize: 12, color: '#d3e0ec', marginTop: 4, lineHeight: 1.5 }}>{detail.item.enables}</div>
            </>
          )}
        </Card>
      </div>

      <div className="rounded-[10px] p-3.5 mt-3" style={{ background: 'rgba(85,184,201,0.05)', border: '1px solid rgba(85,184,201,0.28)' }}>
        <div style={{ fontSize: 12, color: 'var(--text)', lineHeight: 1.5 }}>
          <b style={{ color: 'var(--cyan)' }}>Try it:</b> toggle catalogs off and watch coverage drop — that’s the point. Federating over the catalogs an enterprise already runs, plus speaking MCP / OSI / OpenLineage, is what makes ContextHub the cross-platform layer instead of a 41st silo.
        </div>
      </div>
    </>
  )
}
