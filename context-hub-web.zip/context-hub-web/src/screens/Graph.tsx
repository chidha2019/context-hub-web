import { useEffect, useMemo, useState } from 'react'
import { ViewHeader, Card, Btn } from '../components/ui'
import GraphCanvas from '../components/GraphCanvas'
import { usePersona } from '../PersonaContext'
import { getGraph, type GraphEdge, type GraphNode } from '../api/client'

const TYPE_COLORS: Record<string, string> = {
  Document: '#55b8c9', Issue: '#6f9fe0', Person: '#d6a45c', Service: '#6cc08d', Customer: '#a98cd6',
}

export default function Graph() {
  const { persona } = usePersona()
  const [nodes, setNodes] = useState<GraphNode[]>([])
  const [edges, setEdges] = useState<GraphEdge[]>([])
  const [error, setError] = useState<string | null>(null)
  const [activeTypes, setActiveTypes] = useState<Set<string>>(new Set())
  const [selectedId, setSelectedId] = useState<string | null>(null)

  useEffect(() => {
    getGraph(persona.id)
      .then((d) => {
        setNodes(d.nodes)
        setEdges(d.edges)
        setActiveTypes(new Set(d.nodes.map((n) => n.type)))
        setSelectedId(null)
      })
      .catch((e) => setError(e instanceof Error ? e.message : String(e)))
  }, [persona.id])

  const layers = useMemo(() => {
    const counts = new Map<string, number>()
    for (const n of nodes) counts.set(n.type, (counts.get(n.type) ?? 0) + 1)
    return Array.from(counts.entries()).map(([name, count]) => ({
      name, count, color: TYPE_COLORS[name] ?? '#9aa4b0', on: activeTypes.has(name),
    }))
  }, [nodes, activeTypes])

  const toggleLayer = (name: string) => {
    setActiveTypes((prev) => {
      const next = new Set(prev)
      if (next.has(name)) next.delete(name); else next.add(name)
      return next
    })
  }

  const visibleNodes = useMemo(() => nodes.filter((n) => activeTypes.has(n.type)), [nodes, activeTypes])
  const visibleIds = useMemo(() => new Set(visibleNodes.map((n) => n.id)), [visibleNodes])
  const visibleEdges = useMemo(
    () => edges.filter((e) => visibleIds.has(e.source) && visibleIds.has(e.target)),
    [edges, visibleIds],
  )

  const selected = nodes.find((n) => n.id === selectedId) ?? null
  const relationBreakdown = useMemo(() => {
    if (!selected) return []
    const counts = new Map<string, number>()
    for (const e of edges) {
      if (e.source === selected.id || e.target === selected.id) {
        counts.set(e.rel, (counts.get(e.rel) ?? 0) + 1)
      }
    }
    return Array.from(counts.entries())
  }, [selected, edges])

  return (
    <>
      <ViewHeader
        title="KNOWLEDGE GRAPH EXPLORER"
        sub={`${nodes.length} nodes · ${edges.length} edges · governed for ${persona.name}`}
        actions={<><Btn variant="ghost">Depth 2 ▾</Btn><Btn>Save view</Btn></>}
      />

      {error && (
        <div className="card mb-3" style={{ borderColor: 'var(--red)', color: 'var(--red)', fontSize: 12 }}>
          {error} — is the backend running at localhost:8080?
        </div>
      )}

      <div className="grid gap-3" style={{ gridTemplateColumns: '210px 1fr 280px', height: 'calc(100vh - 150px)' }}>
        <Card title="Entity Layers">
          <div className="flex flex-col gap-1.5 overflow-y-auto">
            {layers.map((g) => (
              <div key={g.name} className="flex items-center gap-2.5 px-2 py-[7px] rounded-md cursor-pointer hover:bg-white/[0.03]" onClick={() => toggleLayer(g.name)}>
                <span className="w-[9px] h-[9px] rounded-full flex-none" style={{ background: g.color }} />
                <span className="flex-1" style={{ fontSize: 11.5 }}>{g.name}</span>
                <span className="mono" style={{ fontSize: 9.5, color: 'var(--faint)' }}>{g.count}</span>
                <span className={`tog ${g.on ? 'on' : ''}`} />
              </div>
            ))}
          </div>
        </Card>

        <GraphCanvas
          label="CLICK NODE TO INSPECT"
          nodes={visibleNodes}
          edges={visibleEdges}
          selectedId={selectedId ?? undefined}
          onNodeClick={setSelectedId}
        />

        <Card title="Node Inspector" extra={selected ? <span style={{ color: 'var(--green)' }}>{selected.type}</span> : undefined}>
          {!selected && <div style={{ fontSize: 11.5, color: 'var(--dim)' }}>Click a node in the graph to inspect it.</div>}
          {selected && (
            <>
              <div className="flex items-center gap-2.5 mb-2.5">
                <span className="w-3 h-3 rounded-full" style={{ background: TYPE_COLORS[selected.type] ?? '#9aa4b0' }} />
                <b style={{ color: '#eaf6ff', fontSize: 14 }}>{selected.label}</b>
              </div>
              <div className="flex justify-between mono py-1.5" style={{ fontSize: 10.5, borderBottom: '1px dashed var(--line)' }}>
                <span style={{ color: 'var(--faint)' }}>type</span><span>{selected.type}</span>
              </div>
              <div className="flex justify-between mono py-1.5" style={{ fontSize: 10.5, borderBottom: '1px dashed var(--line)' }}>
                <span style={{ color: 'var(--faint)' }}>edges</span><span>{selected.degree}</span>
              </div>
              {selected.source && (
                <div className="flex justify-between mono py-1.5" style={{ fontSize: 10.5, borderBottom: '1px dashed var(--line)' }}>
                  <span style={{ color: 'var(--faint)' }}>source</span><span>{selected.source} · {selected.classification}</span>
                </div>
              )}
              {relationBreakdown.length > 0 && (
                <div className="flex justify-between mono py-1.5" style={{ fontSize: 10.5, borderBottom: '1px dashed var(--line)' }}>
                  <span style={{ color: 'var(--faint)' }}>relations</span>
                  <span>{relationBreakdown.map(([rel, n]) => `${rel} × ${n}`).join(', ')}</span>
                </div>
              )}
              {selected.aliases && selected.aliases.length > 0 && (
                <div className="py-1.5" style={{ fontSize: 10.5 }}>
                  <span style={{ color: 'var(--faint)' }}>aliases</span>
                  <div className="mt-1 flex flex-col gap-1">
                    {selected.aliases.map((a, i) => (
                      <div key={i} className="mono" style={{ fontSize: 10, color: 'var(--dim)' }}>{a.source} · {a.raw_name}</div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </Card>
      </div>
    </>
  )
}
