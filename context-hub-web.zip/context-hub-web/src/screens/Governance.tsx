import { useCallback, useEffect, useState } from 'react'
import { ViewHeader, Stat, Btn, Badge } from '../components/ui'
import { usePersona } from '../PersonaContext'
import { getAudit, getGovernanceStats, type GovernanceStats, type ServeEventOut } from '../api/client'

export default function Governance() {
  const { persona } = usePersona()
  const [stats, setStats] = useState<GovernanceStats | null>(null)
  const [events, setEvents] = useState<ServeEventOut[]>([])
  const [error, setError] = useState<string | null>(null)

  const refresh = useCallback(async () => {
    try {
      const [s, a] = await Promise.all([
        getGovernanceStats(persona.id),
        getAudit(persona.id, 50),
      ])
      setStats(s)
      setEvents(a)
      setError(null)
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }, [persona.id])

  useEffect(() => {
    refresh()
  }, [refresh])

  const auditedPct = stats && stats.total > 0 ? '100%' : '—'
  const piiTotal = stats ? stats.pii_total.toLocaleString() : '—'

  return (
    <>
      <ViewHeader
        title="GOVERNANCE & AUDIT"
        sub="zero-trust serving · every request logged · EU AI Act register"
        actions={<><Btn variant="ghost" onClick={refresh}>Refresh</Btn><Btn variant="ghost">Entitlements</Btn><Btn>AI Act Register</Btn></>}
      />

      {error && (
        <div className="card mb-3" style={{ borderColor: 'var(--red)', color: 'var(--red)', fontSize: 12 }}>
          {error} — is the backend running at localhost:8080?
        </div>
      )}

      <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(4,1fr)' }}>
        <Stat n={auditedPct} label="Requests Audited" color="gr" detail={stats ? `${stats.total} total` : '—'} />
        <Stat n={stats ? String(stats.denied) : '—'} label="Denied Serves" color="cy" detail="ACL" />
        <Stat n={piiTotal} label="PII Fields Masked" color="mg" detail="cumulative" />
        <Stat n={stats ? String(stats.blocked) : '—'} label="Injection Attempts Blocked" color="am" detail="cumulative" />
      </div>

      <div className="card p-0 mt-3">
        <div className="card-h p-[12px_14px_8px]"><span className="card-t">Audit Trail · live</span><span className="card-x">{events.length} rows</span></div>
        <table className="tbl">
          <thead><tr><th>Time</th><th>Persona</th><th>Action</th><th>Asset</th><th>ACL</th><th>PII</th><th>Latency</th></tr></thead>
          <tbody>
            {events.length === 0 && (
              <tr><td colSpan={7} style={{ color: 'var(--dim)', textAlign: 'center', padding: 16 }}>No serve events yet — ask a question in Ask to generate one.</td></tr>
            )}
            {events.map((e, i) => (
              <tr key={i}>
                <td className="mono" style={{ color: 'var(--faint)' }}>{e.ts}</td>
                <td className="mono" style={{ color: 'var(--magenta)' }}>{e.persona}</td>
                <td className="mono">{e.action}</td>
                <td>{e.asset}</td>
                <td><Badge kind={e.acl === 'allowed' ? 'b-ok' : 'b-err'}>{e.acl}</Badge></td>
                <td className="mono" style={{ color: 'var(--dim)' }}>{e.pii_masked > 0 ? `${e.pii_masked} masked` : '—'}</td>
                <td className="mono text-right">{e.latency_ms}ms</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}
