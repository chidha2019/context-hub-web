import { ViewHeader, Btn, Badge } from '../components/ui'
import { skills } from '../data/mock'

export default function Skills() {
  return (
    <>
      <ViewHeader
        title="SKILLS & MCP REGISTRY"
        sub="governed capability marketplace · 64 skills · 21 MCP tools · enables FDE ops"
        actions={<><Btn variant="ghost">Category ▾</Btn><Btn variant="pri">+ Publish</Btn></>}
      />
      <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(3,1fr)' }}>
        {skills.map((s) => (
          <div key={s.name} className="card">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-[30px] h-[30px] rounded-[7px] grid place-items-center mono font-bold" style={{ fontSize: 12, color: s.color, border: '1px solid var(--line2)' }}>{s.icon}</span>
              <div>
                <div style={{ fontSize: 12.5, color: '#eaf6ff', fontWeight: 600 }}>{s.name}</div>
                <div className="mono" style={{ fontSize: 9, color: 'var(--faint)' }}>{s.kind}</div>
              </div>
            </div>
            <div className="mb-2.5" style={{ fontSize: 11, color: 'var(--dim)', lineHeight: 1.45 }}>{s.desc}</div>
            <div className="flex items-center gap-2 mono" style={{ fontSize: 9, color: 'var(--faint)' }}>
              <Badge kind={s.status === 'verified' ? 'b-ok' : 'b-stale'}>{s.status}</Badge>
              <span className="ml-auto">{s.usage}</span>
              <span>· guardrails ✓</span>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
