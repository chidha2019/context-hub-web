import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowRight, Radio } from 'lucide-react'
import GraphCanvas from '../components/GraphCanvas'
import LiveFeed from '../components/LiveFeed'
import { graphLayers } from '../data/mock'
import { usePersona } from '../PersonaContext'
import { getOverview, type OverviewResponse } from '../api/client'

const LEGEND = [
  ['Document', '#55b8c9'], ['Entity', '#a98cd6'], ['Service', '#6cc08d'], ['Person', '#d6a45c'], ['PII', '#d97a86'],
] as const

export default function Overview() {
  const { persona } = usePersona()
  const nav = useNavigate()
  const [layers, setLayers] = useState(graphLayers)
  const toggle = (i: number) => setLayers((L) => L.map((l, k) => (k === i ? { ...l, on: !l.on } : l)))

  const [globals, setGlobals] = useState<OverviewResponse | null>(null)
  useEffect(() => {
    getOverview(persona.id).then(setGlobals).catch(() => {})
  }, [persona.id])

  const GLOBALS = [
    { n: globals ? String(globals.entities) : '—', l: 'Entities' },
    { n: globals ? String(globals.relations) : '—', l: 'Relations' },
    { n: globals ? String(globals.served_24h) : '—', l: 'Served/24h' },
  ]

  return (
    <div className="relative w-full h-full">
      {/* Full-bleed live graph = the "map" */}
      <GraphCanvas fill label="" />
      <div className="scanline" />

      {/* ===== TOP STATUS STRIP ===== */}
      <div className="absolute top-0 left-0 right-0 flex items-center gap-4 px-4 py-2.5 z-[4]"
        style={{ background: 'linear-gradient(180deg,rgba(6,11,18,0.85),rgba(6,11,18,0.35))', borderBottom: '1px solid var(--line)' }}>
        <span className="w-8 h-8 rounded-[8px] grid place-items-center mono font-bold flex-none" style={{ fontSize: 12, color: '#04121a', background: persona.color }}>{persona.initials}</span>
        <div className="min-w-0">
          <div className="mono flex items-center gap-2" style={{ fontSize: 12, letterSpacing: 1.5, color: '#eaf6ff' }}>
            COMMAND CENTER
            <span style={{ color: persona.color }}>· {persona.name.toUpperCase()} WATCH</span>
          </div>
          <div className="mono" style={{ fontSize: 9, color: 'var(--faint)', letterSpacing: 0.5 }}>{persona.tagline}</div>
        </div>

        <div className="ml-auto flex items-center gap-5">
          {GLOBALS.map((g) => (
            <div key={g.l} className="text-right leading-none">
              <div className="mono font-semibold" style={{ fontSize: 14, color: '#dfeaf5' }}>{g.n}</div>
              <div className="hud-label" style={{ marginTop: 3 }}>{g.l}</div>
            </div>
          ))}
          <div className="mono flex items-center gap-1.5 px-2.5 py-1 rounded-md" style={{ fontSize: 9, color: 'var(--red)', border: '1px solid rgba(217,122,134,0.35)' }}>
            <Radio size={11} /> LIVE
          </div>
        </div>
      </div>

      {/* ===== LEFT: ENTITY LAYERS ===== */}
      <div className="hud absolute z-[4] flex flex-col" style={{ top: 70, left: 14, width: 210, bottom: 92 }}>
        <div className="flex items-center justify-between px-3 pt-2.5 pb-2" style={{ borderBottom: '1px solid var(--line)' }}>
          <span className="hud-label">Entity Layers</span>
          <span className="mono" style={{ fontSize: 8.5, color: 'var(--cyan)' }}>{layers.filter((l) => l.on).length}/{layers.length} ON</span>
        </div>
        <div className="flex-1 overflow-y-auto px-1.5 py-1.5">
          {layers.map((g, i) => (
            <div key={g.name} className="flex items-center gap-2.5 px-1.5 py-[7px] rounded-md cursor-pointer hover:bg-white/[0.04]" onClick={() => toggle(i)} style={{ opacity: g.on ? 1 : 0.45 }}>
              <span className="w-2.5 h-2.5 rounded-full flex-none" style={{ background: g.color }} />
              <span className="flex-1 truncate" style={{ fontSize: 11, color: '#d3e0ec' }}>{g.name}</span>
              <span className="mono" style={{ fontSize: 9, color: 'var(--faint)' }}>{g.count}</span>
            </div>
          ))}
        </div>
        <div className="px-3 py-2 mono" style={{ fontSize: 8.5, color: 'var(--faint)', borderTop: '1px solid var(--line)' }}>
          FOCUS · <span style={{ color: persona.color }}>{persona.name}</span> · depth 2
        </div>
      </div>

      {/* ===== RIGHT: WATCH BOARD + LIVE FEED ===== */}
      <div className="absolute z-[4] flex flex-col gap-2.5" style={{ top: 70, right: 14, width: 320, bottom: 92 }}>
        <div className="hud flex flex-col" style={{ maxHeight: '50%' }}>
          <div className="flex items-center justify-between px-3 pt-2.5 pb-2" style={{ borderBottom: '1px solid var(--line)' }}>
            <span className="hud-label">Watch · {persona.board.title}</span>
            <span className="mono" style={{ fontSize: 8.5, color: persona.color }}>{persona.board.extra}</span>
          </div>
          <div className="flex-1 overflow-y-auto px-3 py-1">
            {persona.board.rows.map((r) => (
              <div key={r.label} className="flex items-center gap-2 py-2" style={{ borderBottom: '1px solid var(--line)' }}>
                <span className="w-1.5 h-1.5 rounded-full flex-none" style={{ background: persona.color }} />
                <span className="flex-1 truncate" style={{ fontSize: 11, color: '#d3e0ec' }}>{r.label}</span>
                <span className="mono" style={{ fontSize: 9, color: 'var(--dim)' }}>{r.value}</span>
                <span className={`badge ${r.badge}`}>{r.badge.replace('b-', '')}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="hud flex flex-col flex-1 min-h-0">
          <div className="flex items-center justify-between px-3 pt-2.5 pb-2" style={{ borderBottom: '1px solid var(--line)' }}>
            <span className="hud-label">Live Context Feed</span>
            <span className="mono" style={{ fontSize: 8.5, color: 'var(--red)' }}>● STREAM</span>
          </div>
          <div className="flex flex-col flex-1 min-h-0 px-3 py-1"><LiveFeed /></div>
          <button onClick={() => nav(persona.home)} className="btn btn-pri m-2 flex items-center justify-center gap-1.5">Open {persona.name} workspace <ArrowRight size={13} /></button>
        </div>
      </div>

      {/* ===== BOTTOM: MISSION METRICS STATUS BAR ===== */}
      <div className="hud absolute z-[4] flex items-center gap-5 px-4" style={{ left: 14, right: 14, bottom: 14, height: 66 }}>
        {persona.kpis.map((k) => (
          <div key={k.label} className="leading-none flex-none">
            <div className="mono font-semibold" style={{ fontSize: 16, color: '#eaf6ff' }}>{k.n}</div>
            <div className="hud-label" style={{ marginTop: 4 }}>{k.label}</div>
          </div>
        ))}
        <div className="ml-auto flex items-center gap-3.5 flex-none">
          {LEGEND.map(([name, color]) => (
            <span key={name} className="mono flex items-center gap-1.5" style={{ fontSize: 9, color: 'var(--dim)' }}>
              <span className="w-2 h-2 rounded-full" style={{ background: color }} />{name}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
