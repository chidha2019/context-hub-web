import { useEffect, useState } from 'react'
import { ViewHeader, Stat, Card } from '../components/ui'
import { usePersona } from '../PersonaContext'
import { getMeasure, type MeasureResponse } from '../api/client'

export default function Measure() {
  const { persona } = usePersona()
  const [data, setData] = useState<MeasureResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    getMeasure(persona.id).then(setData).catch((e) => setError(e instanceof Error ? e.message : String(e)))
  }, [persona.id])

  const overall = data?.overall

  return (
    <>
      <ViewHeader
        title="MEASURE · GOVERNANCE ACTIVITY"
        sub="derived from the serve-event audit log — no numbers asserted"
      />

      {error && (
        <div className="card mb-3" style={{ borderColor: 'var(--red)', color: 'var(--red)', fontSize: 12 }}>
          {error} — is the backend running at localhost:8080?
        </div>
      )}

      <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(3,1fr)' }}>
        <Stat n={overall ? String(overall.total) : '—'} label="Total Served" color="cy" />
        <Stat n={overall ? `${overall.avg_latency_ms}ms` : '—'} label="Avg Latency" color="gr" />
        <Stat n={overall ? String(overall.pii_total) : '—'} label="PII Fields Masked" color="mg" />
      </div>

      <div className="card p-0 mt-3">
        <div className="card-h p-[12px_14px_8px]"><span className="card-t">Per-Persona Activity</span></div>
        <table className="tbl">
          <thead><tr><th>Persona</th><th>Requests</th><th>Avg Latency</th><th>PII Masked</th><th>Denied</th></tr></thead>
          <tbody>
            {(data?.by_persona ?? []).map((p) => (
              <tr key={p.persona}>
                <td className="mono" style={{ color: 'var(--magenta)' }}>{p.persona}</td>
                <td className="mono">{p.requests}</td>
                <td className="mono">{p.avg_latency_ms}ms</td>
                <td className="mono" style={{ color: 'var(--dim)' }}>{p.pii_masked}</td>
                <td className="mono">{p.denied}</td>
              </tr>
            ))}
            {data && data.by_persona.length === 0 && (
              <tr><td colSpan={5} style={{ color: 'var(--dim)', textAlign: 'center', padding: 16 }}>No serve events yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </>
  )
}
