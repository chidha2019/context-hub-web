import { useEffect, useState } from 'react'
import { ViewHeader, Card, Btn, Badge } from '../components/ui'
import { usePersona } from '../PersonaContext'
import { getSources, type SourcesResponse } from '../api/client'

const CLASSIFICATION_BADGE: Record<string, 'b-ok' | 'b-sync' | 'b-pii'> = {
  public: 'b-ok',
  internal: 'b-sync',
  confidential: 'b-pii',
}

export default function Sources() {
  const { persona } = usePersona()
  const [data, setData] = useState<SourcesResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    getSources(persona.id).then(setData).catch((e) => setError(e instanceof Error ? e.message : String(e)))
  }, [persona.id])

  const connectors = data?.connectors ?? []
  const totalDocs = connectors.reduce((sum, c) => sum + c.document_count, 0)
  const totalChunks = connectors.reduce((sum, c) => sum + c.chunk_count, 0)

  return (
    <>
      <ViewHeader
        title="SOURCES & CONNECTORS"
        sub={`${connectors.length} governed connectors · corpus generated ${data?.corpus_generated_at ?? '—'}`}
        actions={<><Btn variant="ghost">Filter ▾</Btn><Btn variant="pri">+ Add Source</Btn></>}
      />

      {error && (
        <div className="card mb-3" style={{ borderColor: 'var(--red)', color: 'var(--red)', fontSize: 12 }}>
          {error} — is the backend running at localhost:8080?
        </div>
      )}

      <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 260px' }}>
        <div className="card p-0">
          <table className="tbl">
            <thead><tr><th>Source</th><th>Documents</th><th>Chunks</th><th>Classifications</th></tr></thead>
            <tbody>
              {connectors.map((c) => (
                <tr key={c.id}>
                  <td>
                    <span className="inline-grid place-items-center w-[22px] h-[22px] rounded-[5px] mono font-bold mr-2 align-middle" style={{ fontSize: 9, color: 'var(--cyan)', border: '1px solid var(--line2)' }}>{c.name[0]}</span>
                    {c.name}
                  </td>
                  <td className="mono">{c.document_count}</td>
                  <td className="mono">{c.chunk_count}</td>
                  <td>
                    <div className="flex gap-1.5">
                      {Object.entries(c.classifications).map(([kind, count]) => (
                        <Badge key={kind} kind={CLASSIFICATION_BADGE[kind] ?? 'b-sync'}>{kind} · {count}</Badge>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
              {connectors.length === 0 && !error && (
                <tr><td colSpan={4} style={{ color: 'var(--dim)', textAlign: 'center', padding: 16 }}>Loading…</td></tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex flex-col gap-3">
          <Card title="Corpus Totals">
            <div className="mono" style={{ fontSize: 10, color: 'var(--dim)', lineHeight: 2 }}>
              documents <b style={{ color: 'var(--cyan)' }}>{totalDocs}</b><br />
              chunks <b style={{ color: 'var(--text)' }}>{totalChunks}</b><br />
              connectors <b style={{ color: 'var(--text)' }}>{connectors.length}</b>
            </div>
          </Card>
        </div>
      </div>
    </>
  )
}
