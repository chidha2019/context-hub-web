import { useNavigate } from 'react-router-dom'
import { ArrowRight, Check } from 'lucide-react'
import { ViewHeader, Badge } from '../components/ui'
import { usePersona } from '../PersonaContext'

export default function Personas() {
  const { persona, setPersona, all } = usePersona()
  const nav = useNavigate()

  const enter = (id: string, home: string) => { setPersona(id); nav(home) }

  return (
    <>
      <ViewHeader title="PERSONAS" sub={`${all.length} governed workspaces · each with its own surfaces, consumers, skills & access`} />

      <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(4,1fr)' }}>
        {all.map((p) => {
          const active = p.id === persona.id
          return (
            <div key={p.id} className="card flex flex-col" style={{ borderColor: active ? p.color : 'var(--line)', borderLeft: `3px solid ${p.color}` }}>
              <div className="flex items-center gap-2.5 mb-2.5">
                <span className="w-9 h-9 rounded-[8px] grid place-items-center mono font-bold flex-none" style={{ fontSize: 12, color: '#04121a', background: p.color }}>{p.initials}</span>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5"><span style={{ fontSize: 13, color: '#eaf6ff', fontWeight: 600 }}>{p.name}</span>{active && <Check size={13} color={p.color} />}</div>
                  <div className="mono" style={{ fontSize: 8.5, color: 'var(--faint)' }}>{active ? 'ACTIVE WORKSPACE' : 'workspace'}</div>
                </div>
              </div>
              <div style={{ fontSize: 11, color: 'var(--dim)', lineHeight: 1.45, minHeight: 46 }}>{p.tagline}</div>

              <div className="mono mt-2" style={{ fontSize: 8.5, letterSpacing: 1, color: 'var(--faint)', textTransform: 'uppercase' }}>Consumers</div>
              <div className="flex flex-col gap-1 mt-1.5 mb-2">
                {p.consumers.map((c) => (
                  <div key={c.name} className="flex items-center justify-between">
                    <span style={{ fontSize: 11, color: '#d3e0ec' }}>{c.name}</span>
                    <span className="mono" style={{ fontSize: 8.5, color: 'var(--faint)' }}>{c.surface}</span>
                  </div>
                ))}
              </div>

              <div className="mono" style={{ fontSize: 8.5, letterSpacing: 1, color: 'var(--faint)', textTransform: 'uppercase' }}>Skills</div>
              <div className="flex flex-wrap gap-1 mt-1.5 mb-2">
                {p.skills.map((s) => <span key={s} className="mono" style={{ fontSize: 9, color: p.color, border: `1px solid var(--line2)`, borderRadius: 4, padding: '1px 6px' }}>{s}</span>)}
              </div>

              <div className="mono" style={{ fontSize: 8.5, letterSpacing: 1, color: 'var(--faint)', textTransform: 'uppercase' }}>Spines</div>
              <div className="flex flex-wrap gap-1 mt-1.5 mb-3">
                {p.spines.map((s) => <Badge key={s} kind="b-pii">{s}</Badge>)}
              </div>

              <div className="mono mb-3" style={{ fontSize: 9.5, color: 'var(--dim)', lineHeight: 1.5 }}>
                <span style={{ color: 'var(--faint)' }}>access · </span>{p.access}
              </div>

              <button onClick={() => enter(p.id, p.home)}
                className={`btn ${active ? 'btn-ghost' : 'btn-pri'} mt-auto flex items-center justify-center gap-1.5`}>
                {active ? 'Current workspace' : <>Enter workspace <ArrowRight size={13} /></>}
              </button>
            </div>
          )
        })}
      </div>
    </>
  )
}
