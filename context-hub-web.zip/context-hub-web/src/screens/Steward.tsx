import { useEffect, useState } from 'react'
import { ViewHeader, Card, Btn, Badge } from '../components/ui'
import { usePersona } from '../PersonaContext'
import { approveReview, getStewardQueue, rejectReview, type StewardItem } from '../api/client'

function confidenceBadge(confidence: number): 'b-ok' | 'b-sync' | 'b-stale' {
  if (confidence >= 0.75) return 'b-ok'
  if (confidence >= 0.6) return 'b-sync'
  return 'b-stale'
}

export default function Steward() {
  const { persona } = usePersona()
  const [items, setItems] = useState<StewardItem[]>([])
  const [selId, setSelId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const refresh = () => {
    getStewardQueue(persona.id)
      .then((data) => {
        setItems(data)
        setSelId((prev) => (prev && data.some((d) => d.id === prev) ? prev : (data[0]?.id ?? null)))
      })
      .catch((e) => setError(e instanceof Error ? e.message : String(e)))
  }

  useEffect(refresh, [persona.id])

  const q = items.find((i) => i.id === selId) ?? null

  async function act(action: 'approve' | 'reject') {
    if (!q || busy) return
    setBusy(true)
    try {
      await (action === 'approve' ? approveReview(q.id, persona.id) : rejectReview(q.id, persona.id))
      refresh()
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <ViewHeader
        title="STEWARD REVIEW & APPROVE"
        sub={`human-in-the-loop · ${items.length} items pending`}
        actions={<Btn variant="ghost">Bulk approve</Btn>}
      />

      {error && (
        <div className="card mb-3" style={{ borderColor: 'var(--red)', color: 'var(--red)', fontSize: 12 }}>
          {error} — is the backend running at localhost:8080?
        </div>
      )}

      <div className="grid gap-3" style={{ gridTemplateColumns: '320px 1fr' }}>
        <div className="card p-2">
          <div className="card-h px-1.5 pt-1.5 pb-2.5"><span className="card-t">Review Queue · {items.length}</span><span className="card-x">by confidence ▾</span></div>
          {items.length === 0 && <div style={{ fontSize: 11.5, color: 'var(--dim)', padding: '8px 8px' }}>No pending items.</div>}
          {items.map((item) => (
            <div key={item.id} onClick={() => setSelId(item.id)} className="flex items-center gap-2 px-2 py-2.5 rounded-[7px] cursor-pointer"
              style={{ background: item.id === selId ? 'rgba(85,184,201,0.07)' : 'transparent' }}>
              <Badge kind={confidenceBadge(item.confidence)}>{item.proposal.entity_type}</Badge>
              <span className="flex-1 truncate" style={{ fontSize: 11, color: '#d3e0ec' }}>{item.title}</span>
              <span className="mono" style={{ fontSize: 10, color: 'var(--dim)' }}>{item.confidence.toFixed(2)}</span>
            </div>
          ))}
        </div>

        <Card>
          {!q && <div style={{ fontSize: 11.5, color: 'var(--dim)' }}>Select an item from the queue.</div>}
          {q && (
            <>
              <div className="card-h"><span className="card-t">Review · {q.proposal.entity_type}</span><span className="card-x">confidence {q.confidence.toFixed(2)}</span></div>
              <div className="flex items-center gap-2.5 mb-3.5">
                <b style={{ fontSize: 15, color: '#eaf6ff' }}>{q.title}</b>
                <Badge kind={confidenceBadge(q.confidence)}>needs review</Badge>
              </div>
              <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
                <div className="rounded-lg p-3" style={{ border: '1px solid var(--line)' }}>
                  <div className="mono mb-2" style={{ fontSize: 9, color: 'var(--faint)', letterSpacing: 1 }}>CURRENT</div>
                  <div style={{ fontSize: 11.5, color: 'var(--dim)', lineHeight: 1.6 }}>
                    &lsquo;{q.proposal.raw_name}&rsquo; (from {q.proposal.source}) is not yet linked to any entity.
                  </div>
                </div>
                <div className="rounded-lg p-3" style={{ border: '1px solid rgba(108,192,141,0.3)', background: 'rgba(108,192,141,0.04)' }}>
                  <div className="mono mb-2" style={{ fontSize: 9, color: 'var(--green)', letterSpacing: 1 }}>PROPOSED</div>
                  <div style={{ fontSize: 11.5, color: '#d3e0ec', lineHeight: 1.6 }}>
                    Add as an alias of <b>{q.proposal.canonical}</b>.
                  </div>
                </div>
              </div>
              <div className="mono my-3.5" style={{ fontSize: 10, color: 'var(--faint)', lineHeight: 1.8 }}>
                provenance · {q.origin}<br />
                entity type · {q.proposal.entity_type} · confidence {q.confidence.toFixed(2)}
              </div>
              <div className="flex gap-2">
                <Btn variant="pri" onClick={() => act('approve')}>{busy ? '…' : 'Approve'}</Btn>
                <Btn>Edit</Btn>
                <Btn variant="ghost" onClick={() => act('reject')}>{busy ? '…' : 'Reject'}</Btn>
              </div>
            </>
          )}
        </Card>
      </div>
    </>
  )
}
