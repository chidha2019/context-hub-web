import { useState, useMemo } from 'react'
import { X, ArrowUpRight } from 'lucide-react'
import { ViewHeader, Card, Badge, Meter, Btn } from '../components/ui'
import { initialDomains, stageColor, stageBadge, type Domain } from '../data/strategy'

const FILTERS = ['All', 'Live', 'Scaling', 'Pilot', 'Next', 'Later']
const PROMOTE: Record<string, string> = { Later: 'Pilot', Pilot: 'Next', Next: 'Scaling', Scaling: 'Live', Live: 'Live' }
const buckets = [
  { title: 'NOW', color: '#6cc08d', stages: ['Live'] },
  { title: 'NEXT', color: '#55b8c9', stages: ['Scaling', 'Next'] },
  { title: 'LATER', color: '#46586b', stages: ['Pilot', 'Later'] },
]

export default function DomainProducts() {
  const [domains, setDomains] = useState<Domain[]>(initialDomains)
  const [filter, setFilter] = useState('All')
  const [selId, setSelId] = useState<string | null>(null)
  const sel = domains.find((d) => d.id === selId) || null
  const shown = filter === 'All' ? domains : domains.filter((d) => d.stage === filter)

  const kpis = useMemo(() => ({
    live: domains.filter((d) => d.stage === 'Live').length,
    maturity: Math.round(domains.reduce((a, d) => a + d.maturity, 0) / domains.length),
    agents: domains.reduce((a, d) => a + d.agents, 0),
    sources: new Set(domains.flatMap((d) => d.sources)).size,
  }), [domains])

  const promote = (id: string) => setDomains((L) => L.map((d) => {
    if (d.id !== id) return d
    const next = PROMOTE[d.stage]
    return { ...d, stage: next, maturity: Math.min(100, d.maturity + 18) }
  }))

  return (
    <>
      <ViewHeader title="DOMAIN CONTEXT PRODUCTS" sub="land-and-expand portfolio · click a product to drill in" />

      {/* live-recomputing KPIs */}
      <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(4,1fr)' }}>
        {[[kpis.live, 'Live products', 'gr'], [kpis.maturity + '%', 'Avg maturity', 'cy'], [kpis.agents, 'Agents served', 'mg'], [kpis.sources, 'Sources federated', 'bl']].map(([n, l, c]) => (
          <div key={l as string} className="stat"><div className="stat-n" style={{ color: `var(--${c === 'gr' ? 'green' : c === 'cy' ? 'cyan' : c === 'mg' ? 'magenta' : 'blue'})` }}>{n}</div><div className="stat-l">{l}</div></div>
        ))}
      </div>

      {/* filter chips */}
      <div className="flex items-center gap-2 mt-3">
        {FILTERS.map((f) => (
          <button key={f} onClick={() => setFilter(f)} className="mono cursor-pointer rounded-full px-3 py-1"
            style={{ fontSize: 10, letterSpacing: 0.5, color: filter === f ? 'var(--cyan)' : 'var(--dim)', border: `1px solid ${filter === f ? 'var(--cyan)' : 'var(--line2)'}`, background: filter === f ? 'rgba(85,184,201,0.08)' : 'transparent' }}>
            {f}{f !== 'All' ? ` · ${domains.filter((d) => d.stage === f).length}` : ''}
          </button>
        ))}
        <span className="mono ml-auto" style={{ fontSize: 9.5, color: 'var(--faint)' }}>scope → prove → expand · never boil the ocean</span>
      </div>

      <div className="grid gap-3 mt-3" style={{ gridTemplateColumns: sel ? '1fr 340px' : '1fr' }}>
        {/* portfolio grid */}
        <div className="grid gap-3" style={{ gridTemplateColumns: sel ? 'repeat(2,1fr)' : 'repeat(3,1fr)' }}>
          {shown.map((d) => (
            <div key={d.id} onClick={() => setSelId(d.id)} className="card cursor-pointer transition hover:-translate-y-0.5"
              style={{ borderColor: selId === d.id ? stageColor[d.stage] : 'var(--line)' }}>
              <div className="flex items-center gap-2.5 mb-2">
                <span className="w-2.5 h-2.5 rounded-full flex-none" style={{ background: stageColor[d.stage] }} />
                <span className="flex-1 truncate" style={{ fontSize: 13, color: '#eaf6ff', fontWeight: 600 }}>{d.name}</span>
                <Badge kind={stageBadge[d.stage]}>{d.stage}</Badge>
              </div>
              {d.wedge && <div className="mono mb-2" style={{ fontSize: 8.5, letterSpacing: 1, color: 'var(--cyan)' }}>◆ DIFFERENTIATED WEDGE</div>}
              <div className="flex justify-between mono mb-1" style={{ fontSize: 10 }}>
                <span style={{ color: 'var(--faint)' }}>maturity</span><span style={{ color: stageColor[d.stage] }}>{d.maturity}%</span>
              </div>
              <Meter pct={d.maturity} color={stageColor[d.stage]} />
              <div className="flex justify-between mt-2.5 mono" style={{ fontSize: 10 }}>
                <span style={{ color: 'var(--cyan)' }}>{d.value}</span>
                <span style={{ color: 'var(--faint)' }}>{d.agents} agents</span>
              </div>
            </div>
          ))}
        </div>

        {/* drill-in drawer */}
        {sel && (
          <Card className="self-start" title="Product detail" extra={<button onClick={() => setSelId(null)}><X size={13} color="var(--dim)" /></button>}>
            <div className="flex items-center gap-2.5 mb-2">
              <span className="w-3 h-3 rounded-full flex-none" style={{ background: stageColor[sel.stage] }} />
              <span style={{ fontSize: 15, color: '#eaf6ff', fontWeight: 600 }}>{sel.name}</span>
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--dim)', lineHeight: 1.45, marginBottom: 12 }}>{sel.blurb}</div>
            <div className="mono" style={{ fontSize: 10 }}>
              {[['stage', sel.stage], ['owner', sel.owner], ['agents served', String(sel.agents)], ['value', sel.value]].map(([k, v]) => (
                <div key={k} className="flex justify-between py-1.5" style={{ borderBottom: '1px dashed var(--line)' }}>
                  <span style={{ color: 'var(--faint)' }}>{k}</span><span style={{ color: 'var(--text)' }}>{v}</span>
                </div>
              ))}
            </div>
            <div className="mt-3">
              <div className="flex justify-between mono mb-1" style={{ fontSize: 10 }}><span style={{ color: 'var(--faint)' }}>entity resolution</span><span style={{ color: 'var(--cyan)' }}>{sel.entityRes}%</span></div>
              <Meter pct={sel.entityRes} color="linear-gradient(90deg,#2f6b78,#55b8c9)" />
            </div>
            <div className="flex flex-wrap gap-1 mt-3">
              {sel.sources.map((s) => <span key={s} className="mono" style={{ fontSize: 9, color: 'var(--dim)', border: '1px solid var(--line2)', borderRadius: 4, padding: '1px 6px' }}>{s}</span>)}
            </div>
            <div className="mt-3 rounded-md p-2.5" style={{ background: 'rgba(85,184,201,0.05)', border: '1px solid var(--line)' }}>
              <div className="mono" style={{ fontSize: 9, color: 'var(--faint)' }}>NEXT MILESTONE</div>
              <div style={{ fontSize: 11.5, color: '#d3e0ec', marginTop: 2 }}>{sel.milestone}</div>
            </div>
            {sel.stage !== 'Live' && (
              <button onClick={() => promote(sel.id)} className="btn btn-pri w-full mt-3 flex items-center justify-center gap-1.5">
                Promote to {PROMOTE[sel.stage]} <ArrowUpRight size={13} />
              </button>
            )}
          </Card>
        )}
      </div>

      {/* land-and-expand roadmap — reflects live state */}
      <div className="mt-4">
        <div className="mono mb-2" style={{ fontSize: 10, letterSpacing: 2, color: 'var(--dim)', textTransform: 'uppercase' }}>Land &amp; expand roadmap · updates as you promote</div>
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(3,1fr)' }}>
          {buckets.map((b) => {
            const items = domains.filter((d) => b.stages.includes(d.stage))
            return (
              <div key={b.title} className="card" style={{ borderTop: `2px solid ${b.color}` }}>
                <div className="mono mb-2.5" style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, color: b.color }}>{b.title} · {items.length}</div>
                {items.length === 0 && <div className="mono" style={{ fontSize: 10, color: 'var(--faint)' }}>—</div>}
                {items.map((d) => (
                  <div key={d.id} className="flex items-center gap-2 py-1.5 cursor-pointer" onClick={() => setSelId(d.id)} style={{ borderBottom: '1px solid var(--line)' }}>
                    <span className="w-1.5 h-1.5 rounded-full flex-none" style={{ background: stageColor[d.stage] }} />
                    <span className="flex-1" style={{ fontSize: 11.5, color: '#d3e0ec' }}>{d.name}</span>
                    <span className="mono" style={{ fontSize: 9, color: 'var(--faint)' }}>{d.stage}</span>
                  </div>
                ))}
              </div>
            )
          })}
        </div>
      </div>
    </>
  )
}
