import { useState } from 'react'
import { ViewHeader, Card, Badge, Btn } from '../components/ui'
import { usePersona } from '../PersonaContext'
import { askStream, type AskChunk, type AskGuardrails, type AskTrace } from '../api/client'

const DEFAULT_QUERY = "Who owns the billing retry logic and what's the current retry policy?"

function renderAnswer(text: string) {
  const parts = text.split(/(\[\d+\])/g)
  return parts.map((part, i) =>
    /^\[\d+\]$/.test(part)
      ? <sup key={i} className="mono cursor-pointer" style={{ color: 'var(--cyan)', fontSize: 10 }}>{part}</sup>
      : <span key={i}>{part}</span>
  )
}

export default function Ask() {
  const { persona } = usePersona()
  const [query, setQuery] = useState(DEFAULT_QUERY)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [answer, setAnswer] = useState('')
  const [trace, setTrace] = useState<AskTrace | null>(null)
  const [chunks, setChunks] = useState<AskChunk[]>([])
  const [guardrails, setGuardrails] = useState<AskGuardrails | null>(null)
  const [model, setModel] = useState<string | null>(null)

  async function runAsk() {
    if (!query.trim() || loading) return
    setLoading(true)
    setError(null)
    setAnswer('')
    setTrace(null)
    setChunks([])
    setGuardrails(null)
    setModel(null)

    try {
      await askStream(query, persona.id, (event) => {
        if (event.type === 'trace') setTrace(event.data)
        else if (event.type === 'chunks') setChunks(event.data)
        else if (event.type === 'guardrails') setGuardrails(event.data)
        else if (event.type === 'token') setAnswer((a) => a + event.data)
        else if (event.type === 'done') setModel(event.data.model)
      })
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setLoading(false)
    }
  }

  const traceSteps = trace
    ? [
        `BM25 search · ${trace.bm25_count} candidates`,
        `Vector search · ${trace.vector_count} candidates`,
        `Graph walk · ${trace.graph_count} candidates (2 hops)`,
        `Fused ${trace.fused_count} → final ${trace.final_count}` +
          (trace.denied_count > 0 ? ` · ${trace.denied_count} withheld by ACL` : ''),
      ]
    : []

  const guardRows: [string, string, string][] = guardrails
    ? [
        ['acting-as persona', `${persona.name} · ${trace && trace.denied_count > 0 ? 'restricted' : 'allowed'}`, trace && trace.denied_count > 0 ? 'var(--amber)' : 'var(--green)'],
        ['pii redaction', `${guardrails.total_pii_masked} field${guardrails.total_pii_masked === 1 ? '' : 's'} masked`, 'var(--cyan)'],
        ['injection scan', guardrails.injection_blocked ? 'blocked' : 'clean', guardrails.injection_blocked ? 'var(--red)' : 'var(--green)'],
        ['logged to audit', '✓', 'var(--green)'],
      ]
    : []

  const sourcesUsed = Array.from(new Set(chunks.map((c) => c.source)))

  return (
    <>
      <ViewHeader title="ASK · CONTEXT CONSOLE" sub="hybrid retrieval · graph + vector + rerank · provenance-traced" />
      <div className="grid gap-3.5" style={{ gridTemplateColumns: '1fr 340px', height: 'calc(100vh - 160px)' }}>
        <div className="flex flex-col gap-3 overflow-y-auto">
          <div className="flex items-center gap-2.5 rounded-[10px] p-[12px_14px]" style={{ background: 'var(--panelSolid)', border: '1px solid var(--line2)' }}>
            <span style={{ color: 'var(--cyan)', fontSize: 16 }}>⌕</span>
            <input value={query} onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') runAsk() }}
              className="flex-1 bg-transparent border-none outline-none mono" style={{ color: '#eaf6ff', fontSize: 14 }} />
            <Btn variant="pri" onClick={runAsk}>{loading ? 'Asking…' : 'Ask'}</Btn>
          </div>

          {error && (
            <div className="card" style={{ borderColor: 'var(--red)', color: 'var(--red)', fontSize: 12 }}>
              {error} — is the backend running at localhost:8080?
            </div>
          )}

          <div className="card" style={{ lineHeight: 1.65, fontSize: 13 }}>
            <div className="card-t mb-2">Synthesized Answer</div>
            {answer
              ? renderAnswer(answer)
              : <span style={{ color: 'var(--dim)' }}>{loading ? 'Retrieving governed context…' : 'Ask a question to see a grounded, cited answer.'}</span>}
            {guardrails && (
              <div className="flex gap-2 mt-3.5">
                <Badge kind={trace && trace.denied_count > 0 ? 'b-stale' : 'b-ok'}>
                  ACL · {trace && trace.denied_count > 0 ? `${trace.denied_count} withheld` : 'allowed'}
                </Badge>
                <Badge kind="b-pii">{guardrails.total_pii_masked} PII fields masked</Badge>
                {model && <Badge kind="b-sync">{model}</Badge>}
              </div>
            )}
          </div>

          <Card title={`Retrieved Context · ${chunks.length} chunks`} extra={trace ? `fused ${trace.fused_count} → ${trace.final_count}` : ''}>
            {chunks.length === 0 && <div style={{ fontSize: 11.5, color: 'var(--dim)' }}>No context retrieved yet.</div>}
            {chunks.map((c) => (
              <div key={c.index} className="flex gap-3 py-2.5" style={{ borderBottom: '1px solid var(--line)' }}>
                <div className="mono font-bold flex-none" style={{ fontSize: 12, color: 'var(--green)', width: 38 }}>{c.trust.toFixed(2)}</div>
                <div>
                  <div style={{ fontSize: 11.5, color: '#d3e0ec', lineHeight: 1.35 }}>{c.text}</div>
                  <div className="mono mt-[3px]" style={{ fontSize: 9, color: 'var(--faint)' }}>
                    [{c.index}] {c.source} · {c.document_id}
                  </div>
                </div>
              </div>
            ))}
          </Card>
        </div>

        <div className="flex flex-col gap-3 overflow-y-auto">
          <Card title="Retrieval Trace" extra={`${traceSteps.length} steps`}>
            <div className="mono" style={{ fontSize: 10 }}>
              {traceSteps.length === 0 && <div style={{ color: 'var(--dim)' }}>—</div>}
              {traceSteps.map((t, i) => (
                <div key={i} className="flex items-center gap-2 py-[5px] relative">
                  <span className="w-2 h-2 rounded-full flex-none" style={{ border: '2px solid var(--cyan)', background: 'var(--bg)' }} />
                  {t}
                </div>
              ))}
            </div>
          </Card>
          <Card title="Guardrails" extra={guardrails ? <span style={{ color: guardrails.injection_blocked ? 'var(--red)' : 'var(--green)' }}>{guardrails.injection_blocked ? 'BLOCKED' : 'PASS'}</span> : undefined}>
            {guardRows.length === 0 && <div className="mono" style={{ fontSize: 10, color: 'var(--dim)' }}>—</div>}
            {guardRows.map(([k, v, c], i) => (
              <div key={i} className="flex justify-between mono py-[5px]" style={{ fontSize: 10, borderBottom: i < guardRows.length - 1 ? '1px dashed var(--line)' : 'none' }}>
                <span style={{ color: 'var(--faint)' }}>{k}</span><span style={{ color: c }}>{v}</span>
              </div>
            ))}
          </Card>
          <Card title="Provenance" extra="traceable">
            <div className="mono" style={{ fontSize: 10, color: 'var(--dim)', lineHeight: 1.7 }}>
              {chunks.length === 0
                ? '—'
                : <>
                    answer → {sourcesUsed.length} source{sourcesUsed.length === 1 ? '' : 's'}<br />
                    {chunks.slice(0, 4).map((c) => <span key={c.index}>→ {c.document_id} ({c.source})<br /></span>)}
                    <span style={{ color: 'var(--green)' }}>all lineage-resolved</span>
                  </>}
            </div>
          </Card>
        </div>
      </div>
    </>
  )
}
