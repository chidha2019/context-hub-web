import { useState } from 'react'
import { ViewHeader, Stat, Card } from '../components/ui'
import { marketSignals, competitors, wedge, type Competitor } from '../data/strategy'

export default function MarketPositioning() {
  const [sel, setSel] = useState<Competitor>(competitors.find((c) => c.id === 'us')!)

  return (
    <>
      <ViewHeader title="MARKET & POSITIONING" sub="context layer for AI agents · category snapshot, Aug 2026" />

      <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(5,1fr)' }}>
        {marketSignals.map((m) => <Stat key={m.label} n={m.n} label={m.label} detail={m.detail} color={m.color} />)}
      </div>

      <div className="grid gap-3 mt-3" style={{ gridTemplateColumns: '1.5fr 1fr' }}>
        {/* Interactive positioning chart */}
        <Card title="Positioning — click a player" extra="overlap × incumbent strength">
          <div className="relative w-full" style={{ height: 360 }}>
            {/* grid + axes */}
            <div className="absolute inset-0" style={{ borderLeft: '1px solid var(--line2)', borderBottom: '1px solid var(--line2)' }} />
            {[25, 50, 75].map((g) => (
              <div key={'v' + g} className="absolute" style={{ left: `${g}%`, top: 0, bottom: 0, borderLeft: '1px dashed var(--line)' }} />
            ))}
            {[25, 50, 75].map((g) => (
              <div key={'h' + g} className="absolute" style={{ bottom: `${g}%`, left: 0, right: 0, borderTop: '1px dashed var(--line)' }} />
            ))}
            {/* wedge zone (low overlap) */}
            <div className="absolute" style={{ left: 0, top: 0, bottom: 0, width: '40%', background: 'rgba(108,192,141,0.06)' }} />
            <div className="absolute mono" style={{ left: 8, top: 8, fontSize: 8.5, color: 'var(--green)', letterSpacing: 1 }}>◄ WEDGE ZONE · LOW HEAD-TO-HEAD</div>
            <div className="absolute mono" style={{ right: 8, top: 8, fontSize: 8.5, color: 'var(--red)', letterSpacing: 1 }}>CROWDED · HYPERSCALERS ►</div>
            {/* bubbles */}
            {competitors.map((c) => {
              const active = c.id === sel.id
              const d = 12 + c.r
              return (
                <button key={c.id} onClick={() => setSel(c)} title={c.name}
                  className="absolute grid place-items-center cursor-pointer"
                  style={{ left: `calc(${c.x}% - ${d / 2}px)`, bottom: `calc(${c.y}% - ${d / 2}px)`, width: d, height: d }}>
                  <span className="rounded-full" style={{ width: d, height: d, background: c.color, opacity: active ? 1 : 0.6, boxShadow: active ? '0 0 0 4px rgba(255,255,255,0.07)' : 'none', border: c.id === 'us' ? '2px solid var(--bright)' : 'none' }} />
                  <span className="absolute mono whitespace-nowrap" style={{ top: d + 1, fontSize: 8.5, color: active ? '#eaf6ff' : 'var(--dim)' }}>{c.name}</span>
                </button>
              )
            })}
            <div className="absolute mono" style={{ bottom: -18, right: 0, fontSize: 8.5, color: 'var(--faint)' }}>overlap with us →</div>
            <div className="absolute mono" style={{ top: '42%', left: -6, fontSize: 8.5, color: 'var(--faint)', transform: 'rotate(-90deg)', transformOrigin: 'left' }}>incumbent strength ↑</div>
          </div>
        </Card>

        {/* Compare panel (reacts to selection) */}
        <div className="flex flex-col gap-3">
          <Card title="Selected" extra={<span style={{ color: sel.color }}>{sel.id === 'us' ? 'that’s us' : 'competitor'}</span>}>
            <div className="flex items-center gap-2.5 mb-2">
              <span className="w-3.5 h-3.5 rounded-full flex-none" style={{ background: sel.color }} />
              <span style={{ fontSize: 15, color: '#eaf6ff', fontWeight: 600 }}>{sel.name}</span>
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--dim)', lineHeight: 1.45, marginBottom: 10 }}>{sel.angle}</div>
            <div className="mono" style={{ fontSize: 9, letterSpacing: 1, color: 'var(--faint)' }}>THEIR STRENGTH</div>
            <div style={{ fontSize: 12, color: '#d3e0ec', margin: '3px 0 10px' }}>{sel.strength}</div>
            <div className="mono" style={{ fontSize: 9, letterSpacing: 1, color: 'var(--green)' }}>{sel.id === 'us' ? 'POSITION' : 'OUR COUNTER'}</div>
            <div style={{ fontSize: 12, color: '#d3e0ec', marginTop: 3 }}>{sel.counter}</div>
            <div className="flex gap-4 mt-3 mono" style={{ fontSize: 10, color: 'var(--faint)' }}>
              <span>overlap <b style={{ color: 'var(--text)' }}>{sel.x}</b></span>
              <span>strength <b style={{ color: 'var(--text)' }}>{sel.y}</b></span>
            </div>
          </Card>
          <Card title="Our wedge" extra="differentiation">
            {wedge.map(([t], i) => (
              <div key={i} className="flex items-center gap-2 py-1.5" style={{ borderBottom: i < wedge.length - 1 ? '1px solid var(--line)' : 'none' }}>
                <span className="w-1.5 h-1.5 rounded-full flex-none" style={{ background: 'var(--cyan)' }} />
                <span style={{ fontSize: 11.5, color: '#d3e0ec' }}>{t}</span>
              </div>
            ))}
          </Card>
          <div className="rounded-[10px] p-3.5" style={{ background: 'rgba(85,184,201,0.05)', border: '1px solid rgba(85,184,201,0.28)' }}>
            <div className="mono mb-1.5" style={{ fontSize: 9, letterSpacing: 1.5, color: 'var(--cyan)' }}>ARCHITECTURE DIRECTION</div>
            <div style={{ fontSize: 11.5, color: 'var(--text)', lineHeight: 1.5 }}>
              At backend phase, move to <b>Next.js 16.3</b> (server-first) — retrieval, ACL &amp; PII stay <b>server-side</b>, Ask streams, and instant-nav makes screen/persona switching feel live. Prototype stays on Vite for now.
            </div>
          </div>
        </div>
      </div>

      <div className="mono mt-3" style={{ fontSize: 9, color: 'var(--faint)' }}>
        Sources: knowledge-graph market reports · MIT/industry GenAI failure studies · Atlan context-layer analysis · Glean Series F · Futurum semantic-layer coverage.
      </div>
    </>
  )
}
