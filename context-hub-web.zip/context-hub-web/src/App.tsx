import { Routes, Route } from 'react-router-dom'
import AppShell from './components/AppShell'
import Overview from './screens/Overview'
import Ask from './screens/Ask'
import Graph from './screens/Graph'
import Sources from './screens/Sources'
import Steward from './screens/Steward'
import Skills from './screens/Skills'
import Governance from './screens/Governance'
import Measure from './screens/Measure'
import Personas from './screens/Personas'
import MarketPositioning from './screens/MarketPositioning'
import DomainProducts from './screens/DomainProducts'
import Federation from './screens/Federation'

export default function App() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route index element={<Overview />} />
        <Route path="ask" element={<Ask />} />
        <Route path="graph" element={<Graph />} />
        <Route path="sources" element={<Sources />} />
        <Route path="steward" element={<Steward />} />
        <Route path="skills" element={<Skills />} />
        <Route path="governance" element={<Governance />} />
        <Route path="measure" element={<Measure />} />
        <Route path="personas" element={<Personas />} />
        <Route path="strategy" element={<MarketPositioning />} />
        <Route path="domains" element={<DomainProducts />} />
        <Route path="federation" element={<Federation />} />
      </Route>
    </Routes>
  )
}
