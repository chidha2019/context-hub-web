// Typed client for the ContextHub FastAPI backend (server/app/main.py).

const API_BASE = 'http://localhost:8080'

// The backend's governed ACL model covers exactly three personas (POC-PLAN §7.7);
// the front-end has eight. Map the other five onto the nearest governed persona
// so /ask and /governance stay functional for every persona in the TopBar.
const GOVERNED_PERSONAS = new Set(['data-engineer', 'digital-engineer', 'citizen'])
const PERSONA_FALLBACK: Record<string, string> = {
  bi: 'digital-engineer',
  architect: 'digital-engineer',
  qa: 'digital-engineer',
  devops: 'digital-engineer',
  devsecops: 'data-engineer',
}

export function governedPersona(personaId: string): string {
  if (GOVERNED_PERSONAS.has(personaId)) return personaId
  return PERSONA_FALLBACK[personaId] ?? 'digital-engineer'
}

export interface AskTrace {
  bm25_count: number
  vector_count: number
  graph_count: number
  fused_count: number
  final_count: number
  denied_count: number
  denied_sources: string[]
}

export interface AskChunk {
  index: number
  document_id: string
  source: string
  trust: number
  text: string
}

export interface AskGuardrails {
  injection_blocked: boolean
  pii_counts: Record<string, number>
  total_pii_masked: number
  acl_denied: number
}

export type AskEvent =
  | { type: 'trace'; data: AskTrace }
  | { type: 'chunks'; data: AskChunk[] }
  | { type: 'guardrails'; data: AskGuardrails }
  | { type: 'token'; data: string }
  | { type: 'done'; data: { model: string } }

export interface ServeEventOut {
  ts: string
  actor: string
  persona: string
  action: string
  asset: string
  acl: 'allowed' | 'denied' | 'blocked'
  pii_masked: number
  latency_ms: number
  channel: string
}

export interface GovernanceStats {
  total: number
  allowed: number
  denied: number
  blocked: number
  pii_total: number
  avg_latency_ms: number
  mcp_requests: number
}

/**
 * POST /api/ask — streams SSE events (trace, chunks, guardrails, token*, done).
 * Uses fetch + a ReadableStream reader rather than EventSource, since EventSource
 * can't send a POST body or the X-Persona header.
 */
export async function askStream(
  query: string,
  persona: string,
  onEvent: (event: AskEvent) => void,
  signal?: AbortSignal,
): Promise<void> {
  const res = await fetch(`${API_BASE}/api/ask`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Persona': governedPersona(persona),
    },
    body: JSON.stringify({ query }),
    signal,
  })

  if (!res.ok || !res.body) {
    throw new Error(`/api/ask failed: ${res.status}`)
  }

  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })

    let boundary = buffer.indexOf('\n\n')
    while (boundary !== -1) {
      const block = buffer.slice(0, boundary)
      buffer = buffer.slice(boundary + 2)

      const typeLine = block.split('\n').find((l) => l.startsWith('event: '))
      const dataLine = block.split('\n').find((l) => l.startsWith('data: '))
      if (typeLine && dataLine) {
        const type = typeLine.slice('event: '.length) as AskEvent['type']
        const data = JSON.parse(dataLine.slice('data: '.length))
        onEvent({ type, data } as AskEvent)
      }
      boundary = buffer.indexOf('\n\n')
    }
  }
}

export async function getAudit(persona: string, limit = 50): Promise<ServeEventOut[]> {
  const res = await fetch(`${API_BASE}/api/governance/audit?limit=${limit}`, {
    headers: { 'X-Persona': governedPersona(persona) },
  })
  if (!res.ok) throw new Error(`/api/governance/audit failed: ${res.status}`)
  return res.json()
}

export async function getGovernanceStats(persona: string): Promise<GovernanceStats> {
  const res = await fetch(`${API_BASE}/api/governance/stats`, {
    headers: { 'X-Persona': governedPersona(persona) },
  })
  if (!res.ok) throw new Error(`/api/governance/stats failed: ${res.status}`)
  return res.json()
}

function authedGet<T>(path: string, persona: string): Promise<T> {
  return fetch(`${API_BASE}${path}`, { headers: { 'X-Persona': governedPersona(persona) } }).then((res) => {
    if (!res.ok) throw new Error(`${path} failed: ${res.status}`)
    return res.json()
  })
}

function authedPost<T>(path: string, persona: string): Promise<T> {
  return fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: { 'X-Persona': governedPersona(persona) },
  }).then((res) => {
    if (!res.ok) throw new Error(`${path} failed: ${res.status}`)
    return res.json()
  })
}

export interface SourceConnectorOut {
  id: string
  name: string
  document_count: number
  chunk_count: number
  classifications: Record<string, number>
}

export interface SourcesResponse {
  connectors: SourceConnectorOut[]
  corpus_generated_at: string
}

export function getSources(persona: string): Promise<SourcesResponse> {
  return authedGet('/api/sources', persona)
}

export interface GraphNode {
  id: string
  type: string
  label: string
  degree: number
  source?: string
  classification?: string
  aliases?: { source: string; raw_name: string }[]
}

export interface GraphEdge {
  source: string
  target: string
  rel: string
}

export interface GraphResponse {
  nodes: GraphNode[]
  edges: GraphEdge[]
}

export function getGraph(persona: string): Promise<GraphResponse> {
  return authedGet('/api/graph', persona)
}

export interface StewardProposal {
  entity_type: string
  canonical: string
  raw_name: string
  source: string
  entity_id: string
}

export interface StewardItem {
  id: string
  type: string
  title: string
  confidence: number
  origin: string
  proposal: StewardProposal
}

export function getStewardQueue(persona: string): Promise<StewardItem[]> {
  return authedGet('/api/steward/queue', persona)
}

export function approveReview(id: string, persona: string): Promise<unknown> {
  return authedPost(`/api/steward/${id}/approve`, persona)
}

export function rejectReview(id: string, persona: string): Promise<unknown> {
  return authedPost(`/api/steward/${id}/reject`, persona)
}

export interface PersonaMeasure {
  persona: string
  requests: number
  avg_latency_ms: number
  pii_masked: number
  denied: number
}

export interface MeasureResponse {
  overall: GovernanceStats
  by_persona: PersonaMeasure[]
}

export function getMeasure(persona: string): Promise<MeasureResponse> {
  return authedGet('/api/measure', persona)
}

export interface OverviewResponse {
  entities: number
  relations: number
  served_24h: number
}

export function getOverview(persona: string): Promise<OverviewResponse> {
  return authedGet('/api/overview', persona)
}
