import { createContext, useContext, useState, type ReactNode } from 'react'
import { PERSONAS, personaById, type Persona } from './personas'

interface PersonaCtx {
  persona: Persona
  setPersona: (id: string) => void
  all: Persona[]
}

const Ctx = createContext<PersonaCtx | null>(null)

export function PersonaProvider({ children }: { children: ReactNode }) {
  // Default workspace: Data Engineer (first persona).
  const [persona, setP] = useState<Persona>(PERSONAS[0])
  const setPersona = (id: string) => setP(personaById(id))
  return <Ctx.Provider value={{ persona, setPersona, all: PERSONAS }}>{children}</Ctx.Provider>
}

export function usePersona(): PersonaCtx {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('usePersona must be used within a PersonaProvider')
  return ctx
}
