// The 8 consuming personas from the ContextHub architecture.
// Each persona reshapes the app: its own dashboard KPIs + primary board,
// default workspace, consumer surfaces, skills/tools, and access scope.

export interface Kpi {
  n: string
  label: string
  detail?: string
  trend?: 'up' | 'down'
  color?: string // 'cy' | 'gr' | 'am' | 'mg' | 'bl'
}
export interface BoardRow {
  label: string
  value: string
  badge: string // b-ok | b-sync | b-stale | b-err | b-pii
}
export interface Persona {
  id: string
  name: string
  initials: string
  color: string
  tagline: string
  home: string
  focus: string[]
  kpis: Kpi[]
  board: { title: string; extra: string; rows: BoardRow[] }
  consumers: { name: string; surface: string }[]
  skills: string[]
  access: string
  spines: string[]
}

export const PERSONAS: Persona[] = [
  {
    id: 'data-engineer',
    name: 'Data Engineer',
    initials: 'DE',
    color: '#55b8c9',
    tagline: 'Pipelines, lineage & data quality across every source.',
    home: '/sources',
    focus: ['Sources synced', 'DQ pass rate', 'Lineage coverage'],
    kpis: [
      { n: '28/42', label: 'Sources Synced', detail: '3 stale', color: 'gr' },
      { n: '96.4%', label: 'DQ Pass Rate', detail: '1.4pt', trend: 'up', color: 'cy' },
      { n: '91%', label: 'Lineage Coverage', detail: '6pt', trend: 'up', color: 'gr' },
      { n: '12', label: 'Failed Loads / 24h', detail: '4 vs yest', trend: 'down', color: 'am' },
      { n: '4m', label: 'Freshness p95', detail: 'SLA 15m', color: 'cy' },
    ],
    board: {
      title: 'Pipeline & Source Health', extra: '28/42 ON',
      rows: [
        { label: 'Confluence · Eng', value: '184k', badge: 'b-ok' },
        { label: 'Jira · Issues', value: 'syncing', badge: 'b-sync' },
        { label: 'GitHub · 214 repos', value: '1.1M', badge: 'b-ok' },
        { label: 'Salesforce', value: 'stale 6h', badge: 'b-stale' },
        { label: 'Postgres · prod', value: '2.4k', badge: 'b-ok' },
      ],
    },
    consumers: [
      { name: 'Databricks', surface: 'UC Genie · metric view' },
      { name: 'Snowflake', surface: 'Cortex semantic view' },
    ],
    skills: ['Coding Skills', 'graph.retrieve', 'uc.metric_view'],
    access: 'Read/write across data sources, lineage & DQ context',
    spines: ['TRUST', 'LEARN', 'SCALE'],
  },
  {
    id: 'bi',
    name: 'BI Analyst',
    initials: 'BI',
    color: '#6f9fe0',
    tagline: 'Trusted metrics, dashboards & self-serve analytics.',
    home: '/measure',
    focus: ['Certified KPIs', 'Glossary coverage', 'Dashboard reuse'],
    kpis: [
      { n: '214', label: 'Certified KPIs', detail: '9 new', trend: 'up', color: 'cy' },
      { n: '88%', label: 'Glossary Coverage', detail: '3pt', trend: 'up', color: 'gr' },
      { n: '1.2k', label: 'Dashboards', detail: 'PowerBI + Cortex', color: 'bl' },
      { n: '3.4×', label: 'Metric Reuse', detail: 'vs Q2', trend: 'up', color: 'gr' },
      { n: '6', label: 'Stale Metrics', detail: 'need review', trend: 'down', color: 'am' },
    ],
    board: {
      title: 'Certified Metrics', extra: 'semantic layer',
      rows: [
        { label: 'Net Revenue Retention', value: 'certified', badge: 'b-ok' },
        { label: 'Churn Rate', value: 'review', badge: 'b-stale' },
        { label: 'MRR', value: 'certified', badge: 'b-ok' },
        { label: 'CAC', value: 'certified', badge: 'b-ok' },
        { label: 'Gross Margin', value: 'draft', badge: 'b-sync' },
      ],
    },
    consumers: [
      { name: 'PowerBI', surface: 'TMDL + DAX' },
      { name: 'Snowflake', surface: 'Cortex semantic view' },
    ],
    skills: ['Metrics & KPIs', 'snowflake.query'],
    access: 'Read semantic layer, metrics & certified glossary',
    spines: ['TRUST', 'MEASURE'],
  },
  {
    id: 'architect',
    name: 'Architect',
    initials: 'AR',
    color: '#4fb39b',
    tagline: 'System design, patterns & technology topology.',
    home: '/graph',
    focus: ['Entities mapped', 'Design patterns', 'Blast radius'],
    kpis: [
      { n: '1.84M', label: 'Entities Mapped', detail: '1.2k/min', trend: 'up', color: 'cy' },
      { n: '42', label: 'Domains', detail: 'all owned', color: 'gr' },
      { n: '128', label: 'Design Patterns', detail: 'catalogued', color: 'bl' },
      { n: '14', label: 'Avg Blast Radius', detail: 'per change', color: 'am' },
      { n: '320', label: 'Orphan Nodes', detail: 'to reconcile', trend: 'down', color: 'am' },
    ],
    board: {
      title: 'Domain Topology', extra: '42 domains',
      rows: [
        { label: 'Billing domain', value: '214 svc', badge: 'b-ok' },
        { label: 'Identity domain', value: '88 svc', badge: 'b-ok' },
        { label: 'Data platform', value: '132 svc', badge: 'b-sync' },
        { label: 'Payments', value: '247 edges', badge: 'b-ok' },
        { label: 'Legacy CRM', value: 'deprecating', badge: 'b-stale' },
      ],
    },
    consumers: [
      { name: 'Information Ex.', surface: 'Semantic view · YAML/RDF' },
      { name: 'Databricks', surface: 'UC Genie · ontology' },
    ],
    skills: ['Architecture & Design', 'graph.retrieve'],
    access: 'Read full graph, ontology & cross-domain relationships',
    spines: ['SCALE', 'TRUST'],
  },
  {
    id: 'digital-engineer',
    name: 'Digital Engineer',
    initials: 'DG',
    color: '#a98cd6',
    tagline: 'Apps & agents wired to context through MCP.',
    home: '/skills',
    focus: ['MCP tools live', 'Retrieval precision', 'Agent uptime'],
    kpis: [
      { n: '21', label: 'MCP Tools Live', detail: '3 new', trend: 'up', color: 'mg' },
      { n: '0.94', label: 'Retrieval P@k', detail: 'reranked', trend: 'up', color: 'cy' },
      { n: '99.6%', label: 'Agent Uptime', detail: '30d', color: 'gr' },
      { n: '88k', label: 'Tool Calls / 24h', detail: 'graph.retrieve', color: 'bl' },
      { n: '42', label: 'Failed Calls', detail: 'auto-retried', trend: 'down', color: 'am' },
    ],
    board: {
      title: 'MCP Tools & Agents', extra: '21 live',
      rows: [
        { label: 'graph.retrieve', value: '88k calls', badge: 'b-ok' },
        { label: 'snowflake.query', value: '9.1k', badge: 'b-ok' },
        { label: 'uc.metric_view', value: '5.4k', badge: 'b-ok' },
        { label: 'support-copilot', value: 'live', badge: 'b-ok' },
        { label: 'sales-gpt', value: 'live', badge: 'b-sync' },
      ],
    },
    consumers: [
      { name: 'Applications / UIs', surface: 'MCP endpoints' },
      { name: 'SDLC Tools', surface: 'MCP endpoints' },
    ],
    skills: ['graph.retrieve', 'Coding Skills', 'Architecture & Design'],
    access: 'Invoke MCP tools & skills, read serving context',
    spines: ['SERVE', 'GOVERN'],
  },
  {
    id: 'qa',
    name: 'QA Engineer',
    initials: 'QA',
    color: '#6cc08d',
    tagline: 'Test coverage, quality gates & requirement traceability.',
    home: '/steward',
    focus: ['Coverage %', 'Req traceability', 'Defect leakage'],
    kpis: [
      { n: '82%', label: 'Test Coverage', detail: '4pt', trend: 'up', color: 'gr' },
      { n: '94%', label: 'Req Traceability', detail: 'linked', color: 'cy' },
      { n: '34', label: 'Open Reviews', detail: '8 high-impact', color: 'am' },
      { n: '1.8%', label: 'Defect Leakage', detail: '0.3pt', trend: 'down', color: 'gr' },
      { n: '7', label: 'Flaky Tests', detail: 'quarantined', trend: 'down', color: 'am' },
    ],
    board: {
      title: 'Review Queue', extra: '34 pending',
      rows: [
        { label: 'Net Revenue Retention · KPI', value: '0.71', badge: 'b-stale' },
        { label: 'MRR synonym · Glossary', value: '0.68', badge: 'b-stale' },
        { label: 'Acme ↔ Account · Entity', value: '0.83', badge: 'b-sync' },
        { label: 'Churn Rate · KPI', value: '0.62', badge: 'b-stale' },
        { label: 'PII tag · email_hash', value: '0.90', badge: 'b-ok' },
      ],
    },
    consumers: [{ name: 'SDLC Tools', surface: 'MCP endpoints' }],
    skills: ['QA Skills', 'Requirement Elaboration'],
    access: 'Read requirements, tests & SDLC skills; propose reviews',
    spines: ['TRUST', 'LEARN'],
  },
  {
    id: 'devops',
    name: 'DevOps Engineer',
    initials: 'DO',
    color: '#d6a45c',
    tagline: 'Deploy, containers & pipeline automation.',
    home: '/sources',
    focus: ['Deploy success', 'Pipeline health', 'MTTR'],
    kpis: [
      { n: '98.7%', label: 'Deploy Success', detail: '30d', trend: 'up', color: 'gr' },
      { n: '64', label: 'Pipelines', detail: '3 running', color: 'cy' },
      { n: '22m', label: 'MTTR', detail: '8m faster', trend: 'down', color: 'gr' },
      { n: '3', label: 'Rollbacks / 24h', detail: 'gateway', trend: 'down', color: 'am' },
      { n: '128', label: 'Containers', detail: 'across 12 hosts', color: 'bl' },
    ],
    board: {
      title: 'Deployments & Pipelines', extra: '64 pipelines',
      rows: [
        { label: 'billing-service', value: 'deployed', badge: 'b-ok' },
        { label: 'identity-api', value: 'deploying', badge: 'b-sync' },
        { label: 'data-loader', value: 'healthy', badge: 'b-ok' },
        { label: 'gateway', value: 'rollback', badge: 'b-err' },
        { label: 'scheduler', value: 'healthy', badge: 'b-ok' },
      ],
    },
    consumers: [
      { name: 'SDLC Tools', surface: 'MCP endpoints' },
      { name: 'Applications', surface: 'MCP endpoints' },
    ],
    skills: ['DevOps Skills', 'Coding Skills'],
    access: 'Read ops metadata, runbooks & deployment context',
    spines: ['SERVE', 'MEASURE'],
  },
  {
    id: 'devsecops',
    name: 'DevSecOps Engineer',
    initials: 'DS',
    color: '#d97a86',
    tagline: 'Security, compliance & vulnerability posture.',
    home: '/governance',
    focus: ['Vulns open', 'Policy pass', 'PII exposure'],
    kpis: [
      { n: '11', label: 'Vulns Open', detail: '2 critical', trend: 'down', color: 'am' },
      { n: '100%', label: 'Policy Pass', detail: '7d clean', color: 'gr' },
      { n: '14.2k', label: 'PII Fields Masked', detail: '/ 24h', color: 'mg' },
      { n: '3', label: 'Injections Blocked', detail: '2 today', trend: 'down', color: 'am' },
      { n: '100%', label: 'Requests Audited', detail: '318k/24h', color: 'gr' },
    ],
    board: {
      title: 'Security Posture', extra: 'zero-trust',
      rows: [
        { label: 'Injection attempts', value: '3 blocked', badge: 'b-err' },
        { label: 'Over-permissioned serves', value: '0', badge: 'b-ok' },
        { label: 'PII fields masked', value: '14.2k', badge: 'b-pii' },
        { label: 'Critical vulns', value: '2 open', badge: 'b-stale' },
        { label: 'Policy violations', value: '0', badge: 'b-ok' },
      ],
    },
    consumers: [{ name: 'SDLC Tools', surface: 'MCP endpoints' }],
    skills: ['DevSecOps Skills'],
    access: 'Read audit, entitlements, PII & policy context',
    spines: ['GOVERN', 'TRUST'],
  },
  {
    id: 'citizen',
    name: 'Citizen Developer',
    initials: 'CD',
    color: '#8f93d6',
    tagline: 'Low-code building, guided by context & guardrails.',
    home: '/ask',
    focus: ['Guided builds', 'Guardrail hits', 'Time to answer'],
    kpis: [
      { n: '42', label: 'Guided Builds', detail: 'this week', trend: 'up', color: 'cy' },
      { n: '128', label: 'Guardrail Hits', detail: 'kept safe', color: 'mg' },
      { n: '12s', label: 'Time to Answer', detail: 'p50', trend: 'down', color: 'gr' },
      { n: '9', label: 'Approved Scopes', detail: 'available', color: 'bl' },
      { n: '4', label: 'Blocked Actions', detail: 'out of scope', trend: 'down', color: 'am' },
    ],
    board: {
      title: 'Guided Builds', extra: 'guard-railed',
      rows: [
        { label: 'Refund workflow', value: 'building', badge: 'b-sync' },
        { label: 'Report · churn', value: 'ready', badge: 'b-ok' },
        { label: 'Form · intake', value: 'review', badge: 'b-stale' },
        { label: 'Approved templates', value: '9', badge: 'b-ok' },
        { label: 'Blocked actions', value: '4', badge: 'b-err' },
      ],
    },
    consumers: [{ name: 'Applications / UIs', surface: 'MCP endpoints' }],
    skills: ['Requirement Elaboration', 'Coding Skills'],
    access: 'Ask & assemble within approved, guard-railed scope',
    spines: ['SERVE', 'GOVERN'],
  },
]

export const personaById = (id: string): Persona =>
  PERSONAS.find((p) => p.id === id) ?? PERSONAS[0]
