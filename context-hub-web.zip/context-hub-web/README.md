# ContextHub — POC

Enterprise **Context Hub** command center — a single governed graph, served to agents over HTTP
and MCP with ACL enforcement, PII masking and full audit, demonstrated on a synthetic B2B payments
org ("Meridian Pay"). See `docs/POC-PLAN.md` for the full build specification and rationale behind
every decision below.

## Stack

- **Frontend**: Vite + React 18 + TypeScript, Tailwind CSS, react-router-dom, lucide-react.
- **Backend**: FastAPI + SQLite, `sentence-transformers` for embedding, `rank-bm25` + NetworkX for
  retrieval, `boto3`/AWS Bedrock for Claude synthesis.
- **MCP**: a stdio server (`server/mcp_server/`) exposing the same governed retrieval to any MCP
  client — see `server/README.md`.

## Run it

One command bootstraps the venv, node_modules, synthetic corpus, ingestion, and both servers:

```bash
make demo          # idempotent — safe to re-run
make reset         # wipes server/.venv and node_modules first, for a cold-clone rehearsal
```

Or run each piece by hand:

```bash
# Backend
cd server
uv venv
uv pip install -e ".[dev]"
uv run python -m app.synth.generate   # generate the synthetic corpus (deterministic under SEED)
uv run python -m app.ingest.pipeline  # chunk, embed, resolve entities, build graph, write SQLite
uv run uvicorn app.main:app --port 8080

# Frontend (separate terminal)
npm install
npm run dev          # http://localhost:5173
npm run build         # type-check + production build to /dist
npm run preview       # serve the production build
```

Backend exit-criteria checks (per milestone) live in `server/tests/` — e.g.
`uv run python -m tests.test_m3` from `server/`.

## Run with Docker (frontend only)

Production (multi-stage build → static bundle served by nginx):

```bash
docker compose up --build
# → http://localhost:8090
```

Development (Vite dev server with hot reload, source mounted):

```bash
docker compose --profile dev up --build dev
# → http://localhost:5173
```

The `Dockerfile` is multi-stage: `deps` (cached `npm ci`) → `dev` (Vite) →
`build` (`npm run build`) → `prod` (nginx serving `/dist`). `nginx.conf` adds the
SPA fallback (`try_files … /index.html`) so client-side routes resolve, long-caches
fingerprinted `/assets`, and never caches `index.html`. The backend isn't containerized in this
POC — run it via `uv` as above, on port 8080.

## Why no vector database

~3,500 chunks × 384 dims is a ~5 MB float32 numpy array — brute-force cosine over it
(`server/app/retrieval/vector.py`) is sub-5ms, faster than the network hop to a vector DB would
be. Adding Qdrant or pgvector to a POC at this scale costs a service, a schema and a migration
path, and buys nothing measurable. This is a documented engineering call, not a shortcut — see
POC-PLAN §4.1.

## What's real vs. what stays mock

Seven screens are wired to the live backend — every number on them is derived, never asserted:

| Screen | Backed by |
|---|---|
| `Ask.tsx` | `POST /api/ask` — live governed retrieval + streamed Claude synthesis |
| `Sources.tsx` | `GET /api/sources` — real per-connector document/chunk counts |
| `Graph.tsx` | `GET /api/graph` — real entities/edges, click-to-inspect, ACL-filtered |
| `Steward.tsx` | `GET/POST /api/steward/*` — real entity-resolution proposals; Approve/Reject mutate the DB |
| `Governance.tsx` | `GET /api/governance/*` — real audit trail from real serve events |
| `Measure.tsx` | `GET /api/measure` — counters derived from the audit table (adoption/uplift/SLA/ROI dropped — no backing data exists for them) |
| `Overview.tsx` | `GET /api/overview` for the top globals strip + a polled `LiveFeed`; the persona-specific KPI/board content and the full-bleed graph background stay static (see below) |

Deliberately still static, by design:

- **`Skills.tsx`, `MarketPositioning.tsx`, `DomainProducts.tsx`, `Federation.tsx`, `Personas.tsx`**
  — positioning/vision surfaces and persona-marketing content, not POC surfaces. Not wired.
- **`Overview.tsx`'s persona `kpis`/`board`** (from `src/personas.ts`) — content for 8 personas,
  5 of which the backend's ACL model doesn't govern at all (`server/app/governance/acl.py` covers
  exactly 3: `data-engineer`, `digital-engineer`, `citizen`). Same class of content as the
  out-of-scope screens above.
- **Decorative header buttons with no handler** — e.g. Sources' "+ Add Source", Steward's "Bulk
  approve"/"Edit", Governance's "Entitlements"/"AI Act Register". None of these were ever in
  POC-PLAN's per-screen scope (§2); left as visible-but-inert rather than removed.
- **Overview's full-bleed background graph** — ambient canvas art behind the command-center HUD,
  not a real inspector surface, so it stays on the original procedural animation.

## Structure

```
src/
  App.tsx                 # routes
  api/client.ts            # typed fetch client -> the FastAPI backend, X-Persona from PersonaContext
  components/
    AppShell.tsx          # nav + top bar + <Outlet/>
    Sidebar.tsx           # left icon rail (routes)
    TopBar.tsx            # breadcrumb, search, persona switch, status
    GraphCanvas.tsx       # force-directed graph canvas with real click-to-inspect (Graph); decorative background (Overview)
    LiveFeed.tsx          # polls real serve events for the live context-feed ticker
    ui.tsx                # Card / Stat / Badge / Meter / Btn / ViewHeader
  screens/                 # 12 screens — see the real-vs-mock table above
    Overview.tsx  Ask.tsx  Graph.tsx  Sources.tsx  Steward.tsx  Skills.tsx
    Governance.tsx  Measure.tsx  Personas.tsx
    MarketPositioning.tsx  DomainProducts.tsx  Federation.tsx
  data/mock.ts            # mock data still used by the out-of-scope screens above
  types.ts                # ContextAsset, ServeEvent, SourceConnector, ...

server/
  app/                     # FastAPI app — see server/README.md
  mcp_server/              # MCP stdio server exposing the same governed retrieval
  tests/                   # per-milestone exit-criteria scripts (test_m0..test_m6)
docs/POC-PLAN.md           # the full build specification
```

## MCP

See `server/README.md` for the `.mcp.json` snippet, the three governed tools
(`graph.retrieve`, `graph.walk`, `context.assets`), and how persona binding works at launch.
