/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#05070b',
        ink2: '#080d15',
        panelSolid: '#0a0f18',
        cy: '#22d3ee',
        am: '#f5a524',
        gr: '#34e29b',
        mg: '#c77dff',
        rd: '#ff5470',
        bl: '#4a9eff',
        tl: '#2dd4bf',
        txt: '#c7d5e3',
        dim: '#6b7d92',
        faint: '#41505f',
      },
      fontFamily: {
        mono: ['"JetBrains Mono"', 'ui-monospace', '"SF Mono"', 'Menlo', 'Consolas', 'monospace'],
        sans: ['Inter', 'system-ui', '-apple-system', '"Segoe UI"', 'Roboto', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
