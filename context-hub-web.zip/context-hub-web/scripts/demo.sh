#!/usr/bin/env bash
# ContextHub demo bootstrap — reset, generate, ingest, serve.
# Idempotent by default (safe to re-run); RESET=1 wipes the venv/node_modules first
# for a true cold-clone rehearsal. See docs/POC-PLAN.md §8/§10.
set -euo pipefail

# The corpus generator and ingestion pipeline print unicode checkmarks in their self-checks;
# Windows' default console codepage (cp1252) can't encode them and crashes the process otherwise.
export PYTHONIOENCODING=utf-8

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVER_DIR="$ROOT_DIR/server"

if [ "${RESET:-0}" = "1" ]; then
  echo "==> RESET=1 — removing server/.venv and node_modules"
  rm -rf "$SERVER_DIR/.venv" "$ROOT_DIR/node_modules"
fi

if [ ! -d "$SERVER_DIR/.venv" ]; then
  echo "==> Creating server venv (uv venv + uv pip install)"
  (cd "$SERVER_DIR" && uv venv && uv pip install -e ".[dev]")
fi

if [ ! -d "$ROOT_DIR/node_modules" ]; then
  echo "==> Installing frontend dependencies (npm install)"
  (cd "$ROOT_DIR" && npm install)
fi

echo "==> Freeing ports 8080/5173 if something stale is holding them"
powershell -NoProfile -Command "
  Get-NetTCPConnection -LocalPort 8080,5173 -ErrorAction SilentlyContinue |
    Select-Object -ExpandProperty OwningProcess -Unique |
    ForEach-Object { Stop-Process -Id \$_ -Force -ErrorAction SilentlyContinue }
" >/dev/null 2>&1 || true

echo "==> Generating synthetic corpus (deterministic under SEED)"
(cd "$SERVER_DIR" && uv run python -m app.synth.generate)

echo "==> Running ingestion pipeline (chunk, embed, resolve, build graph, write DB)"
# If the embedding model is already cached, force offline mode — a live rehearsal hit a slow/
# flaky Hugging Face Hub metadata fetch (not the model download itself) that stalled ingestion
# for over 20 minutes despite the model being fully cached locally. A cold clone's first-ever
# run still needs network to fetch the model once; every run after that shouldn't touch the
# network at all.
HF_CACHE="$HOME/.cache/huggingface/hub/models--sentence-transformers--all-MiniLM-L6-v2"
if [ -d "$HF_CACHE" ]; then
  (cd "$SERVER_DIR" && HF_HUB_OFFLINE=1 uv run python -m app.ingest.pipeline)
else
  (cd "$SERVER_DIR" && uv run python -m app.ingest.pipeline)
fi

echo "==> Starting backend (uvicorn :8080)"
(cd "$SERVER_DIR" && nohup uv run uvicorn app.main:app --port 8080 > /tmp/contexthub-backend.log 2>&1 &)

echo "==> Starting frontend (vite :5173)"
(cd "$ROOT_DIR" && nohup npm run dev > /tmp/contexthub-frontend.log 2>&1 &)

echo "==> Waiting for both services to come up..."
backend_up=0
for _ in $(seq 1 30); do
  if curl -sf -H "X-Persona: data-engineer" http://localhost:8080/api/health >/dev/null 2>&1; then
    backend_up=1
    break
  fi
  sleep 1
done

frontend_up=0
for _ in $(seq 1 30); do
  if curl -sf http://localhost:5173/ >/dev/null 2>&1; then
    frontend_up=1
    break
  fi
  sleep 1
done

if [ "$backend_up" != "1" ] || [ "$frontend_up" != "1" ]; then
  echo "!! One or both services failed to start."
  echo "   Backend log:  /tmp/contexthub-backend.log"
  echo "   Frontend log: /tmp/contexthub-frontend.log"
  exit 1
fi

cat <<'BANNER'

============================================================
  ContextHub is up
    backend  http://localhost:8080
    frontend http://localhost:5173
============================================================

Demo script (docs/POC-PLAN.md §10):
  1. /sources     — three connectors, real record counts
  2. /graph       — click `billing-service`, see real edges to owner/PRs/tickets
  3. /steward     — approve "'@mike.c' -> 'Michael Chen'", watch the queue count drop
  4. /ask as Data Engineer — "What customer email and card number were affected by the
     PAY-2871 refund?" — full grounded answer, 8 chunks, 11 PII fields masked
  5. Switch to Citizen Developer, same query — degraded answer, Slack denied entirely
  6. /governance  — both serves show allowed; PII column differs: 11 masked vs -
  7. Point Claude Code at the MCP server (.mcp.json) — a live channel=mcp row appears

BANNER
